export function calculateSearchScore(
queryTokens: string[],
targetValues: string[]
): number {
let score = 0;

const normalizedTargets = targetValues
.filter(Boolean)
.map((value) => value.toLowerCase());

queryTokens.forEach((token) => {
normalizedTargets.forEach((target) => {
if (target === token) {
score += 100;
return;
}

if (target.startsWith(token)) {
score += 75;
return;
}

if (target.includes(token)) {
score += 50;
}
});
});

return score;
}