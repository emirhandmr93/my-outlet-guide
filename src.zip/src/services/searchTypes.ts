export type SearchResultType =
| "outlet"
| "brand"
| "city"
| "country"
| "category"
| "feature";

export type SearchResult = {
id: string;
title: string;
subtitle: string;
type: SearchResultType;
routeName: string;
routeParams?: Record<string, string>;
score: number;
};