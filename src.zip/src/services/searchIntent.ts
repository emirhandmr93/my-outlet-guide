export type SearchIntent =
| "outlet"
| "brand"
| "city"
| "country"
| "category"
| "tool"
| "guide"
| "general";

export function detectSearchIntent(
tokens: string[]
): SearchIntent {
const query = tokens.join(" ");

if (
query.includes("tax") ||
query.includes("vat")
) {
return "guide";
}

if (
query.includes("calculator") ||
query.includes("compare")
) {
return "tool";
}

return "general";
}