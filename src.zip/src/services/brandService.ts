import { brands, Brand } from "../constants/brands";
import { categories } from "../constants/categories";
import { outletBrands } from "../constants/outletBrands";

export type BrandCategoryGroup = {
categoryId: string;
categoryName: string;
icon: string;
order: number;
brands: Brand[];
};

export function getPopularBrands(limit = 6) {
return brands
.filter((brand) => brand.brandStatus === "active")
.sort((a, b) => a.brandName.localeCompare(b.brandName))
.slice(0, limit);
}

export function getBrandsForOutlet(outletId: string) {
const outletBrandRelations = outletBrands.filter(
(item) => item.outletId === outletId && item.relationStatus === "active"
);

return brands
.filter(
(brand) =>
brand.brandStatus === "active" &&
outletBrandRelations.some(
(relation) => relation.brandId === brand.brandId
)
)
.sort((a, b) => a.brandName.localeCompare(b.brandName));
}


export function groupBrandsByCategory(brandList: Brand[]) {
return categories
.map((category) => {
const categoryBrands = brandList.filter(
(brand) => brand.categoryId === category.categoryId
);

return {
categoryId: category.categoryId,
categoryName: category.categoryName,
icon: category.icon,
order: Number(category.order),
brands: categoryBrands,
};
})
.filter((group) => group.brands.length > 0)
.sort((a, b) => Number(a.order) - Number(b.order));
}

export function getBrandCategoryGroupsForOutlet(outletId: string) {
const outletBrandList = getBrandsForOutlet(outletId);

return groupBrandsByCategory(outletBrandList);
}
