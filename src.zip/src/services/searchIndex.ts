import { brands } from "../constants/brands";
import { categories } from "../constants/categories";
import { cities } from "../constants/cities";
import { countries } from "../constants/countries";
import { outlets } from "../constants/outlets";
import { getCityName, getCountryName } from "./locationService";

export type SearchItemType = "outlet" | "brand" | "city" | "country" | "category";

export type SearchIndexItem = {
id: string;
title: string;
subtitle: string;
type: SearchItemType;
keywords: string[];
};

export function buildSearchIndex(): SearchIndexItem[] {
const outletItems: SearchIndexItem[] = outlets.map((outlet) => ({
id: outlet.outletId,
title: outlet.name,
subtitle: `${getCityName(outlet.cityId)}, ${getCountryName(outlet.countryId)}`,
type: "outlet",
keywords: [
outlet.name,
getCityName(outlet.cityId),
getCountryName(outlet.countryId),
outlet.countryId,
outlet.cityId,
],
}));

const brandItems: SearchIndexItem[] = brands
.filter((brand) => brand.brandStatus === "active")
.map((brand) => ({
id: brand.brandId,
title: brand.brandName,
subtitle: "Brand",
type: "brand",
keywords: [brand.brandName, brand.categoryId],
}));

const cityItems: SearchIndexItem[] = cities.map((city) => ({
id: city.cityId,
title: city.cityName,
subtitle: "City",
type: "city",
keywords: [city.cityName, city.countryId],
}));

const countryItems: SearchIndexItem[] = countries.map((country) => ({
id: country.countryId,
title: country.countryName,
subtitle: "Country",
type: "country",
keywords: [
country.countryName,
country.countryId,
country.currency,
country.continent,
],
}));

const categoryItems: SearchIndexItem[] = categories.map((category) => ({
id: category.categoryId,
title: category.categoryName,
subtitle: "Category",
type: "category",
keywords: [category.categoryName, category.categoryId],
}));

return [
...outletItems,
...brandItems,
...cityItems,
...countryItems,
...categoryItems,
];
}