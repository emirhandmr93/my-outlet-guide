export type CurrentWeather = {
temperature: number;
weatherCode: number;
condition: string;
icon: string;
};

function getWeatherCondition(weatherCode: number) {
if (weatherCode === 0) {
return { condition: "Clear", icon: "☀️" };
}

if ([1, 2, 3].includes(weatherCode)) {
return { condition: "Cloudy", icon: "⛅" };
}

if ([45, 48].includes(weatherCode)) {
return { condition: "Foggy", icon: "🌫️" };
}

if ([51, 53, 55, 61, 63, 65, 80, 81, 82].includes(weatherCode)) {
return { condition: "Rainy", icon: "🌧️" };
}

if ([71, 73, 75, 85, 86].includes(weatherCode)) {
return { condition: "Snowy", icon: "❄️" };
}

if ([95, 96, 99].includes(weatherCode)) {
return { condition: "Stormy", icon: "⛈️" };
}

return { condition: "Weather", icon: "🌤️" };
}

export async function getCurrentWeather(
latitude: number,
longitude: number
): Promise<CurrentWeather> {
const response = await fetch(
`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weather_code&timezone=auto`
);

const data = await response.json();

const temperature = Math.round(data.current.temperature_2m);
const weatherCode = data.current.weather_code;
const weatherInfo = getWeatherCondition(weatherCode);

return {
temperature,
weatherCode,
condition: weatherInfo.condition,
icon: weatherInfo.icon,
};
}