export type FlightProvider = {
providerId: string;
providerName: string;
providerType: "affiliate" | "api" | "manual" | "mock";
status: "active" | "inactive";
};

export type FlightAirport = {
airportId: string;
airportCode: string;
airportName: string;
cityId: string;
countryId: string;
status: "active" | "inactive";
};

export type FlightRoute = {
routeId: string;
originAirportId: string;
destinationCityId: string;
destinationAirportIds: string[];
status: "active" | "inactive";
};

export type FlightDeal = {
dealId: string;
providerId: string;
routeId: string;
airline: string;
routeText: string;
currentPrice: string;
lastUpdatedText: string;
flightDateText?: string;
dealLevel: "good" | "great" | "amazing";
status: "active" | "expired";
};

export type FlightPreference = {
userId: string;
departureAirportId: string;
selectedCityIds: string[];
selectedThresholds: Array<"good" | "great" | "amazing">;
maxBudget?: number;
currency?: string;
};

export type FlightNotification = {
notificationId: string;
userId: string;
dealId: string;
title: string;
message: string;
status: "pending" | "sent" | "dismissed";
createdAt: string;
};

const mockFlightProviders: FlightProvider[] = [
{
providerId: "mock",
providerName: "Mock Flight Data",
providerType: "mock",
status: "active",
},
];

const mockFlightAirports: FlightAirport[] = [
{
airportId: "esb",
airportCode: "ESB",
airportName: "Ankara Esenboğa Airport",
cityId: "ankara",
countryId: "turkey",
status: "active",
},
];

const mockFlightRoutes: FlightRoute[] = [
{
routeId: "esb-paris",
originAirportId: "esb",
destinationCityId: "paris",
destinationAirportIds: ["cdg", "ory", "bva"],
status: "active",
},
];

const mockFlightDeals: FlightDeal[] = [
{
dealId: "ankara-paris-wizz-001",
providerId: "mock",
routeId: "esb-paris",
airline: "Wizz Air",
routeText: "Ankara → Paris",
currentPrice: "5.900 TL",
lastUpdatedText: "10 min ago",
flightDateText: "Fri, 18 Oct • 14:20",
dealLevel: "great",
status: "active",
},
];

export function getActiveFlightDeals(): FlightDeal[] {
return mockFlightDeals.filter((deal) => deal.status === "active");
}

export function getPrimaryFlightDeal(): FlightDeal | null {
const activeDeals = getActiveFlightDeals();

return activeDeals[0] || null;
}