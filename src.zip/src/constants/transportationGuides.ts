export type TransportationType =
| "train"
| "metro"
| "bus"
| "shuttle"
| "taxi"
| "uber"
| "walking";

export type TransportationStep = {
order: number;
description: string;
};

export type TransportationGuide = {
guideId: string;
outletId: string;
originType: "city_center" | "airport" | "station";
originId: string;
transportationType: TransportationType;
title: string;
estimatedDuration: string;
estimatedCost: string;
recommended: boolean;
steps: TransportationStep[];
updatedAt: string;
};

export const transportationGuides: TransportationGuide[] = [
{
guideId: "paris-to-la-vallee-rer-a",
outletId: "la-vallee-village",
originType: "city_center",
originId: "paris-city-center",
transportationType: "train",
title: "Paris City Center to La Vallée Village by RER A",
estimatedDuration: "45-55 min",
estimatedCost: "€5-10",
recommended: true,
steps: [
{ order: 1, description: "Go to Châtelet–Les Halles, Auber, Charles de Gaulle–Étoile, Nation, or another central Paris RER A station." },
{ order: 2, description: "Take RER A towards Marne-la-Vallée Chessy." },
{ order: 3, description: "Get off at Val d'Europe station." },
{ order: 4, description: "Follow signs towards La Vallée Village / Centre Commercial Val d'Europe." },
{ order: 5, description: "Walk approximately 5 minutes to the outlet entrance." },
],
updatedAt: "2026-06-24",
},
{
guideId: "cdg-to-la-vallee-tgv",
outletId: "la-vallee-village",
originType: "airport",
originId: "charles-de-gaulle-airport",
transportationType: "train",
title: "Charles de Gaulle Airport to La Vallée Village",
estimatedDuration: "35-60 min",
estimatedCost: "€17-25",
recommended: false,
steps: [
{ order: 1, description: "From CDG Airport, go to the train station inside the airport." },
{ order: 2, description: "Take a TGV train to Marne-la-Vallée Chessy when available." },
{ order: 3, description: "From Marne-la-Vallée Chessy, continue towards Val d'Europe by train, taxi, or local transfer." },
{ order: 4, description: "Get off near Val d'Europe / La Vallée Village." },
{ order: 5, description: "Walk to the outlet entrance." },
],
updatedAt: "2026-06-24",
},
{
guideId: "orly-to-la-vallee-rer",
outletId: "la-vallee-village",
originType: "airport",
originId: "orly-airport",
transportationType: "train",
title: "Orly Airport to La Vallée Village",
estimatedDuration: "60-90 min",
estimatedCost: "€12-20",
recommended: false,
steps: [
{ order: 1, description: "From Orly Airport, take OrlyVal or another airport connection towards the RER network." },
{ order: 2, description: "Connect to central Paris and transfer to RER A." },
{ order: 3, description: "Take RER A towards Marne-la-Vallée Chessy." },
{ order: 4, description: "Get off at Val d'Europe station." },
{ order: 5, description: "Walk approximately 5 minutes to La Vallée Village." },
],
updatedAt: "2026-06-24",
},
{
guideId: "disneyland-to-la-vallee",
outletId: "la-vallee-village",
originType: "station",
originId: "disneyland-paris",
transportationType: "walking",
title: "Disneyland Paris to La Vallée Village",
estimatedDuration: "5-15 min",
estimatedCost: "€0-10",
recommended: false,
steps: [
{ order: 1, description: "Start from Disneyland Paris / Marne-la-Vallée Chessy area." },
{ order: 2, description: "Use a short local transfer, taxi, or train connection to Val d'Europe." },
{ order: 3, description: "If staying nearby, walking may also be possible depending on your hotel location." },
{ order: 4, description: "Follow signs to La Vallée Village." },
],
updatedAt: "2026-06-24",
},
{
guideId: "paris-to-la-vallee-taxi",
outletId: "la-vallee-village",
originType: "city_center",
originId: "paris-city-center",
transportationType: "taxi",
title: "Paris City Center to La Vallée Village by Taxi / Uber",
estimatedDuration: "35-60 min",
estimatedCost: "€70-120",
recommended: false,
steps: [
{ order: 1, description: "Open a taxi or ride-share app and set the destination as La Vallée Village, Serris." },
{ order: 2, description: "Check the estimated fare before confirming the ride." },
{ order: 3, description: "Travel directly to the outlet entrance." },
{ order: 4, description: "For the return trip, check availability before closing time." },
],
updatedAt: "2026-06-24",
},
];
