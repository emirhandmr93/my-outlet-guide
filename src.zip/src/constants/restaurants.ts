export const restaurants = [
  {
    "restaurantId": "art-cafe",
    "outletId": "la-vallee-village",
    "restaurantName": "Art Café",
    "category": "Cafe",
    "priceLevel": "€€",
    "website": "https://",
    "status": "active",
    "displayOrder": "1"
  },
  {
    "restaurantId": "wild-and-the-moon",
    "outletId": "la-vallee-village",
    "restaurantName": "Wild & The Moon",
    "category": "Healthy",
    "priceLevel": "€€",
    "website": "https://",
    "status": "active",
    "displayOrder": "2"
  },
  {
    "restaurantId": "amorino",
    "outletId": "la-vallee-village",
    "restaurantName": "Amorino",
    "category": "Ice Cream",
    "priceLevel": "€",
    "website": "https://",
    "status": "active",
    "displayOrder": "3"
  },
  {
    "restaurantId": "laduree",
    "outletId": "la-vallee-village",
    "restaurantName": "Ladurée",
    "category": "Desserts",
    "priceLevel": "€€€",
    "website": "https://",
    "status": "active",
    "displayOrder": "4"
  },
  {
    "restaurantId": "momus",
    "outletId": "la-vallee-village",
    "restaurantName": "Momus",
    "category": "Restaurant",
    "priceLevel": "€€€",
    "website": "https://",
    "status": "active",
    "displayOrder": "5"
  },
  {
    "restaurantId": "pierre-herme",
    "outletId": "la-vallee-village",
    "restaurantName": "Pierre Hermé Paris",
    "category": "Desserts",
    "priceLevel": "€€€",
    "website": "https://",
    "status": "active",
    "displayOrder": "6"
  }
];
