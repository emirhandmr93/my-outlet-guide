export const outlets = [
  {
    "outletId": "la-vallee-village",
    "name": "La Vallée Village",
    "slug": "la-vallee-village",
    "countryId": "france",
    "cityId": "paris",
    "address": "3 Cours de la Garonne, 77700 Serris, France",
    "latitude": 48.8556,
    "longitude": 2.7832,
    "openingHours": "10:00 - 20:00",
    "heroImage": "",
    "galleryImages": [],
    "storesCountText": "110+ Stores",
    "rating": 4.6,
    "reviewCount": 0,
    "services": [
      "Parking",
      "Tax Free",
      "Restaurants & Cafes",
      "Shuttle",
      "Guest Services"
    ],
    "restaurants": [
      "Art Café",
      "Wild & The Moon",
      "Amorino",
      "Ladurée",
      "Momus",
      "Pierre Hermé Paris"
    ],
    "taxFreeAvailable": true,
    "vatRate": 20,
    "minimumTaxFreeSpend": "100.01 EUR",
    "taxFreeOfficeInfo": "Ask for a tax refund form directly in participating boutiques when your purchase is over €100. The form must be validated at customs or a PABLO kiosk when leaving the EU.",
    "cityCenterDistanceKm": 40,
    "airportDistanceKm": 35,
    "websiteUrl": "https://www.thebicestercollection.com/la-vallee-village/en",
    "status": "active",
    "googleMapsUrl": "https://maps.google.com/?q=La+Vallee+Village",
    "appleMapsUrl": "http://maps.apple.com/?q=La+Vallee+Village",
    "yandexMapsUrl": "https://yandex.com/maps/?text=La%20Vallee%20Village"
  }
];
