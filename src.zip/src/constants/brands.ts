export type BrandStatus = "active" | "inactive" | "coming-soon" | "discontinued";

export type BrandLuxuryLevel = "luxury" | "premium" | "fashion" | "sports" | "lifestyle";

export type Brand = {
 brandId: string;
 brandName: string;
 aliases: string[];
 categoryId: string;
 logo: string;
 website?: string;
 originCountryId?: string;
 luxuryLevel?: BrandLuxuryLevel | string;
 description?: string;
 rankingWeight: number;
 brandStatus: BrandStatus | string;
};

export const brands: Brand[] = [
  {
    "brandId": "sephora",
    "brandName": "Sephora",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "guerlain",
    "brandName": "Guerlain",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 92,
    "brandStatus": "active"
  },
  {
    "brandId": "clarins",
    "brandName": "Clarins",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "estee-lauder",
    "brandName": "Estée Lauder",
    "aliases": [
      "estee lauder"
    ],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "loccitane",
    "brandName": "L'Occitane",
    "aliases": [
      "loccitane",
      "l occitane"
    ],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "loreal-paris",
    "brandName": "L'Oréal Paris",
    "aliases": [
      "loreal",
      "l oreal"
    ],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "lancome",
    "brandName": "Lancôme",
    "aliases": [
      "lancome"
    ],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "mac-cosmetics",
    "brandName": "MAC Cosmetics",
    "aliases": [
      "mac"
    ],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "shiseido",
    "brandName": "Shiseido",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "premium",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "clinique",
    "brandName": "Clinique",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "diptyque",
    "brandName": "Diptyque",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "kiehls",
    "brandName": "Kiehl's",
    "aliases": [
      "kiehls"
    ],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "byredo",
    "brandName": "BYREDO",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "sweden",
    "luxuryLevel": "premium",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "rituals",
    "brandName": "Rituals",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "netherlands",
    "luxuryLevel": "premium",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "the-body-shop",
    "brandName": "The Body Shop",
    "aliases": [
      "body shop"
    ],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "yves-rocher",
    "brandName": "Yves Rocher",
    "aliases": [],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "beaute-prestige-international",
    "brandName": "Beauté Prestige International",
    "aliases": [
      "bpi",
      "beaute prestige international"
    ],
    "categoryId": "beauty",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 55,
    "brandStatus": "active"
  },
  {
    "brandId": "polo-ralph-lauren",
    "brandName": "Polo Ralph Lauren",
    "aliases": [
      "ralph lauren",
      "polo"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "boss",
    "brandName": "BOSS",
    "aliases": [
      "hugo boss",
      "boss"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "calvin-klein",
    "brandName": "Calvin Klein",
    "aliases": [
      "ck"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "fashion",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "lacoste",
    "brandName": "Lacoste",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "levis",
    "brandName": "Levi's",
    "aliases": [
      "levis",
      "levi strauss"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "fashion",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "tommy-hilfiger",
    "brandName": "Tommy Hilfiger",
    "aliases": [
      "tommy"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "fashion",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "uniqlo",
    "brandName": "Uniqlo",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "off-white",
    "brandName": "Off-White",
    "aliases": [
      "off white"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "armani-exchange",
    "brandName": "Armani Exchange",
    "aliases": [
      "a|x",
      "ax"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "fashion",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "moschino",
    "brandName": "Moschino",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "tommy-jeans",
    "brandName": "Tommy Jeans",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "fashion",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "a-bathing-ape",
    "brandName": "A Bathing Ape",
    "aliases": [
      "bape"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "fashion",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "diesel",
    "brandName": "Diesel",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "fashion",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "guess",
    "brandName": "Guess",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "fashion",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "hugo",
    "brandName": "HUGO",
    "aliases": [
      "hugo boss"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "fashion",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "karl-lagerfeld",
    "brandName": "KARL LAGERFELD",
    "aliases": [
      "karl"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "kenzo",
    "brandName": "Kenzo",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "max-mara",
    "brandName": "Max Mara",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "dsquared2",
    "brandName": "Dsquared2",
    "aliases": [
      "dsquared"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 78,
    "brandStatus": "active"
  },
  {
    "brandId": "g-star-raw",
    "brandName": "G-Star RAW",
    "aliases": [
      "g-star",
      "g star"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "netherlands",
    "luxuryLevel": "fashion",
    "rankingWeight": 78,
    "brandStatus": "active"
  },
  {
    "brandId": "gant",
    "brandName": "GANT",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "fashion",
    "rankingWeight": 78,
    "brandStatus": "active"
  },
  {
    "brandId": "superdry",
    "brandName": "Superdry",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "fashion",
    "rankingWeight": 78,
    "brandStatus": "active"
  },
  {
    "brandId": "ami-paris",
    "brandName": "Ami Paris",
    "aliases": [
      "ami"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "fred-perry",
    "brandName": "Fred Perry",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "fashion",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "isabel-marant",
    "brandName": "Isabel Marant",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "maje",
    "brandName": "Maje",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "marni",
    "brandName": "Marni",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "fashion",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "massimo-dutti",
    "brandName": "Massimo Dutti",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "spain",
    "luxuryLevel": "fashion",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "sandro",
    "brandName": "Sandro",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "liu-jo",
    "brandName": "Liu Jo",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "fashion",
    "rankingWeight": 72,
    "brandStatus": "active"
  },
  {
    "brandId": "napapijri",
    "brandName": "Napapijri",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 72,
    "brandStatus": "active"
  },
  {
    "brandId": "replay",
    "brandName": "Replay",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "fashion",
    "rankingWeight": 72,
    "brandStatus": "active"
  },
  {
    "brandId": "ted-baker",
    "brandName": "Ted Baker",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "fashion",
    "rankingWeight": 72,
    "brandStatus": "active"
  },
  {
    "brandId": "acne-studios",
    "brandName": "Acne Studios",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "sweden",
    "luxuryLevel": "fashion",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "evisu",
    "brandName": "Evisu",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "fashion",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "marc-opolo",
    "brandName": "Marc O'Polo",
    "aliases": [
      "marc opolo"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "fashion",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "mlb-korea",
    "brandName": "MLB Korea",
    "aliases": [
      "mlb"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "south-korea",
    "luxuryLevel": "fashion",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "scotch-and-soda",
    "brandName": "Scotch & Soda",
    "aliases": [
      "scotch and soda"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "netherlands",
    "luxuryLevel": "fashion",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "the-kooples",
    "brandName": "The Kooples",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "zadig-and-voltaire",
    "brandName": "Zadig & Voltaire",
    "aliases": [
      "zadig"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "bash",
    "brandName": "ba&sh",
    "aliases": [
      "bash"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 65,
    "brandStatus": "active"
  },
  {
    "brandId": "k-way",
    "brandName": "K-Way",
    "aliases": [
      "kway"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 65,
    "brandStatus": "active"
  },
  {
    "brandId": "anne-fontaine",
    "brandName": "Anne Fontaine",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 60,
    "brandStatus": "active"
  },
  {
    "brandId": "bompard",
    "brandName": "Bompard",
    "aliases": [
      "eric bompard"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 60,
    "brandStatus": "active"
  },
  {
    "brandId": "claudie-pierlot",
    "brandName": "Claudie Pierlot",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 60,
    "brandStatus": "active"
  },
  {
    "brandId": "fusalp",
    "brandName": "Fusalp",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 60,
    "brandStatus": "active"
  },
  {
    "brandId": "hackett-london",
    "brandName": "Hackett London",
    "aliases": [
      "hackett"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "fashion",
    "rankingWeight": 60,
    "brandStatus": "active"
  },
  {
    "brandId": "berenice",
    "brandName": "Berenice",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 55,
    "brandStatus": "active"
  },
  {
    "brandId": "charles-tyrwhitt",
    "brandName": "Charles Tyrwhitt",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "fashion",
    "rankingWeight": 55,
    "brandStatus": "active"
  },
  {
    "brandId": "gerard-darel",
    "brandName": "Gerard Darel",
    "aliases": [
      "gérard darel"
    ],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 55,
    "brandStatus": "active"
  },
  {
    "brandId": "ikks",
    "brandName": "IKKS",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 55,
    "brandStatus": "active"
  },
  {
    "brandId": "figaret",
    "brandName": "Figaret",
    "aliases": [],
    "categoryId": "fashion",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "fashion",
    "rankingWeight": 50,
    "brandStatus": "active"
  },
  {
    "brandId": "lindt",
    "brandName": "Lindt",
    "aliases": [],
    "categoryId": "food-chocolate",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "haribo",
    "brandName": "Haribo",
    "aliases": [],
    "categoryId": "food-chocolate",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "laduree",
    "brandName": "Ladurée",
    "aliases": [
      "laduree"
    ],
    "categoryId": "food-chocolate",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "pierre-herme-paris",
    "brandName": "Pierre Hermé Paris",
    "aliases": [
      "pierre herme"
    ],
    "categoryId": "food-chocolate",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "venchi",
    "brandName": "Venchi",
    "aliases": [],
    "categoryId": "food-chocolate",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "bose",
    "brandName": "Bose",
    "aliases": [],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "le-creuset",
    "brandName": "Le Creuset",
    "aliases": [],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "muji",
    "brandName": "Muji",
    "aliases": [
      "mujirushi"
    ],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "baccarat",
    "brandName": "Baccarat",
    "aliases": [],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "tefal",
    "brandName": "Tefal",
    "aliases": [],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "villeroy-and-boch",
    "brandName": "Villeroy & Boch",
    "aliases": [
      "villeroy boch"
    ],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "premium",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "zwilling",
    "brandName": "Zwilling",
    "aliases": [],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "premium",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "wmf",
    "brandName": "WMF",
    "aliases": [],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "premium",
    "rankingWeight": 78,
    "brandStatus": "active"
  },
  {
    "brandId": "fissler",
    "brandName": "Fissler",
    "aliases": [],
    "categoryId": "home-lifestyle",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "premium",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "rolex",
    "brandName": "Rolex",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "luxury",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "omega",
    "brandName": "Omega",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "breitling",
    "brandName": "Breitling",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "luxury",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "pandora",
    "brandName": "Pandora",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "denmark",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "swarovski",
    "brandName": "Swarovski",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "austria",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "tag-heuer",
    "brandName": "TAG Heuer",
    "aliases": [
      "tag heuer"
    ],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "luxury",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "longines",
    "brandName": "Longines",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "luxury",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "montblanc",
    "brandName": "Montblanc",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "seiko",
    "brandName": "Seiko",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "swatch",
    "brandName": "Swatch",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "tissot",
    "brandName": "Tissot",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "citizen",
    "brandName": "Citizen",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "premium",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "fossil",
    "brandName": "Fossil",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "hour-passion",
    "brandName": "Hour Passion",
    "aliases": [],
    "categoryId": "jewelry-watches",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "premium",
    "rankingWeight": 65,
    "brandStatus": "active"
  },
  {
    "brandId": "lego",
    "brandName": "Lego",
    "aliases": [
      "lego"
    ],
    "categoryId": "kids",
    "logo": "",
    "originCountryId": "denmark",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "disney-store",
    "brandName": "Disney Store",
    "aliases": [
      "disney"
    ],
    "categoryId": "kids",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "petit-bateau",
    "brandName": "Petit Bateau",
    "aliases": [],
    "categoryId": "kids",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "chicco",
    "brandName": "Chicco",
    "aliases": [],
    "categoryId": "kids",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "mayoral",
    "brandName": "Mayoral",
    "aliases": [],
    "categoryId": "kids",
    "logo": "",
    "originCountryId": "spain",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 70,
    "brandStatus": "active"
  },
  {
    "brandId": "bonpoint",
    "brandName": "Bonpoint",
    "aliases": [],
    "categoryId": "kids",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 65,
    "brandStatus": "active"
  },
  {
    "brandId": "jacadi",
    "brandName": "Jacadi",
    "aliases": [],
    "categoryId": "kids",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 65,
    "brandStatus": "active"
  },
  {
    "brandId": "kids-around",
    "brandName": "Kids around",
    "aliases": [
      "kids around"
    ],
    "categoryId": "kids",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 55,
    "brandStatus": "active"
  },
  {
    "brandId": "dior",
    "brandName": "Dior",
    "aliases": [
      "christian dior"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "gucci",
    "brandName": "Gucci",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "hermes",
    "brandName": "Hermès",
    "aliases": [
      "hermes"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "louis-vuitton",
    "brandName": "Louis Vuitton",
    "aliases": [
      "lv"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "prada",
    "brandName": "Prada",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "saint-laurent",
    "brandName": "Saint Laurent",
    "aliases": [
      "ysl",
      "yves saint laurent"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "balenciaga",
    "brandName": "Balenciaga",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "bottega-veneta",
    "brandName": "Bottega Veneta",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "burberry",
    "brandName": "Burberry",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "celine",
    "brandName": "Celine",
    "aliases": [
      "céline"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "dolce-and-gabbana",
    "brandName": "Dolce & Gabbana",
    "aliases": [
      "dolce gabbana",
      "d&g"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "fendi",
    "brandName": "Fendi",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "moncler",
    "brandName": "Moncler",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "valentino",
    "brandName": "Valentino",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "versace",
    "brandName": "Versace",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "armani",
    "brandName": "Armani",
    "aliases": [
      "giorgio armani"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "givenchy",
    "brandName": "Givenchy",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "loewe",
    "brandName": "Loewe",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "spain",
    "luxuryLevel": "luxury",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "miu-miu",
    "brandName": "Miu Miu",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "ferragamo",
    "brandName": "Ferragamo",
    "aliases": [
      "salvatore ferragamo"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "balmain",
    "brandName": "Balmain",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "chloe",
    "brandName": "Chloé",
    "aliases": [
      "chloe"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "emporio-armani",
    "brandName": "Emporio Armani",
    "aliases": [
      "ea"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "brunello-cucinelli",
    "brandName": "Brunello Cucinelli",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "etro",
    "brandName": "Etro",
    "aliases": [],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "zegna",
    "brandName": "Zegna",
    "aliases": [
      "ermenegildo zegna"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "rabanne",
    "brandName": "Rabanne",
    "aliases": [
      "paco rabanne"
    ],
    "categoryId": "luxury",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "christian-louboutin",
    "brandName": "Christian Louboutin",
    "aliases": [
      "louboutin"
    ],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "michael-kors",
    "brandName": "Michael Kors",
    "aliases": [
      "mk"
    ],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "jimmy-choo",
    "brandName": "Jimmy Choo",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "luxury",
    "rankingWeight": 94,
    "brandStatus": "active"
  },
  {
    "brandId": "birkenstock",
    "brandName": "BIRKENSTOCK",
    "aliases": [
      "birkenstock"
    ],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 92,
    "brandStatus": "active"
  },
  {
    "brandId": "coach",
    "brandName": "Coach",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 92,
    "brandStatus": "active"
  },
  {
    "brandId": "longchamp",
    "brandName": "Longchamp",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 92,
    "brandStatus": "active"
  },
  {
    "brandId": "golden-goose",
    "brandName": "Golden Goose",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "dr-martens",
    "brandName": "Dr. Martens",
    "aliases": [
      "dr martens",
      "doc martens"
    ],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "furla",
    "brandName": "Furla",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "timberland",
    "brandName": "Timberland",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "tods",
    "brandName": "Tod's",
    "aliases": [
      "tods"
    ],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "luxury",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "ugg",
    "brandName": "UGG",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 86,
    "brandStatus": "active"
  },
  {
    "brandId": "kate-spade",
    "brandName": "Kate Spade",
    "aliases": [
      "kate spade new york"
    ],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "samsonite",
    "brandName": "Samsonite",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "bally",
    "brandName": "Bally",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "luxury",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "clarks",
    "brandName": "Clarks",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "hogan",
    "brandName": "Hogan",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "mcm",
    "brandName": "MCM",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "premium",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "tumi",
    "brandName": "TUMI",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "premium",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "churchs",
    "brandName": "Church's",
    "aliases": [
      "churchs"
    ],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "united-kingdom",
    "luxuryLevel": "luxury",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "geox",
    "brandName": "Geox",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "axel-arigato",
    "brandName": "Axel Arigato",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "sweden",
    "luxuryLevel": "premium",
    "rankingWeight": 78,
    "brandStatus": "active"
  },
  {
    "brandId": "camper",
    "brandName": "Camper",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "spain",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "coccinelle",
    "brandName": "Coccinelle",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "premium",
    "rankingWeight": 72,
    "brandStatus": "active"
  },
  {
    "brandId": "jm-weston",
    "brandName": "J.M. Weston",
    "aliases": [
      "jm weston"
    ],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "luxury",
    "rankingWeight": 72,
    "brandStatus": "active"
  },
  {
    "brandId": "claris-virot",
    "brandName": "Claris Virot",
    "aliases": [],
    "categoryId": "shoes-bags",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "premium",
    "rankingWeight": 60,
    "brandStatus": "active"
  },
  {
    "brandId": "adidas",
    "brandName": "Adidas",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "sports",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "nike",
    "brandName": "Nike",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "sports",
    "rankingWeight": 100,
    "brandStatus": "active"
  },
  {
    "brandId": "new-balance",
    "brandName": "New Balance",
    "aliases": [
      "nb"
    ],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "sports",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "puma",
    "brandName": "Puma",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "germany",
    "luxuryLevel": "sports",
    "rankingWeight": 95,
    "brandStatus": "active"
  },
  {
    "brandId": "the-north-face",
    "brandName": "The North Face",
    "aliases": [
      "north face",
      "tnf"
    ],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "sports",
    "rankingWeight": 92,
    "brandStatus": "active"
  },
  {
    "brandId": "converse",
    "brandName": "Converse",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "sports",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "vans",
    "brandName": "Vans",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 90,
    "brandStatus": "active"
  },
  {
    "brandId": "lululemon",
    "brandName": "lululemon",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "canada",
    "luxuryLevel": "premium",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "skechers",
    "brandName": "Skechers",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "lifestyle",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "under-armour",
    "brandName": "Under Armour",
    "aliases": [
      "ua"
    ],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "sports",
    "rankingWeight": 88,
    "brandStatus": "active"
  },
  {
    "brandId": "on",
    "brandName": "On",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "switzerland",
    "luxuryLevel": "premium",
    "rankingWeight": 86,
    "brandStatus": "active"
  },
  {
    "brandId": "asics",
    "brandName": "ASICS",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "sports",
    "rankingWeight": 85,
    "brandStatus": "active"
  },
  {
    "brandId": "fila",
    "brandName": "Fila",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "italy",
    "luxuryLevel": "sports",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "hoka",
    "brandName": "HOKA",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "sports",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "onitsuka-tiger",
    "brandName": "Onitsuka Tiger",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "sports",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "salomon",
    "brandName": "Salomon",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "france",
    "luxuryLevel": "sports",
    "rankingWeight": 82,
    "brandStatus": "active"
  },
  {
    "brandId": "columbia",
    "brandName": "Columbia",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "sports",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "mizuno",
    "brandName": "Mizuno",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "sports",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "reebok",
    "brandName": "Reebok",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "united-states",
    "luxuryLevel": "sports",
    "rankingWeight": 80,
    "brandStatus": "active"
  },
  {
    "brandId": "anta",
    "brandName": "Anta",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "china",
    "luxuryLevel": "sports",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "li-ning",
    "brandName": "Li-Ning",
    "aliases": [
      "lining"
    ],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "china",
    "luxuryLevel": "sports",
    "rankingWeight": 75,
    "brandStatus": "active"
  },
  {
    "brandId": "descente",
    "brandName": "Descente",
    "aliases": [],
    "categoryId": "sportswear",
    "logo": "",
    "originCountryId": "japan",
    "luxuryLevel": "sports",
    "rankingWeight": 72,
    "brandStatus": "active"
  }
];
