export const transportation = [
  {
    "transportationId": "la-vallee-metro",
    "outletId": "la-vallee-village",
    "transportType": "metro",
    "title": "Metro / Train",
    "duration": "40 min",
    "cost": "€2.50",
    "tip": "Use public transportation whenever possible.",
    "status": "active",
    "displayOrder": "1"
  },
  {
    "transportationId": "la-vallee-shuttle",
    "outletId": "la-vallee-village",
    "transportType": "shuttle",
    "title": "Shuttle Bus",
    "duration": "50 min",
    "cost": "€10",
    "tip": "Reservation may be required.",
    "status": "active",
    "displayOrder": "2"
  }
];
