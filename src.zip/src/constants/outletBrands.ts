export type OutletBrand = {
 outletId: string;
 brandId: string;
 featured: boolean;
 relationStatus: string;
};

export const outletBrands: OutletBrand[] = [
  {
    "outletId": "la-vallee-village",
    "brandId": "armani",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "balenciaga",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "balmain",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "brunello-cucinelli",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "burberry",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "chloe",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "christian-louboutin",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "dolce-and-gabbana",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "fendi",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "ferragamo",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "givenchy",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "gucci",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "jimmy-choo",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "kenzo",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "loewe",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "marni",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "moncler",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "prada",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "rabanne",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "saint-laurent",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "valentino",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "versace",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "zegna",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "acne-studios",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "ami-paris",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "anne-fontaine",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "bash",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "berenice",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "bompard",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "bonpoint",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "boss",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "calvin-klein",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "charles-tyrwhitt",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "claudie-pierlot",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "diesel",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "figaret",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "fred-perry",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "fusalp",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "gerard-darel",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "guess",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "hackett-london",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "ikks",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "isabel-marant",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "k-way",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "karl-lagerfeld",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "lacoste",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "levis",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "maje",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "max-mara",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "polo-ralph-lauren",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "sandro",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "the-kooples",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "tommy-hilfiger",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "zadig-and-voltaire",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "adidas",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "asics",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "lululemon",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "new-balance",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "nike",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "on",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "puma",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "axel-arigato",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "birkenstock",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "churchs",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "claris-virot",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "coach",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "furla",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "golden-goose",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "hogan",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "jm-weston",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "kate-spade",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "longchamp",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "michael-kors",
    "featured": true,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "samsonite",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "tods",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "tumi",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "beaute-prestige-international",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "byredo",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "clarins",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "diptyque",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "guerlain",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "loccitane",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "hour-passion",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "swarovski",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "baccarat",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "laduree",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "pierre-herme-paris",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "kids-around",
    "featured": false,
    "relationStatus": "active"
  },
  {
    "outletId": "la-vallee-village",
    "brandId": "petit-bateau",
    "featured": false,
    "relationStatus": "active"
  }
];
