export const countries = [
  {
    "countryId": "austria",
    "countryName": "Austria",
    "countryFlag": "🇦🇹",
    "continent": "Europe",
    "currency": "EUR",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "canada",
    "countryName": "Canada",
    "countryFlag": "🇨🇦",
    "continent": "North America",
    "currency": "CAD",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "china",
    "countryName": "China",
    "countryFlag": "🇨🇳",
    "continent": "Asia",
    "currency": "CNY",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "denmark",
    "countryName": "Denmark",
    "countryFlag": "🇩🇰",
    "continent": "Europe",
    "currency": "DKK",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "france",
    "countryName": "France",
    "countryFlag": "🇫🇷",
    "continent": "Europe",
    "currency": "EUR",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "germany",
    "countryName": "Germany",
    "countryFlag": "🇩🇪",
    "continent": "Europe",
    "currency": "EUR",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "italy",
    "countryName": "Italy",
    "countryFlag": "🇮🇹",
    "continent": "Europe",
    "currency": "EUR",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "japan",
    "countryName": "Japan",
    "countryFlag": "🇯🇵",
    "continent": "Asia",
    "currency": "JPY",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "netherlands",
    "countryName": "Netherlands",
    "countryFlag": "🇳🇱",
    "continent": "Europe",
    "currency": "EUR",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "south-korea",
    "countryName": "South Korea",
    "countryFlag": "🇰🇷",
    "continent": "Asia",
    "currency": "KRW",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "spain",
    "countryName": "Spain",
    "countryFlag": "🇪🇸",
    "continent": "Europe",
    "currency": "EUR",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "sweden",
    "countryName": "Sweden",
    "countryFlag": "🇸🇪",
    "continent": "Europe",
    "currency": "SEK",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "switzerland",
    "countryName": "Switzerland",
    "countryFlag": "🇨🇭",
    "continent": "Europe",
    "currency": "CHF",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "thailand",
    "countryName": "Thailand",
    "countryFlag": "🇹🇭",
    "continent": "Asia",
    "currency": "THB",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "united-arab-emirates",
    "countryName": "United Arab Emirates",
    "countryFlag": "🇦🇪",
    "continent": "Asia",
    "currency": "AED",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "united-kingdom",
    "countryName": "United Kingdom",
    "countryFlag": "🇬🇧",
    "continent": "Europe",
    "currency": "GBP",
    "taxFreeAvailable": "TRUE"
  },
  {
    "countryId": "united-states",
    "countryName": "United States",
    "countryFlag": "🇺🇸",
    "continent": "North America",
    "currency": "USD",
    "taxFreeAvailable": "FALSE"
  }
];
