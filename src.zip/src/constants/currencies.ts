export type Currency = {
currencyCode: string;
currencyName: string;
symbol: string;
};

export const currencies: Currency[] = [
{ currencyCode: "EUR", currencyName: "Euro", symbol: "€" },
{ currencyCode: "TRY", currencyName: "Turkish Lira", symbol: "₺" },
{ currencyCode: "USD", currencyName: "US Dollar", symbol: "$" },
{ currencyCode: "GBP", currencyName: "British Pound", symbol: "£" },
{ currencyCode: "CHF", currencyName: "Swiss Franc", symbol: "CHF" },
{ currencyCode: "AED", currencyName: "UAE Dirham", symbol: "د.إ" },
{ currencyCode: "KRW", currencyName: "South Korean Won", symbol: "₩" },
{ currencyCode: "JPY", currencyName: "Japanese Yen", symbol: "¥" },
{ currencyCode: "CNY", currencyName: "Chinese Yuan", symbol: "¥" },
{ currencyCode: "RUB", currencyName: "Russian Ruble", symbol: "₽" },
{ currencyCode: "THB", currencyName: "Thai Baht", symbol: "฿" },
{ currencyCode: "SAR", currencyName: "Saudi Riyal", symbol: "﷼" },
];