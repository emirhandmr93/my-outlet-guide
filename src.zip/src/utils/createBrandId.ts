export function createBrandId(brandName: string) {
return brandName
.trim()
.toLowerCase()
.replace(/&/g, "and")
.replace(/'/g, "")
.replace(/\./g, "")
.replace(/[^a-z0-9]+/g, "-")
.replace(/^-+|-+$/g, "");
}