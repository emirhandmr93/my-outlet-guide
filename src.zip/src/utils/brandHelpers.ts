import { Brand } from "../constants/brands";

export function getBrandById(
brands: Brand[],
brandId: string
) {
return brands.find((brand) => brand.brandId === brandId);
}

export function getBrandsByCategory(
brands: Brand[],
categoryId: string
) {
return brands.filter(
(brand) => brand.categoryId === categoryId
);
}

export function getActiveBrands(
brands: Brand[]
) {
return brands.filter(
(brand) => brand.active
);
}