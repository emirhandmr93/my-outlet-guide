export const colors = {
primary: "#0B1F3A",
gold: "#C9A227",

background: "#F7F8FA",
surface: "#FFFFFF",
surfaceSoft: "#F7F8FA",
warningSoft: "#FFF8E1",

textPrimary: "#0B1F3A",
textSecondary: "#666666",
textMuted: "#999999",
textInverse: "#FFFFFF",

border: "#E5E7EB",

success: "#16A34A",
danger: "#DC2626",
info: "#2563EB",
};