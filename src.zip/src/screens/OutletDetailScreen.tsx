import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { useReviews } from "../contexts/ReviewsContext";
import { useTranslation } from "../hooks/useTranslation";
import { useReviewHelpful } from "../contexts/ReviewHelpfulContext";
import { useEffect, useState } from "react";
import { useUser } from "../contexts/UserContext";
import { requireAuth } from "../utils/requireAuth";
import { getBrandCategoryGroupsForOutlet } from "src/services/brandService";
import { getTransportationForOutlet } from "src/services/transportationService";
import { getRestaurantsForOutlet } from "../services/restaurantService";
import { ServicesCard } from "../components/cards/ServicesCard";
import { RestaurantsCard } from "../components/cards/RestaurantsCard";
import { TransportationCard } from "../components/cards/TransportationCard";
import { WebsiteCard } from "../components/cards/WebsiteCard";
import { MapsCard } from "../components/cards/MapsCard";
import { TaxFreeCard } from "../components/cards/TaxFreeCard";
import { QuickFactsCard } from "../components/cards/QuickFactsCard";
import { OutletBadges } from "../components/OutletBadges";
import { OutletHero } from "../components/OutletHero";
import { BrandsCard } from "../components/cards/BrandsCard";
import { ReviewStatsCard } from "../components/cards/ReviewStatsCard";
import { ReviewTabs } from "../components/ReviewTabs";
import { WriteReviewButton } from "../components/WriteReviewButton";
import { ReviewItem } from "../components/ReviewItem";


import {
getCurrentWeather,
CurrentWeather,
} from "../services/weatherService";

import {
FlatList,
Image,
Linking,
Modal,
ScrollView,
StyleSheet,
Text,
TextInput,
TouchableOpacity,
View,
Dimensions,
} from "react-native";

import { outlets } from "../constants/outlets";
import { useFavorites } from "../contexts/FavoritesContext";
const screenWidth = Dimensions.get("window").width;
const screenHeight = Dimensions.get("window").height;

type RouteParams = {
OutletDetail: {
outletId: string;
};
};

const cityNames: Record<string, string> = {
paris: "Paris",
milan: "Milan",
london: "London",
};

const countryNames: Record<string, string> = {
france: "France",
italy: "Italy",
"united-kingdom": "United Kingdom",
};

function getReviewAverage(review: any) {
return (
(
review.overallRating +
review.transportationRating +
review.brandVarietyRating +
review.restaurantsRating +
review.servicesRating
) / 5
).toFixed(1);
}

export function OutletDetailScreen() {
const route = useRoute<RouteProp<RouteParams, "OutletDetail">>();
const navigation = useNavigation<any>();
const { isLoggedIn } = useUser();
const { t } = useTranslation();
const { reviews } = useReviews();
const { currentUser } = useUser();
const outlet =
outlets.find((item) => item.outletId === route.params?.outletId) ||
outlets[0];
const brandCategoryGroups = getBrandCategoryGroupsForOutlet(outlet.outletId);
const transportationItems = getTransportationForOutlet(outlet.outletId);
const restaurantItems = getRestaurantsForOutlet(outlet.outletId);
const [weather, setWeather] = useState<CurrentWeather | null>(null);
const [weatherError, setWeatherError] = useState(false);
const [weatherLoading, setWeatherLoading] = useState(true);

useEffect(() => {
async function loadWeather() {
try {
setWeatherLoading(true);
setWeatherError(false);

const result = await getCurrentWeather(
Number(outlet.latitude),
Number(outlet.longitude)
);

setWeather(result);
} catch (error) {
console.log("Weather load error", error);
setWeatherError(true);
} finally {
setWeatherLoading(false);
}
}

loadWeather();
}, [outlet.latitude, outlet.longitude]);

const { toggleFavorite, isFavorite } = useFavorites();
const favorite = isFavorite(outlet.outletId);
const {toggleHelpful, getHelpfulItem } = useReviewHelpful();
const [reviewSort, setReviewSort] = useState<"helpful" | "recent">("helpful");
const [selectedImage, setSelectedImage] = useState(outlet.heroImage);
const [isGalleryOpen, setIsGalleryOpen]= useState(false);
const [brandSearch, setBrandSearch] = useState("");
const [openCategory, setOpenCategory] = useState<string | null>(null);
const [openTransportation, setOpenTransportation] = useState<string | null>(null);
const outletReviews = reviews.filter(
(review) => review.outletId === outlet.outletId
);

const averageRating =
outletReviews.length > 0
? (
outletReviews.reduce(
(sum, review) => sum + Number(getReviewAverage(review)),
0
) / outletReviews.length
).toFixed(1)
: "0.0";

const averageTransportationRating =
outletReviews.length > 0
? (
outletReviews.reduce(
(sum, review) => sum + review.transportationRating,
0
) / outletReviews.length
).toFixed(1)
: "0.0";

const averageBrandVarietyRating =
outletReviews.length > 0
? (
outletReviews.reduce(
(sum, review) => sum + review.brandVarietyRating,
0
) / outletReviews.length
).toFixed(1)
: "0.0";

const averageRestaurantsRating =
outletReviews.length > 0
? (
outletReviews.reduce(
(sum, review) => sum + review.restaurantsRating,
0
) / outletReviews.length
).toFixed(1)
: "0.0";

const averageServicesRating =
outletReviews.length > 0
? (
outletReviews.reduce(
(sum, review) => sum + review.servicesRating,
0
) / outletReviews.length
).toFixed(1)
: "0.0";

const currentUserReview = outletReviews.find(
(review) => review.userId === currentUser?.userId
);
const sortedReviews = [...outletReviews].sort((a, b) => {
if (reviewSort === "recent") {
return (
new Date(b.createdAt).getTime() -
new Date(a.createdAt).getTime()
);
}

return (
getHelpfulItem(b.reviewId).helpfulCount -
getHelpfulItem(a.reviewId).helpfulCount
);
});

const currentGalleryIndex = (outlet.galleryImages as string[]).indexOf(selectedImage as string);

function showPreviousImage() {
if (currentGalleryIndex <= 0) {
setSelectedImage(outlet.galleryImages[outlet.galleryImages.length - 1]);
return;
}

setSelectedImage(outlet.galleryImages[currentGalleryIndex - 1]);
}

function showNextImage() {
if (currentGalleryIndex === outlet.galleryImages.length - 1) {
setSelectedImage(outlet.galleryImages[0]);
return;
}

setSelectedImage(outlet.galleryImages[currentGalleryIndex + 1]);
}

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
{/*
<OutletHero
name={outlet.name}
location={`${cityNames[outlet.cityId]}, ${countryNames[outlet.countryId]}`}
selectedImage={selectedImage}
galleryImages={outlet.galleryImages}
favoriteButtonText={
favorite
? t("outlet.removeFavorite")
: t("outlet.addFavorite")
}
onPressHeroImage={() => setIsGalleryOpen(true)}
onPressGalleryImage={setSelectedImage}
onPressFavorite={() => {
if (
!requireAuth({
isLoggedIn,
navigation,
})
) {
return;
}

toggleFavorite(outlet.outletId);
}}
/>
*/}

<Modal visible={isGalleryOpen} animationType="fade">
<View style={styles.galleryModal}>
<TouchableOpacity
style={styles.galleryCloseButton}
onPress={() => setIsGalleryOpen(false)}
>
<Text style={styles.galleryCloseText}>Close</Text>
</TouchableOpacity>

<View style={styles.galleryModalImageWrapper}>
<TouchableOpacity
style={styles.galleryArrowLeft}
onPress={showPreviousImage}
>
<Text style={styles.galleryArrowText}>‹</Text>
</TouchableOpacity>

<ScrollView
style={styles.galleryZoomScroll}
contentContainerStyle={styles.galleryZoomContent}
maximumZoomScale={3}
minimumZoomScale={1}
showsHorizontalScrollIndicator={false}
showsVerticalScrollIndicator={false}
>
<Image
source={{ uri: selectedImage }}
style={styles.galleryModalImage}
resizeMode="contain"
/>
</ScrollView>

<TouchableOpacity
style={styles.galleryArrowRight}
onPress={showNextImage}
>
<Text style={styles.galleryArrowText}>›</Text>
</TouchableOpacity>
</View>
</View>
</Modal>

{/*
<OutletBadges
taxFreeText={
outlet.taxFreeAvailable
? t("outlet.taxFree")
: t("outlet.limitedTaxFree")
}
status={outlet.status}
rating={outlet.rating}
/>
*/}

{/*
<QuickFactsCard
title={t("outlet.quickFacts")}
weather={weather}
weatherLoading={weatherLoading}
weatherError={weatherError}
weatherLoadingText={t("weather.loading")}
weatherUnavailableText={t("weather.unavailable")}
cityName={cityNames[outlet.cityId]}
openingHoursLabel={t("outlet.openingHours")}
openingHours={outlet.openingHours}
addressLabel={t("outlet.address")}
address={outlet.address}
storesCountText={outlet.storesCountText}
cityCenterDistanceKm={outlet.cityCenterDistanceKm}
airportDistanceKm={outlet.airportDistanceKm}
reviewCountLabel={t("outlet.reviewCount")}
reviewCount={outlet.reviewCount}
/>
*/}

<TaxFreeCard
title="Tax Free"
vatRate={outlet.vatRate}
minimumSpend={outlet.minimumTaxFreeSpend}
officeInfo={outlet.taxFreeOfficeInfo}
/>

<BrandsCard
title={t("outlet.brands")}
brandSearch={brandSearch}
setBrandSearch={setBrandSearch}
openCategory={openCategory}
setOpenCategory={setOpenCategory}
brandCategoryGroups={brandCategoryGroups}
/>


<RestaurantsCard
title={t("outlet.restaurantsCafes")}
restaurants={restaurantItems}
notAvailableText={t("common.notAvailable")}
/>

<ServicesCard
title={t("outlet.services")}
services={outlet.services}
notAvailableText={t("common.notAvailable")}
/>

<TransportationCard
title={t("outlet.transportation")}
transportationItems={transportationItems}
notAvailableText={t("common.notAvailable")}
buttonText={t("outlet.viewTransportationGuide")}
onPressGuide={() =>
navigation.navigate("Transportation", {
outletId: outlet.outletId,
})
}
/>

<WebsiteCard
title={t("website.title")}
description={t("website.description")}
buttonText={t("website.visit")}
onPress={() => Linking.openURL(outlet.websiteUrl)}
/>

<MapsCard
title={t("outlet.maps")}
googleText={t("outlet.googleMaps")}
appleText={t("outlet.appleMaps")}
yandexText={t("outlet.yandexMaps")}
onPressGoogle={() => Linking.openURL(outlet.googleMapsUrl)}
onPressApple={() => Linking.openURL(outlet.appleMapsUrl)}
onPressYandex={() => Linking.openURL(outlet.yandexMapsUrl)}
/>

<View style={styles.card}>
<Text style={styles.sectionTitle}>
{t("outlet.reviews")}
</Text>

<ReviewStatsCard
summaryText={`⭐ ${averageRating} (${outletReviews.length} ${t(
"outlet.reviewLabel"
)})`}
transportationTitle={t("outlet.transportationRating")}
transportationValue={averageTransportationRating}
brandsTitle={t("outlet.brandsRating")}
brandsValue={averageBrandVarietyRating}
restaurantsTitle={t("outlet.restaurantsRating")}
restaurantsValue={averageRestaurantsRating}
servicesTitle={t("outlet.servicesRating")}
servicesValue={averageServicesRating}
/>

<ReviewTabs
activeTab={reviewSort}
helpfulText={t("outlet.mostHelpful")}
recentText={t("outlet.recent")}
onChangeTab={setReviewSort}
/>

{!currentUserReview && (
<WriteReviewButton
title={t("outlet.writeReview")}
onPress={() => {
if (
!requireAuth({
isLoggedIn,
navigation,
})
) {
return;
}

navigation.navigate("WriteReview", {
outletId: outlet.outletId,
});
}}
/>
)}

{outletReviews.length > 0 ? (
sortedReviews.map((review) => {
const helpfulItem = getHelpfulItem(review.reviewId);

return (
<ReviewItem
key={review.reviewId}
userName={review.userName}
rating={getReviewAverage(review)}
comment={review.comment}
createdAt={review.createdAt}
isEdited={review.isEdited}
updatedAt={review.updatedAt}
previousComment={review.previousComment}
editedText={t("outlet.edited")}
previousCommentTitle={t("outlet.previousComment")}
helpfulText={t("outlet.helpful")}
helpfulCount={helpfulItem.helpfulCount}
isHelpfulByCurrentUser={helpfulItem.isHelpfulByCurrentUser}
canEdit={currentUser?.userId === review.userId}
editText={t("outlet.editReview")}
onPressHelpful={() => toggleHelpful(review.reviewId)}
onPressEdit={() => {
if (
!requireAuth({
isLoggedIn,
navigation,
})
) {
return;
}

navigation.navigate("WriteReview", {
outletId: outlet.outletId,
reviewId: review.reviewId,
});
}}
/>
);
})
) : (
<Text style={styles.text}>
{t("outlet.noReviews")}
</Text>
)}
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: {
padding: 20,
paddingTop: 70,
paddingBottom: 120,
},

heroImage: {
width: "100%",
height: 260,
borderRadius: 28,
marginBottom: 22,
backgroundColor: "#E5E7EB",
},

gallery: {
marginBottom: 22,
},

galleryImage: {
width: 110,
height: 85,
borderRadius: 16,
marginRight: 10,
backgroundColor: "#E5E7EB",
},

title: {
fontSize: 32,
fontWeight: "800",
color: "#0B1F3A",
},

location: {
fontSize: 16,
color: "#C9A227",
marginTop: 6,
marginBottom: 16,
},

favoriteButton: {
backgroundColor: "#FFFFFF",
borderRadius: 16,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 18,
},

favoriteButtonText: {
textAlign: "center",
fontWeight: "700",
color: "#0B1F3A",
},

badgeRow: {
flexDirection: "row",
gap: 10,
marginBottom: 20,
flexWrap: "wrap",
},

badge: {
backgroundColor: "#FFFFFF",
color: "#0B1F3A",
paddingHorizontal: 12,
paddingVertical: 8,
borderRadius: 999,
borderWidth: 1,
borderColor: "#E5E7EB",
fontWeight: "700",
textTransform: "capitalize",
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
marginBottom: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
},

sectionTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 10,
},

text: {
fontSize: 15,
color: "#666666",
lineHeight: 22,
marginBottom: 6,
},

mapButton: {
backgroundColor: "#0B1F3A",
borderRadius: 14,
padding: 14,
marginTop: 8,
},

mapButtonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},

mapButtonSecondary: {
backgroundColor: "#FFFFFF",
borderRadius: 14,
padding: 14,
marginTop: 10,
borderWidth: 1,
borderColor: "#E5E7EB",
},

mapButtonSecondaryText: {
color: "#0B1F3A",
fontWeight: "800",
textAlign: "center",
},

reviewSummary: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 14,
},

reviewCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

reviewUser: {
fontWeight: "800",
color: "#0B1F3A",
},

reviewRating: {
marginTop: 4,
color: "#C9A227",
fontWeight: "800",
},

reviewComment: {
marginTop: 6,
color: "#666666",
lineHeight: 20,
},

reviewDate: {
marginTop: 8,
color: "#999999",
fontSize: 12,
},

reviewStatsRow: {
flexDirection: "row",
gap: 10,
marginBottom: 10,
},

reviewStatBox: {
flex: 1,
backgroundColor: "#F7F8FA",
borderRadius: 12,
padding: 12,
borderWidth: 1,
borderColor: "#E5E7EB",
},

reviewStatTitle: {
color: "#666666",
fontSize: 12,
fontWeight: "700",
},

reviewStatValue: {
marginTop: 4,
color: "#0B1F3A",
fontWeight: "800",
},

reviewHelpful: {
marginTop: 8,
color: "#0B1F3A",
fontWeight: "800",
},

reviewTabs: {
flexDirection: "row",
gap: 10,
marginTop: 14,
marginBottom: 14,
},

reviewTab: {
flex: 1,
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 12,
borderWidth: 1,
borderColor: "#E5E7EB",
},

reviewTabActive: {
backgroundColor: "#0B1F3A",
borderColor: "#0B1F3A",
},

reviewTabText: {
textAlign: "center",
color: "#0B1F3A",
fontWeight: "800",
},

reviewTabTextActive: {
color: "#FFFFFF",
},

editedText: {
marginTop: 4,
color: "#C9A227",
fontSize: 12,
fontWeight: "800",
},

editReviewButton: {
marginTop: 10,
backgroundColor: "#FFFFFF",
borderRadius: 12,
padding: 10,
borderWidth: 1,
borderColor: "#E5E7EB",
},

editReviewButtonText: {
color: "#0B1F3A",
fontWeight: "800",
textAlign: "center",
},

previousCommentBox: {
marginTop: 10,
backgroundColor: "#FFFFFF",
borderRadius: 12,
padding: 10,
borderWidth: 1,
borderColor: "#E5E7EB",
},

previousCommentTitle: {
color: "#C9A227",
fontWeight: "800",
marginBottom: 4,
fontSize: 12,
},

previousCommentText: {
color: "#666666",
lineHeight: 18,
fontSize: 13,
},

writeReviewButton: {
backgroundColor: "#0B1F3A",
borderRadius: 16,
padding: 14,
marginTop: 12,
marginBottom: 14,
},

writeReviewButtonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},

brandSearchInput: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 14,
color: "#0B1F3A",
},

brandCategoryBox: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

brandCategoryTitle: {
color: "#0B1F3A",
fontWeight: "800",
},

brandItem: {
color: "#666666",
marginTop: 8,
},

galleryImageActive: {
borderWidth: 3,
borderColor: "#C9A227",
},





galleryModal: {
flex: 1,
backgroundColor: "#000000",
justifyContent: "center",
alignItems: "center",
padding: 20,
},

galleryModalImage: {
width: screenWidth,
height: screenHeight * 0.75,
},

galleryCloseButton: {
position: "absolute",
top: 60,
right: 20,
zIndex: 10,
},

galleryCloseText: {
color: "#FFFFFF",
fontWeight: "900",
fontSize: 16,
},

weatherCard: {
backgroundColor: "#FFF8E1",
borderRadius: 20,
padding: 16,
marginBottom: 16,
borderWidth: 1,
borderColor: "#C9A227",
flexDirection: "row",
alignItems: "center",
},

weatherIcon: {
fontSize: 30,
marginRight: 12,
},

weatherTitle: {
color: "#0B1F3A",
fontWeight: "900",
fontSize: 15,
},

weatherText: {
color: "#666666",
marginTop: 4,
},



galleryModalImageWrapper: {
width: "100%",
height: "75%",
justifyContent: "center",
alignItems: "center",
},

galleryArrowLeft: {
position: "absolute",
left: 10,
zIndex: 10,
padding: 16,
},

galleryArrowRight: {
position: "absolute",
right: 10,
zIndex: 10,
padding: 16,
},

galleryArrowText: {
color: "#FFFFFF",
fontSize: 54,
fontWeight: "300",
},

galleryZoomScroll: {
width: screenWidth,
height: screenHeight * 0.75,
},

galleryZoomContent: {
justifyContent: "center",
alignItems: "center",
},

restaurantCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

restaurantTitle: {
color: "#0B1F3A",
fontWeight: "800",
fontSize: 16,
},

restaurantCategory: {
marginTop: 4,
color: "#666666",
},

restaurantPrice: {
marginTop: 6,
color: "#C9A227",
fontWeight: "800",
},

chipWrap: {
flexDirection: "row",
flexWrap: "wrap",
},

transportationCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

transportationTitle: {
color: "#0B1F3A",
fontWeight: "800",
fontSize: 16,
},

transportationMeta: {
marginTop: 6,
color: "#666666",
lineHeight: 20,
},

transportationPrice: {
marginTop: 6,
color: "#C9A227",
fontWeight: "800",
},

transportationTip: {
marginTop: 8,
color: "#666666",
fontStyle: "italic",
lineHeight: 20,
},

});