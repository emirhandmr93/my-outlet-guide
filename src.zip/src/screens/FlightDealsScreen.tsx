import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { flightDeals } from "../constants/flightDeals";
import { useTranslation } from "../hooks/useTranslation";
import { getBestFlightDealAlertLevel } from "../utils/flightDealEngine";
import {
departureAirports,
flightDealCities,
} from "../constants/flightDealCities";

import { useFlightDealPreferences } from "../contexts/FlightDealPreferencesContext";

export function FlightDealsScreen() {
const {
departureAirportId,
selectedCityIds,
selectedThresholds,
} = useFlightDealPreferences();


const filteredDeals = flightDeals.filter((deal) => {
const alertLevel = getBestFlightDealAlertLevel({
discountPercent: deal.discountPercent,
selectedThresholds,
});

return (
deal.departureAirportId === departureAirportId &&
selectedCityIds.includes(deal.destinationCityId) &&
Boolean(alertLevel)
);
});

const navigation = useNavigation<any>();
const { t } = useTranslation();
return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>
{t("flightDeals.title")}
</Text>

<Text style={styles.pageSubtitle}>
{t("flightDeals.subtitle")}
</Text>

{filteredDeals.map((deal) => {
const airport =
departureAirports.find(
(item) =>
item.airportId === deal.departureAirportId
);

const city =
flightDealCities.find(
(item) =>
item.cityId === deal.destinationCityId
);

return (
<TouchableOpacity
key={deal.dealId}
style={styles.card}
activeOpacity={0.85}
onPress={() =>
navigation.navigate("FlightDealDetail", {
dealId: deal.dealId,
})
}
>
{(() => {
const alertLevel = getBestFlightDealAlertLevel({
discountPercent: deal.discountPercent,
selectedThresholds,
});

if (!alertLevel) {
return null;
}

const icon =
alertLevel.id === "exceptional"
? "🔥"
: alertLevel.id === "great"
? "🟠"
: "🟡";

return (
<Text style={styles.badge}>
{icon} {alertLevel.title}
</Text>
);
})()}


<Text style={styles.route}>
{airport?.cityName} → {city?.cityName}
</Text>

<Text style={styles.airline}>
{deal.airline}
</Text>

<Text style={styles.price}>
{deal.detectedPrice} {deal.currency}
</Text>

<Text style={styles.discount}>
{deal.discountPercent}% {t("flightDeals.belowAverage")}
</Text>

<Text style={styles.updated}>
{t("flightDeals.updated")} {deal.lastUpdatedMinutesAgo} {t("flightDeals.minAgo")}
</Text>
</TouchableOpacity>
);
})}

{filteredDeals.length === 0 && (
<View style={styles.emptyCard}>
<Text style={styles.emptyTitle}>
{t("flightDeals.noOpportunities")}
</Text>

<Text style={styles.emptyText}>
{t("flightDeals.noOpportunitiesText")}
</Text>
</View>
)}
</ScrollView>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: "#F7F8FA",
},

content: {
padding: 20,
paddingTop: 60,
paddingBottom: 120,
},

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
marginBottom: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
},

badge: {
color: "#C9A227",
fontWeight: "800",
marginBottom: 8,
},

route: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
},

airline: {
marginTop: 6,
color: "#666666",
},

price: {
marginTop: 12,
fontSize: 24,
fontWeight: "800",
color: "#0B1F3A",
},

discount: {
marginTop: 6,
color: "#C9A227",
fontWeight: "800",
},

updated: {
marginTop: 8,
color: "#999999",
fontSize: 12,
},

emptyCard: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 20,
borderWidth: 1,
borderColor: "#E5E7EB",
},

emptyTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
},

emptyText: {
color: "#666666",
lineHeight: 20,
},
});