import { useState } from "react";
import { useNavigation } from "@react-navigation/native";
import { useTranslation } from "../hooks/useTranslation";
import {
Alert,
ScrollView,
StyleSheet,
Text,
TextInput,
TouchableOpacity,
View,
} from "react-native";

import { useAuth } from "../contexts/AuthContext";

export function LoginScreen() {
const {
loginWithEmail,
registerWithEmail,
loginWithGoogle,
loginWithApple,
} = useAuth();

const { t } = useTranslation();
const navigation = useNavigation<any>();

const [showEmailForm, setShowEmailForm] = useState(false);
const [email, setEmail] = useState("");
const [password, setPassword] = useState("");

async function handleRegister() {
try {
await registerWithEmail(email.trim(), password);
navigation.goBack();
} catch {
Alert.alert(
t("common.error"),
t("login.createAccountError")
);
}
}

async function handleLogin() {
try {
await loginWithEmail(email.trim(), password);
navigation.goBack();
} catch {
Alert.alert(
t("common.error"),
t("login.signInError")
);
}
}

return (
<ScrollView
style={styles.container}
contentContainerStyle={styles.content}
>
<Text style={styles.pageTitle}>
{t("login.title")}
</Text>

<Text style={styles.pageSubtitle}>
{t("login.subtitle")}
</Text>

<TouchableOpacity
style={styles.socialButton}
onPress={async () => {
try {
await loginWithApple();
navigation.goBack();
} catch {
Alert.alert(
t("common.error"),
t("login.appleComingSoon")
);
}
}}
>
<Text style={styles.socialButtonText}>
{t("login.apple")}
</Text>
</TouchableOpacity>

<TouchableOpacity
style={styles.emailButton}
onPress={() =>
setShowEmailForm((current) => !current)
}
>
<Text style={styles.emailButtonText}>
{t("login.email")}
</Text>
</TouchableOpacity>

{showEmailForm && (
<View style={styles.emailCard}>
<Text style={styles.label}>
{t("login.emailLabel")}
</Text>

<TextInput
style={styles.input}
placeholder={t("login.emailPlaceholder")}
placeholderTextColor="#8A8A8A"
value={email}
onChangeText={setEmail}
autoCapitalize="none"
keyboardType="email-address"
/>

<Text style={styles.label}>
{t("login.passwordLabel")}
</Text>

<TextInput
style={styles.input}
placeholder={t("login.passwordPlaceholder")}
placeholderTextColor="#8A8A8A"
value={password}
onChangeText={setPassword}
secureTextEntry
/>

<TouchableOpacity
style={styles.primaryButton}
onPress={handleLogin}
>
<Text style={styles.primaryButtonText}>
{t("login.signIn")}
</Text>
</TouchableOpacity>

<TouchableOpacity
style={styles.secondaryButton}
onPress={handleRegister}
>
<Text style={styles.secondaryButtonText}>
{t("login.createAccount")}
</Text>
</TouchableOpacity>
</View>
)}

<Text style={styles.termsText}>
{t("login.terms")}
</Text>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 70, paddingBottom: 120 },

pageTitle: {
fontSize: 34,
fontWeight: "900",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 16,
color: "#C9A227",
marginTop: 8,
marginBottom: 24,
lineHeight: 22,
},

socialButton: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
},

socialButtonText: {
color: "#0B1F3A",
fontWeight: "900",
textAlign: "center",
},

emailButton: {
backgroundColor: "#0B1F3A",
borderRadius: 18,
padding: 18,
marginBottom: 16,
},

emailButtonText: {
color: "#FFFFFF",
fontWeight: "900",
textAlign: "center",
},

emailCard: {
backgroundColor: "#FFFFFF",
borderRadius: 22,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 16,
},

label: {
color: "#0B1F3A",
fontWeight: "800",
marginBottom: 8,
},

input: {
backgroundColor: "#F7F8FA",
borderRadius: 16,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 14,
},

primaryButton: {
backgroundColor: "#0B1F3A",
borderRadius: 16,
padding: 15,
marginTop: 4,
},

primaryButtonText: {
color: "#FFFFFF",
fontWeight: "900",
textAlign: "center",
},

secondaryButton: {
backgroundColor: "#FFF8E1",
borderRadius: 16,
padding: 15,
marginTop: 10,
borderWidth: 1,
borderColor: "#C9A227",
},

secondaryButtonText: {
color: "#0B1F3A",
fontWeight: "900",
textAlign: "center",
},

termsText: {
color: "#666666",
textAlign: "center",
lineHeight: 20,
marginTop: 10,
},
});