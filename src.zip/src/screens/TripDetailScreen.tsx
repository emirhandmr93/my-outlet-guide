import { useState } from "react";
import DateTimePicker from "@react-native-community/datetimepicker";
import { RouteProp, useRoute } from "@react-navigation/native";
import { getTripStatusLabel } from "../utils/getTripStatusLabel";
import { useNotificationSettings } from "../contexts/NotificationSettingsContext";
import {
Platform,
ScrollView,
StyleSheet,
Text,
TouchableOpacity,
View,
} from "react-native";

import { DropdownSelector } from "../components/DropdownSelector";
import { WeatherCard } from "../components/WeatherCard";
import { deals } from "../constants/deals";
import { events } from "../constants/events";
import { notificationTemplates } from "../constants/notifications";
import { weatherForecasts } from "../constants/weatherForecasts";
import { useTrips } from "../contexts/TripsContext";
import { useTranslation } from "../hooks/useTranslation";

type RouteParams = {
TripDetail: {
tripId: string;
};
};

const tripCityOptions = [
{ label: "Paris", value: "paris" },
{ label: "Milan", value: "milan" },
{ label: "London", value: "london" },
];

function formatDate(date: Date) {
const year = date.getFullYear();
const month = String(date.getMonth() + 1).padStart(2, "0");
const day = String(date.getDate()).padStart(2, "0");

return `${year}-${month}-${day}`;
}

export function TripDetailScreen() {
const route = useRoute<RouteProp<RouteParams, "TripDetail">>();
const { trips, addCityToTrip } = useTrips();
const { t } = useTranslation();
const { flightReminders, taxFreeReminders, dealReminders, eventReminders, } = useNotificationSettings();

const [selectedCityId, setSelectedCityId] = useState("paris");
const [arrivalDate, setArrivalDate] = useState<Date | null>(null);
const [departureDate, setDepartureDate] = useState<Date | null>(null);
const [pickerType, setPickerType] = useState<"arrival" | "departure" | null>(
null
);

const trip = trips.find((item) => item.id === route.params?.tripId);
const visibleNotifications = notificationTemplates.filter((notification) => {
if (notification.notificationType === "flight") {
return flightReminders;
}

if (notification.notificationType === "tax_free") {
return taxFreeReminders;
}

if (notification.notificationType === "deal") {
return dealReminders;
}

if (notification.notificationType === "event") {
return eventReminders;
}

return true;
});


const selectedCity =
tripCityOptions.find((city) => city.value === selectedCityId) ||
tripCityOptions[0];

if (!trip) {
return (
<View style={styles.emptyContainer}>
<Text style={styles.emptyText}>{t("tripDetail.notFound")}</Text>
</View>
);
}

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{trip.tripName}</Text>

<Text style={styles.pageSubtitle}>
{trip.startDate} - {trip.endDate}
</Text>

<View style={styles.card}>
<Text style={styles.sectionTitle}>{t("tripDetail.status")}</Text>
<Text style={styles.status}>
{getTripStatusLabel(trip.status, t)}
</Text>
</View>

<View style={styles.card}>
<Text style={styles.sectionTitle}>{t("tripDetail.flightInfo")}</Text>

<Text style={styles.infoText}>
{t("tripDetail.flightNumber")}:{" "}
{trip.flightNumber || t("tripDetail.notProvided")}
</Text>

<Text style={styles.infoText}>
{t("tripDetail.departureAirport")}:{" "}
{trip.departureAirport || t("tripDetail.notProvided")}
</Text>

<Text style={styles.infoText}>
{t("tripDetail.departureTime")}:{" "}
{trip.departureTime || t("tripDetail.notProvided")}
</Text>
</View>

<View style={styles.card}>
<Text style={styles.sectionTitle}>{t("tripDetail.tripCities")}</Text>

<DropdownSelector
label=""
selectedLabel={selectedCity.label}
options={tripCityOptions}
onSelect={setSelectedCityId}
/>

<Text style={styles.fieldLabel}>{t("tripDetail.arrivalDate")}</Text>

<TouchableOpacity
style={styles.inputBox}
onPress={() => {
if (!arrivalDate) {
setArrivalDate(new Date());
}
setPickerType("arrival");
}}
>
<Text style={arrivalDate ? styles.inputText : styles.placeholderText}>
{arrivalDate
? formatDate(arrivalDate)
: t("tripDetail.selectArrivalDate")}
</Text>
</TouchableOpacity>

<Text style={styles.fieldLabel}>{t("tripDetail.departureDate")}</Text>

<TouchableOpacity
style={styles.inputBox}
onPress={() => {
if (!departureDate) {
setDepartureDate(arrivalDate || new Date());
}
setPickerType("departure");
}}
>
<Text
style={departureDate ? styles.inputText : styles.placeholderText}
>
{departureDate
? formatDate(departureDate)
: t("tripDetail.selectDepartureDate")}
</Text>
</TouchableOpacity>

{pickerType && (
<DateTimePicker
value={
pickerType === "arrival"
? arrivalDate || new Date()
: departureDate || arrivalDate || new Date()
}
mode="date"
display={Platform.OS === "ios" ? "spinner" : "default"}
onChange={(_, selectedDate) => {
if (!selectedDate) {
setPickerType(null);
return;
}

if (pickerType === "arrival") {
setArrivalDate(selectedDate);

if (departureDate && selectedDate > departureDate) {
setDepartureDate(null);
}
}

if (pickerType === "departure") {
setDepartureDate(selectedDate);
}

if (Platform.OS !== "ios") {
setPickerType(null);
}
}}
/>
)}

{Platform.OS === "ios" && pickerType && (
<TouchableOpacity
style={styles.doneButton}
onPress={() => setPickerType(null)}
>
<Text style={styles.doneButtonText}>{t("tripDetail.done")}</Text>
</TouchableOpacity>
)}

<TouchableOpacity
style={styles.addButton}
onPress={() => {
if (!arrivalDate || !departureDate) {
alert(t("tripDetail.alertDates"));
return;
}

if (departureDate < arrivalDate) {
alert(t("tripDetail.alertDeparture"));
return;
}

const tripStart = new Date(trip.startDate);
const tripEnd = new Date(trip.endDate);

tripStart.setHours(0, 0, 0, 0);
tripEnd.setHours(23, 59, 59, 999);

if (arrivalDate < tripStart || departureDate > tripEnd) {
alert(t("tripDetail.alertInsideTrip"));
return;
}

const newArrivalDate = formatDate(arrivalDate);
const newDepartureDate = formatDate(departureDate);

const hasOverlap = trip.tripCities.some((city) => {
return (
newArrivalDate < city.departureDate &&
newDepartureDate > city.arrivalDate
);
});

if (hasOverlap) {
alert(t("tripDetail.alertOverlap"));
return;
}

addCityToTrip(trip.id, {
cityId: selectedCity.value,
cityName: selectedCity.label,
arrivalDate: newArrivalDate,
departureDate: newDepartureDate,
});

setArrivalDate(null);
setDepartureDate(null);
}}
>
<Text style={styles.addButtonText}>{t("tripDetail.addCity")}</Text>
</TouchableOpacity>

{trip.tripCities.map((city, index) => (
<View key={`${city.cityId}-${index}`} style={styles.cityCard}>
<Text style={styles.cityTitle}>{city.cityName}</Text>
<Text style={styles.cityDates}>
{city.arrivalDate} - {city.departureDate}
</Text>
</View>
))}
</View>

<Text style={styles.sectionHeader}>{t("tripDetail.weather")}</Text>

{trip.tripCities.length > 0 ? (
trip.tripCities.map((city, index) => {
const weather =
weatherForecasts.find((item) => item.cityId === city.cityId) ||
weatherForecasts[0];

const filteredWeather = {
...weather,
forecasts: weather.forecasts.filter((forecast) => {
return (
forecast.date >= city.arrivalDate &&
forecast.date <= city.departureDate
);
}),
};

return (
<WeatherCard
key={`${city.cityId}-weather-${index}`}
weather={filteredWeather}
/>
);
})
) : (
<View style={styles.card}>
<Text style={styles.placeholder}>{t("tripDetail.emptyCityText")}</Text>
</View>
)}

<View style={styles.card}>
<Text style={styles.sectionTitle}>{t("tripDetail.deals")}</Text>

{trip.tripCities.flatMap((city) => {
const matchingDeals = deals.filter((deal) => {
return (
deal.cityId === city.cityId &&
deal.startDate <= city.departureDate &&
deal.endDate >= city.arrivalDate
);
});

return matchingDeals.map((deal) => (
<View key={`${city.cityId}-${deal.dealId}`} style={styles.dealCard}>
<Text style={styles.dealTitle}>{deal.title}</Text>

<Text style={styles.dealDescription}>{deal.description}</Text>

<Text style={styles.dealDates}>
{deal.startDate} - {deal.endDate}
</Text>
</View>
));
})}

{trip.tripCities.length === 0 && (
<Text style={styles.placeholder}>{t("tripDetail.emptyDeals")}</Text>
)}
</View>

<View style={styles.card}>
<Text style={styles.sectionTitle}>{t("tripDetail.events")}</Text>

{trip.tripCities.flatMap((city) => {
const matchingEvents = events.filter((event) => {
return (
event.cityId === city.cityId &&
event.startDate <= city.departureDate &&
event.endDate >= city.arrivalDate
);
});

return matchingEvents.map((event) => (
<View
key={`${city.cityId}-${event.eventId}`}
style={styles.eventCard}
>
<Text style={styles.eventTitle}>{event.title}</Text>

<Text style={styles.eventDescription}>{event.description}</Text>

<Text style={styles.eventDates}>
{event.startDate} - {event.endDate}
</Text>
</View>
));
})}

{trip.tripCities.length === 0 && (
<Text style={styles.placeholder}>{t("tripDetail.emptyEvents")}</Text>
)}
</View>

<View style={styles.card}>
<Text style={styles.sectionTitle}>{t("tripDetail.notifications")}</Text>

{visibleNotifications.map((notification) => (
<View
key={notification.notificationId}
style={styles.notificationCard}
>
<Text style={styles.notificationTitle}>{notification.title}</Text>

<Text style={styles.notificationMessage}>
{notification.message}
</Text>
</View>
))}
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: "#F7F8FA",
},

content: {
padding: 20,
paddingTop: 60,
paddingBottom: 120,
},

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
color: "#C9A227",
marginTop: 6,
marginBottom: 20,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 14,
},

sectionTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 10,
},

sectionHeader: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginTop: 10,
marginBottom: 12,
},

fieldLabel: {
fontSize: 14,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 8,
marginTop: 12,
},

status: {
color: "#C9A227",
fontWeight: "800",
},

infoText: {
color: "#666666",
marginBottom: 6,
},

inputBox: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
paddingHorizontal: 14,
paddingVertical: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
},

inputText: {
color: "#0B1F3A",
fontSize: 15,
},

placeholderText: {
color: "#8A8A8A",
fontSize: 15,
},

doneButton: {
marginTop: 12,
backgroundColor: "#EFEFEF",
borderRadius: 14,
padding: 12,
},

doneButtonText: {
textAlign: "center",
fontWeight: "800",
color: "#0B1F3A",
},

addButton: {
marginTop: 14,
backgroundColor: "#FFF8E1",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#C9A227",
},

addButtonText: {
textAlign: "center",
fontWeight: "800",
color: "#0B1F3A",
},

cityCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
marginTop: 10,
borderWidth: 1,
borderColor: "#E5E7EB",
},

cityTitle: {
fontWeight: "800",
color: "#0B1F3A",
fontSize: 16,
},

cityDates: {
marginTop: 4,
color: "#666666",
},

placeholder: {
color: "#666666",
},

emptyContainer: {
flex: 1,
justifyContent: "center",
alignItems: "center",
},

emptyText: {
fontSize: 18,
fontWeight: "700",
},

dealCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginTop: 10,
},

dealTitle: {
fontSize: 16,
fontWeight: "800",
color: "#0B1F3A",
},

dealDescription: {
marginTop: 4,
color: "#666666",
},

dealDates: {
marginTop: 8,
color: "#C9A227",
fontWeight: "700",
},

eventCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginTop: 10,
},

eventTitle: {
fontSize: 16,
fontWeight: "800",
color: "#0B1F3A",
},

eventDescription: {
marginTop: 4,
color: "#666666",
},

eventDates: {
marginTop: 8,
color: "#C9A227",
fontWeight: "700",
},

notificationCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginTop: 10,
},

notificationTitle: {
fontSize: 16,
fontWeight: "800",
color: "#0B1F3A",
},

notificationMessage: {
marginTop: 4,
color: "#666666",
},
});
