import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useNotificationSettings } from "../contexts/NotificationSettingsContext";
import { useTranslation } from "../hooks/useTranslation";
import { useNavigation } from "@react-navigation/native";

export function NotificationSettingsScreen() {
const { t } = useTranslation();
const navigation = useNavigation<any>();

const {
flightDeals,
setFlightDeals,
flightReminders,
setFlightReminders,
taxFreeReminders,
setTaxFreeReminders,
dealReminders,
setDealReminders,
eventReminders,
setEventReminders,
favoriteOutletAlerts,
setFavoriteOutletAlerts,
favoriteBrandAlerts,
setFavoriteBrandAlerts,
majorPromotionsOnly,
setMajorPromotionsOnly,
} = useNotificationSettings();

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("notifications.title")}</Text>

<Text style={styles.pageSubtitle}>{t("notifications.subtitle")}</Text>

<View style={styles.infoBox}>
<Text style={styles.infoText}>{t("notifications.info")}</Text>
</View>

<NotificationRow
title={t("notifications.flightReminders")}
description={t("notifications.flightRemindersDesc")}
enabled={flightReminders}
onPress={() => setFlightReminders(!flightReminders)}
/>

<NotificationRow
title={t("notifications.taxFree")}
description={t("notifications.taxFreeDesc")}
enabled={taxFreeReminders}
onPress={() => setTaxFreeReminders(!taxFreeReminders)}
/>

<NotificationRow
title={t("notifications.deals")}
description={t("notifications.dealsDesc")}
enabled={dealReminders}
onPress={() => setDealReminders(!dealReminders)}
/>

<NotificationRow
title={t("notifications.events")}
description={t("notifications.eventsDesc")}
enabled={eventReminders}
onPress={() => setEventReminders(!eventReminders)}
/>

<NotificationRow
title={t("notifications.favoriteOutlet")}
description={t("notifications.favoriteOutletDesc")}
enabled={favoriteOutletAlerts}
onPress={() => setFavoriteOutletAlerts(!favoriteOutletAlerts)}
/>

<NotificationRow
title={t("notifications.favoriteBrand")}
description={t("notifications.favoriteBrandDesc")}
enabled={favoriteBrandAlerts}
onPress={() => setFavoriteBrandAlerts(!favoriteBrandAlerts)}
/>

<NotificationRow
title={t("notifications.majorPromotions")}
description={t("notifications.majorPromotionsDesc")}
enabled={majorPromotionsOnly}
onPress={() => setMajorPromotionsOnly(!majorPromotionsOnly)}
/>
</ScrollView>
);
}

function NotificationRow({
title,
description,
enabled,
onPress,
}: {
title: string;
description: string;
enabled: boolean;
onPress: () => void;
}) {
const { t } = useTranslation();    
return (
<TouchableOpacity style={styles.row} activeOpacity={0.85} onPress={onPress}>
<View style={styles.rowContent}>
<Text style={styles.rowTitle}>{title}</Text>
<Text style={styles.rowDescription}>{description}</Text>
</View>

<Text style={[styles.toggle, enabled && styles.toggleActive]}>
{enabled ? t("common.on") : t("common.off")}
</Text>
</TouchableOpacity>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

infoBox: {
backgroundColor: "#FFF8E1",
borderRadius: 18,
padding: 16,
borderWidth: 1,
borderColor: "#C9A227",
marginBottom: 16,
},

infoText: {
color: "#0B1F3A",
fontWeight: "700",
lineHeight: 20,
},

row: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
flexDirection: "row",
alignItems: "center",
justifyContent: "space-between",
gap: 12,
},

rowContent: {
flex: 1,
},

rowTitle: {
fontSize: 17,
fontWeight: "800",
color: "#0B1F3A",
},

rowDescription: {
marginTop: 5,
color: "#666666",
lineHeight: 20,
},

toggle: {
fontWeight: "800",
color: "#666666",
},

toggleActive: {
color: "#C9A227",
},


});