import { useState } from "react";
import {
ScrollView,
StyleSheet,
Text,
TextInput,
View,
} from "react-native";

import { CountrySelector } from "../components/CountrySelector";
import { CurrencySelector } from "../components/CurrencySelector";
import { countries } from "../constants/countries";
import { taxFreeRules } from "../constants/taxFreeRules";
import { useSavings } from "../contexts/SavingsContext";
import {
convertFromEur,
formatCurrency,
} from "../services/exchangeRateService";
import { useTranslation } from "../hooks/useTranslation";

export function TaxFreeCalculatorScreen() {
const [amount, setAmount] = useState("");
const { t } = useTranslation();

const {
selectedCountryId,
selectedCurrency,
setSelectedCountryId,
setSelectedCurrency,
} = useSavings();

const selectedCountry =
countries.find((country) => country.countryId === selectedCountryId) ||
countries[0];

const rule =
taxFreeRules.find((item) => item.countryId === selectedCountryId) ||
taxFreeRules[0];

const numericAmount = Number(amount) || 0;
const estimatedRefund = numericAmount * (rule.estimatedRefundRate / 100);
const netCost = numericAmount - estimatedRefund;
const convertedNetCost = convertFromEur(netCost, selectedCurrency);

const isBelowMinimum =
rule.minimumSpend > 0 &&
numericAmount > 0 &&
numericAmount < rule.minimumSpend;

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("taxCalc.title")}</Text>

<Text style={styles.pageSubtitle}>
{t("taxCalc.subtitle")}
</Text>

<View style={styles.card}>
<Text style={styles.sectionTitle}>
{t("taxCalc.country")}
</Text>

<CountrySelector
selectedCountryId={selectedCountryId}
onSelectCountry={setSelectedCountryId}
/>

<Text style={styles.sectionTitle}>
{t("taxCalc.yourCurrency")}
</Text>

<CurrencySelector
selectedCurrency={selectedCurrency}
onSelectCurrency={setSelectedCurrency}
/>

<Text style={styles.label}>
{t("taxCalc.shoppingAmount")} ({selectedCountry.currency})
</Text>

<TextInput
style={styles.input}
keyboardType="numeric"
placeholder="2500"
placeholderTextColor="#8A8A8A"
value={amount}
onChangeText={setAmount}
/>

{isBelowMinimum && (
<View style={styles.warningBox}>
<Text style={styles.warningText}>
{t("taxCalc.belowMinimum")} {selectedCountry.countryName}.
</Text>
</View>
)}

<View style={styles.resultBox}>
<Text style={styles.resultLabel}>
{t("taxCalc.estimatedRefund")}
</Text>
<Text style={styles.resultValue}>
{selectedCountry.currency} {estimatedRefund.toFixed(2)}
</Text>
</View>

<View style={styles.resultBox}>
<Text style={styles.resultLabel}>
{t("taxCalc.estimatedNetCost")}
</Text>
<Text style={styles.resultValue}>
{selectedCountry.currency} {netCost.toFixed(2)}
</Text>
</View>

<View style={styles.highlightBox}>
<Text style={styles.highlightLabel}>
{t("taxCalc.netCostCurrency")}
</Text>
<Text style={styles.highlightValue}>
{formatCurrency(convertedNetCost, selectedCurrency)}
</Text>
</View>

<Text style={styles.note}>
{t("taxCalc.vatRate")}: {rule.vatRate}% •{" "}
{t("taxCalc.refundRate")}: {rule.estimatedRefundRate}% •{" "}
{t("taxCalc.minimumSpend")}: {selectedCountry.currency}{" "}
{rule.minimumSpend}
</Text>
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
},

sectionTitle: {
fontSize: 16,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 10,
marginTop: 8,
},

label: {
fontSize: 14,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 8,
marginTop: 12,
},

input: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
paddingHorizontal: 14,
paddingVertical: 12,
borderWidth: 1,
borderColor: "#E5E7EB",
fontSize: 15,
},

warningBox: {
marginTop: 14,
backgroundColor: "#FFF8E1",
borderRadius: 14,
padding: 12,
borderWidth: 1,
borderColor: "#C9A227",
},

warningText: {
color: "#0B1F3A",
fontWeight: "700",
lineHeight: 20,
},

resultBox: { marginTop: 18 },

resultLabel: {
color: "#666666",
},

resultValue: {
marginTop: 4,
fontSize: 24,
fontWeight: "800",
color: "#0B1F3A",
},

highlightBox: {
marginTop: 20,
backgroundColor: "#0B1F3A",
borderRadius: 18,
padding: 16,
},

highlightLabel: {
color: "#C9A227",
fontWeight: "800",
marginBottom: 6,
},

highlightValue: {
color: "#FFFFFF",
fontSize: 24,
fontWeight: "800",
},

note: {
marginTop: 16,
color: "#666666",
lineHeight: 20,
},
});