import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { useTrips } from "../contexts/TripsContext";
import { useTranslation } from "../hooks/useTranslation";
import {
ScrollView,
StyleSheet,
Text,
TouchableOpacity,
View,
} from "react-native";

import { brands } from "../constants/brands";
import { deals } from "../constants/deals";
import { outletBrands } from "../constants/outletBrands";
import { outlets } from "../constants/outlets";
import { useTransition } from "react";

type RouteParams = {
BrandResults: {
brandId: string;
};
};

const cityNames: Record<string, string> = {
paris: "Paris",
milan: "Milan",
london: "London",
};

const countryNames: Record<string, string> = {
france: "France",
italy: "Italy",
"united-kingdom": "United Kingdom",
};

export function BrandResultsScreen() {
const navigation = useNavigation<any>();
const route = useRoute<RouteProp<RouteParams, "BrandResults">>();
const { t } = useTranslation();

const brand =
brands.find((item) => item.brandId === route.params?.brandId) || brands[0];

const matchingOutletIds = outletBrands
.filter((item) => item.brandId === brand.brandId)
.map((item) => item.outletId);

const matchingOutlets = outlets.filter((outlet) =>
matchingOutletIds.includes(outlet.outletId)
);

const { trips } = useTrips();

const activeTrip = trips.find((trip) => trip.status === "Active") || trips[0];

const tripCityIds = activeTrip?.tripCities.map((city) => city.cityId) || [];

const recommendedOutlets = matchingOutlets.filter((outlet) =>
tripCityIds.includes(outlet.cityId)
);

const allOtherOutlets = matchingOutlets.filter(
(outlet) =>
!recommendedOutlets.some(
(recommended) => recommended.outletId === outlet.outletId
)
);


const matchingDeals = deals.filter(
(deal) => deal.brandId === brand.brandId
);

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{brand.brandName}</Text>
<Text style={styles.pageSubtitle}>
    {t("brand.subtitle")}
    </Text>

{recommendedOutlets.length > 0 && (
<>
<Text style={styles.sectionTitle}>
    {t("brand.recommended")}
    </Text>

{recommendedOutlets.map((outlet) => (
<TouchableOpacity
key={`recommended-${outlet.outletId}`}
style={styles.recommendedCard}
activeOpacity={0.85}
onPress={() =>
navigation.navigate("OutletDetail", {
outletId: outlet.outletId,
})
}
>
<Text style={styles.outletName}>{outlet.name}</Text>

<Text style={styles.outletLocation}>
{cityNames[outlet.cityId]}, {countryNames[outlet.countryId]}
</Text>

<Text style={styles.recommendedText}>
{t("brand.availableDuringTrip")}
    </Text>
</TouchableOpacity>
))}
</>
)}

<Text style={styles.sectionTitle}>
    {t("brand.currentDeals")}
    </Text>

{matchingDeals.length > 0 ? (
matchingDeals.map((deal) => (
<View key={deal.dealId} style={styles.dealCard}>
<Text style={styles.dealTitle}>{deal.title}</Text>
<Text style={styles.dealDescription}>{deal.description}</Text>
<Text style={styles.dealDates}>
{deal.startDate} - {deal.endDate}
</Text>
</View>
))
) : (
<View style={styles.emptyCard}>
<Text style={styles.emptyText}>
    {t("brand.noDeals")}
    </Text>
</View>
)}

<Text style={styles.sectionTitle}>
    {t("brand.viewAllLocations")}
    </Text>

{allOtherOutlets.map((outlet) => (
<TouchableOpacity
key={outlet.outletId}
style={styles.card}
activeOpacity={0.85}
onPress={() =>
navigation.navigate("OutletDetail", {
outletId: outlet.outletId,
})
}
>
<Text style={styles.outletName}>
    {t("brand.viewOutlet")}
    </Text>

<Text style={styles.outletLocation}>
{cityNames[outlet.cityId]}, {countryNames[outlet.countryId]}
</Text>

</TouchableOpacity>
))}

{matchingOutlets.length === 0 && (
<View style={styles.emptyCard}>
<Text style={styles.emptyTitle}>
    {t("brand.noOutlets")}
    </Text>
<Text style={styles.emptyText}>
    {t("brand.noOutletsText")}
    </Text>
</View>
)}
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },

pageTitle: {
fontSize: 32,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

sectionTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 12,
marginTop: 18,
},

recommendedCard: {
backgroundColor: "#FFF8E1",
borderRadius: 18,
padding: 16,
borderWidth: 1,
borderColor: "#C9A227",
marginBottom: 10,
},

recommendedText: {
color: "#0B1F3A",
fontWeight: "700",
},

dealCard: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
},

dealTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
},

dealDescription: {
marginTop: 5,
color: "#666666",
lineHeight: 20,
},

dealDates: {
marginTop: 8,
color: "#C9A227",
fontWeight: "700",
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
},

outletName: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
},

outletLocation: {
marginTop: 5,
color: "#666666",
},

tapText: {
marginTop: 10,
color: "#0B1F3A",
fontWeight: "800",
},

emptyCard: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
},

emptyTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
},

emptyText: {
color: "#666666",
lineHeight: 20,
},
});