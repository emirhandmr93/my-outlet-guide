import { useNavigation } from "@react-navigation/native";
import { useEffect, useState } from "react";
import { updateProfile } from "firebase/auth";
import {
Alert,
ScrollView,
StyleSheet,
Text,
TextInput,
TouchableOpacity,
View,
} from "react-native";
import { useTranslation } from "../hooks/useTranslation";
import { useAuth } from "../contexts/AuthContext";

export function ProfileScreen() {
const navigation = useNavigation<any>();
const { t } = useTranslation();
const { currentUser, isAuthenticated, logout } = useAuth();
const [displayName, setDisplayName] = useState("");

useEffect(() => {
if (currentUser) {
setDisplayName(
currentUser.displayName ||
currentUser.email?.split("@")[0] ||
""
);
}
}, [currentUser]);

async function handleSaveDisplayName() {
if (!currentUser) {
return;
}

const cleanName = displayName.trim();

if (!cleanName) {
Alert.alert(
t("common.error"),
t("profile.displayNameEmptyError")
);
return;
}

await updateProfile(currentUser, {
displayName: cleanName,
});

Alert.alert(
t("common.success"),
t("profile.displayNameUpdated")
);
}

return (
<ScrollView
style={styles.container}
contentContainerStyle={styles.content}
>
<Text style={styles.pageTitle}>
{t("profile.title")}
</Text>

<Text style={styles.pageSubtitle}>
{t("profile.subtitle")}
</Text>

<View style={styles.authCard}>
<Text style={styles.authTitle}>
{isAuthenticated
? currentUser?.email || t("profile.signedIn")
: t("profile.guestUser")}
</Text>

<Text style={styles.authText}>
{isAuthenticated
? t("profile.syncedText")
: t("profile.signInText")}
</Text>

{isAuthenticated && (
<View style={styles.displayNameBox}>
<Text style={styles.displayNameLabel}>
{t("profile.displayName")}
</Text>

<TextInput
style={styles.displayNameInput}
value={displayName}
onChangeText={setDisplayName}
placeholder={t("profile.displayNamePlaceholder")}
placeholderTextColor="#8A8A8A"
/>

<TouchableOpacity
style={styles.saveNameButton}
onPress={handleSaveDisplayName}
>
<Text style={styles.saveNameButtonText}>
{t("profile.saveName")}
</Text>
</TouchableOpacity>
</View>
)}

{isAuthenticated ? (
<TouchableOpacity style={styles.logoutButton} onPress={logout}>
<Text style={styles.logoutButtonText}>
{t("profile.signOut")}
</Text>
</TouchableOpacity>
) : (
<TouchableOpacity
style={styles.signInButton}
onPress={() => navigation.navigate("Login")}
>
<Text style={styles.signInButtonText}>
{t("profile.signIn")}
</Text>
</TouchableOpacity>
)}
</View>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("MyTrips")}>
<Text style={styles.rowText}>{t("profile.myTrips")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("LanguageSettings")}>
<Text style={styles.rowText}>{t("profile.language")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.getParent()?.navigate("CurrencySettings")}>
<Text style={styles.rowText}>{t("profile.currency")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("NotificationSettings")}>
<Text style={styles.rowText}>{t("profile.notifications")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("FlightDealSettings")}>
<Text style={styles.rowText}>{t("profile.flightDeals")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.getParent()?.navigate("OfflinePacks")}>
<Text style={styles.rowText}>{t("profile.offlinePacks")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("MyReviews")}>
<Text style={styles.rowText}>{t("profile.myReviews")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("HelpFaq")}>
<Text style={styles.rowText}>{t("profile.helpFaq")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("ContactUs")}>
<Text style={styles.rowText}>{t("profile.contactUs")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("PrivacyPolicy")}>
<Text style={styles.rowText}>{t("profile.privacyPolicy")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("TermsConditions")}>
<Text style={styles.rowText}>{t("profile.termsConditions")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row} onPress={() => navigation.navigate("DeleteAccount")}>
<Text style={styles.rowText}>{t("profile.deleteAccount")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.row}>
<Text style={styles.rowText}>{t("profile.about")}</Text>
<Text style={styles.arrow}>›</Text>
</TouchableOpacity>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: "#F7F8FA",
},

content: {
padding: 20,
paddingTop: 60,
paddingBottom: 120,
},

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

row: {
backgroundColor: "#FFFFFF",
borderRadius: 16,
padding: 18,
marginBottom: 10,
borderWidth: 1,
borderColor: "#E5E7EB",
flexDirection: "row",
alignItems: "center",
justifyContent: "space-between",
},

rowText: {
fontSize: 16,
fontWeight: "700",
color: "#0B1F3A",
},

arrow: {
fontSize: 26,
color: "#C9A227",
},

authCard: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 16,
},

authTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
},

authText: {
marginTop: 6,
color: "#666666",
lineHeight: 20,
},

signInButton: {
backgroundColor: "#0B1F3A",
borderRadius: 14,
padding: 14,
marginTop: 14,
},

signInButtonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},

logoutButton: {
backgroundColor: "#FFF8E1",
borderRadius: 14,
padding: 14,
marginTop: 14,
borderWidth: 1,
borderColor: "#C9A227",
},

logoutButtonText: {
color: "#0B1F3A",
fontWeight: "800",
textAlign: "center",
},

displayNameBox: {
marginTop: 14,
},

displayNameLabel: {
color: "#0B1F3A",
fontWeight: "800",
marginBottom: 8,
},

displayNameInput: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
color: "#0B1F3A",
fontWeight: "700",
},

saveNameButton: {
backgroundColor: "#0B1F3A",
borderRadius: 14,
padding: 14,
marginTop: 10,
},

saveNameButtonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},



});