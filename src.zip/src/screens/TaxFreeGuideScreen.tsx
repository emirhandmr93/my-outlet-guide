import { ScrollView, StyleSheet, Text, View } from "react-native";
import { CountrySelector } from "../components/CountrySelector";
import { countries } from "../constants/countries";
import { taxFreeRules } from "../constants/taxFreeRules";
import { useSavings } from "../contexts/SavingsContext";
import { useTranslation } from "../hooks/useTranslation";

export function TaxFreeGuideScreen() {
const { selectedCountryId, setSelectedCountryId } = useSavings();
const { t } = useTranslation();

const selectedCountry =
countries.find((country) => country.countryId === selectedCountryId) ||
countries[0];

const rule =
taxFreeRules.find(
(item) => item.countryId === selectedCountry.countryId
) || taxFreeRules[0];

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("taxGuide.title")}</Text>

<Text style={styles.pageSubtitle}>
{t("taxGuide.subtitle")}
</Text>

<View style={styles.card}>
<Text style={styles.sectionTitle}>
{t("taxGuide.country")}
</Text>

<CountrySelector
selectedCountryId={selectedCountryId}
onSelectCountry={setSelectedCountryId}
/>

<View style={styles.infoBox}>
<Text style={styles.infoLabel}>
{t("taxGuide.vatRate")}
</Text>
<Text style={styles.infoValue}>{rule.vatRate}%</Text>
</View>

<View style={styles.infoBox}>
<Text style={styles.infoLabel}>
{t("taxGuide.minimumSpend")}
</Text>
<Text style={styles.infoValue}>
{rule.currency} {rule.minimumSpend}
</Text>
</View>

<View style={styles.infoBox}>
<Text style={styles.infoLabel}>
{t("taxGuide.refundRate")}
</Text>
<Text style={styles.infoValue}>
{rule.estimatedRefundRate}%
</Text>
</View>

<Text style={styles.sectionTitle}>
{t("taxGuide.refundProcess")}
</Text>

{rule.refundProcessSteps.map((step, index) => (
<View key={`${step}-${index}`} style={styles.stepRow}>
<Text style={styles.stepNumber}>
{index + 1}
</Text>

<Text style={styles.stepText}>{step}</Text>
</View>
))}

<Text style={styles.note}>
{t("taxGuide.note")}
</Text>
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
},

infoBox: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
marginBottom: 10,
},

infoLabel: {
color: "#666666",
marginBottom: 4,
},

infoValue: {
color: "#0B1F3A",
fontSize: 18,
fontWeight: "800",
},

sectionTitle: {
marginTop: 16,
marginBottom: 12,
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
},

stepRow: {
flexDirection: "row",
gap: 12,
marginBottom: 12,
alignItems: "flex-start",
},

stepNumber: {
width: 28,
height: 28,
borderRadius: 14,
backgroundColor: "#0B1F3A",
color: "#FFFFFF",
textAlign: "center",
lineHeight: 28,
fontWeight: "800",
},

stepText: {
flex: 1,
color: "#666666",
lineHeight: 20,
},

note: {
marginTop: 14,
color: "#666666",
lineHeight: 20,
fontSize: 13,
},
});