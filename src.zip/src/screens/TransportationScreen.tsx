import { RouteProp, useRoute } from "@react-navigation/native";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { useTranslation } from "../hooks/useTranslation";
import { getTransportationLabel } from "../utils/transportationFormatter";
import { transportationGuides } from "../constants/transportationGuides";

type RouteParams = {
Transportation: {
outletId: string;
};
};

export function TransportationScreen() {
const route = useRoute<RouteProp<RouteParams, "Transportation">>();
const outletId = route.params?.outletId;
const { t } = useTranslation();

const guides = transportationGuides.filter(
(guide) => guide.outletId === outletId
);

const recommendedGuide = guides.find((guide) => guide.recommended) || guides[0];
const otherGuides = guides.filter(
(guide) => guide.guideId !== recommendedGuide?.guideId
);

if (!recommendedGuide) {
return (
<View style={styles.emptyContainer}>
<Text style={styles.emptyTitle}>{t("transportation.notAvailable")}</Text>
</View>
);
}

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("transportation.title")}</Text>
<Text style={styles.pageSubtitle}>{t("transportation.subtitle")}</Text>

<View style={styles.card}>
<Text style={styles.badge}>{t("transportation.recommendedRoute")}</Text>
<Text style={styles.routeTitle}>{recommendedGuide.title}</Text>

<View style={styles.infoRow}>
<Text style={styles.infoBox}>
{getTransportationLabel(recommendedGuide.transportationType)}
</Text>
<Text style={styles.infoBox}>⏱️ {recommendedGuide.estimatedDuration}</Text>
<Text style={styles.infoBox}>💰 {recommendedGuide.estimatedCost}</Text>
</View>

<Text style={styles.sectionTitle}>{t("transportation.stepByStep")}</Text>

{recommendedGuide.steps
.sort((a, b) => a.order - b.order)
.map((step) => (
<View key={step.order} style={styles.stepRow}>
<Text style={styles.stepNumber}>{step.order}</Text>
<Text style={styles.stepText}>{step.description}</Text>
</View>
))}
</View>

{otherGuides.length > 0 && (
<>
<Text style={styles.sectionTitleOutside}>{t("transportation.otherOptions")}</Text>

{otherGuides.map((guide) => (
<View key={guide.guideId} style={styles.optionCard}>
<Text style={styles.optionTitle}>{guide.title}</Text>
<Text style={styles.optionText}>
{getTransportationLabel(guide.transportationType)} • {guide.estimatedDuration} • {guide.estimatedCost}
</Text>
</View>
))}
</>
)}
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },
emptyContainer: {
flex: 1,
backgroundColor: "#F7F8FA",
alignItems: "center",
justifyContent: "center",
padding: 20,
},
emptyTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
textAlign: "center",
},
pageTitle: { fontSize: 28, fontWeight: "800", color: "#0B1F3A" },
pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},
card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
},
badge: {
alignSelf: "flex-start",
backgroundColor: "#FFF8E1",
color: "#0B1F3A",
borderRadius: 999,
paddingHorizontal: 12,
paddingVertical: 7,
fontWeight: "800",
marginBottom: 12,
},
routeTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 14,
},
infoRow: {
gap: 8,
marginBottom: 18,
},
infoBox: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 12,
color: "#0B1F3A",
fontWeight: "800",
},
sectionTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 12,
},
sectionTitleOutside: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginTop: 20,
marginBottom: 12,
},
stepRow: {
flexDirection: "row",
gap: 12,
marginBottom: 12,
alignItems: "flex-start",
},
stepNumber: {
width: 28,
height: 28,
borderRadius: 14,
backgroundColor: "#0B1F3A",
color: "#FFFFFF",
textAlign: "center",
lineHeight: 28,
fontWeight: "800",
},
stepText: {
flex: 1,
color: "#666666",
lineHeight: 20,
},
optionCard: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},
optionTitle: {
fontSize: 16,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
},
optionText: {
color: "#666666",
},
});