import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useTranslation } from "../hooks/useTranslation";

import { deals } from "../constants/deals";
import { events } from "../constants/events";
import { outlets } from "../constants/outlets";

type RouteParams = {
CityResults: {
cityId: string;
};
};

const cityNames: Record<string, string> = {
paris: "Paris",
milan: "Milan",
london: "London",
};

const countryNames: Record<string, string> = {
france: "France",
italy: "Italy",
"united-kingdom": "United Kingdom",
};

export function CityResultsScreen() {
const navigation = useNavigation<any>();
const route = useRoute<RouteProp<RouteParams, "CityResults">>();
const { t } = useTranslation();

const cityId = route.params?.cityId || "paris";
const cityName = cityNames[cityId] || cityId;

const cityOutlets = outlets.filter((outlet) => outlet.cityId === cityId);
const cityDeals = deals.filter((deal) => deal.cityId === cityId);
const cityEvents = events.filter((event) => event.cityId === cityId);

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{cityName}</Text>
<Text style={styles.pageSubtitle}>
    {t("city.subtitle")}
    </Text>

<Text style={styles.sectionTitle}>
     {t("city.availableOutlets")}
    </Text>

{cityOutlets.map((outlet) => (
<TouchableOpacity
key={outlet.outletId}
style={styles.card}
activeOpacity={0.85}
onPress={() =>
navigation.navigate("OutletDetail", {
outletId: outlet.outletId,
})
}
>
<Text style={styles.cardTitle}>{outlet.name}</Text>
<Text style={styles.cardText}>
{countryNames[outlet.countryId] || outlet.countryId} •{" "}
{outlet.taxFreeAvailable ? t("city.taxFreeAvailable")
: t("city.taxFreeLimited")}
</Text>
<Text style={styles.tapText}>
     {t("city.viewOutlet")}
    </Text>
</TouchableOpacity>
))}

<Text style={styles.sectionTitle}>
     {t("city.currentDeals")}
    </Text>

{cityDeals.length > 0 ? (
cityDeals.map((deal) => (
<View key={deal.dealId} style={styles.card}>
<Text style={styles.cardTitle}>{deal.title}</Text>
<Text style={styles.cardText}>{deal.description}</Text>
<Text style={styles.dateText}>
{deal.startDate} - {deal.endDate}
</Text>
</View>
))
) : (
<View style={styles.card}>
<Text style={styles.cardText}>
     {t("city.noDeals")}
    </Text>
</View>
)}

<Text style={styles.sectionTitle}>
     {t("city.events")}
    </Text>

{cityEvents.length > 0 ? (
cityEvents.map((event) => (
<View key={event.eventId} style={styles.card}>
<Text style={styles.cardTitle}>{event.title}</Text>
<Text style={styles.cardText}>{event.description}</Text>
<Text style={styles.dateText}>
{event.startDate} - {event.endDate}
</Text>
</View>
))
) : (
<View style={styles.card}>
<Text style={styles.cardText}>
     {t("city.noEvents")}
    </Text>
</View>
)}
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },

pageTitle: {
fontSize: 32,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

sectionTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginTop: 18,
marginBottom: 12,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
},

cardTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
},

cardText: {
color: "#666666",
lineHeight: 20,
},

dateText: {
marginTop: 8,
color: "#C9A227",
fontWeight: "800",
},

tapText: {
marginTop: 10,
color: "#0B1F3A",
fontWeight: "800",
},
});