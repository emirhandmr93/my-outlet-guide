import {
ScrollView,
StyleSheet,
Text,
TextInput,
View,
} from "react-native";
import { useState } from "react";

import { CountrySelector } from "../components/CountrySelector";
import { CurrencySelector } from "../components/CurrencySelector";
import { taxFreeRules } from "../constants/taxFreeRules";
import { countries } from "../constants/countries";
import {
convertFromEur,
formatCurrency,
} from "../services/exchangeRateService";
import { useSavings } from "../contexts/SavingsContext";
import { useTranslation } from "../hooks/useTranslation";

export function SmartShoppingCalculatorScreen() {
const [price, setPrice] = useState("");
const { t } = useTranslation();

const {
selectedCountryId,
selectedCurrency,
setSelectedCountryId,
setSelectedCurrency,
} = useSavings();

const selectedCountry =
countries.find((country) => country.countryId === selectedCountryId) ||
countries[0];

const rule =
taxFreeRules.find((item) => item.countryId === selectedCountryId) ||
taxFreeRules[0];

const numericPrice = Number(price) || 0;
const refund = numericPrice * (rule.estimatedRefundRate / 100);
const netCost = numericPrice - refund;
const convertedNetCost = convertFromEur(netCost, selectedCurrency);

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("smartCalc.title")}</Text>

<Text style={styles.pageSubtitle}>
{t("smartCalc.subtitle")}
</Text>

<View style={styles.card}>
<Text style={styles.sectionTitle}>
{t("smartCalc.country")}
</Text>

<CountrySelector
selectedCountryId={selectedCountryId}
onSelectCountry={setSelectedCountryId}
/>

<Text style={styles.sectionTitle}>
{t("smartCalc.yourCurrency")}
</Text>

<CurrencySelector
selectedCurrency={selectedCurrency}
onSelectCurrency={setSelectedCurrency}
/>

<Text style={styles.label}>
{t("smartCalc.productPrice")} ({selectedCountry.currency})
</Text>

<TextInput
style={styles.input}
keyboardType="numeric"
placeholder="2500"
placeholderTextColor="#8A8A8A"
value={price}
onChangeText={setPrice}
/>

<View style={styles.resultBox}>
<Text style={styles.resultLabel}>
{t("smartCalc.estimatedRefund")}
</Text>
<Text style={styles.resultValue}>
€ {refund.toFixed(2)}
</Text>
</View>

<View style={styles.resultBox}>
<Text style={styles.resultLabel}>
{t("smartCalc.estimatedNetCost")}
</Text>
<Text style={styles.resultValue}>
€ {netCost.toFixed(2)}
</Text>
</View>

<View style={styles.highlightBox}>
<Text style={styles.highlightLabel}>
{t("smartCalc.yourCurrency")}
</Text>
<Text style={styles.highlightValue}>
{formatCurrency(convertedNetCost, selectedCurrency)}
</Text>
</View>

<Text style={styles.note}>
{t("smartCalc.refundRate")}: {rule.estimatedRefundRate}% •{" "}
{t("smartCalc.minimumSpend")}: {selectedCountry.currency}{" "}
{rule.minimumSpend}
</Text>
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
},

sectionTitle: {
fontSize: 16,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
marginTop: 4,
},

label: {
fontSize: 14,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 8,
marginTop: 12,
},

input: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
paddingHorizontal: 14,
paddingVertical: 12,
borderWidth: 1,
borderColor: "#E5E7EB",
fontSize: 15,
},

resultBox: { marginTop: 18 },

resultLabel: {
color: "#666666",
},

resultValue: {
marginTop: 4,
fontSize: 24,
fontWeight: "800",
color: "#0B1F3A",
},

highlightBox: {
marginTop: 20,
backgroundColor: "#0B1F3A",
borderRadius: 18,
padding: 16,
},

highlightLabel: {
color: "#C9A227",
fontWeight: "800",
marginBottom: 6,
},

highlightValue: {
color: "#FFFFFF",
fontSize: 24,
fontWeight: "800",
},

note: {
marginTop: 16,
color: "#666666",
lineHeight: 20,
},
});