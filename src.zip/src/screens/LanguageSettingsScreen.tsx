import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { languages } from "../constants/languages";
import { useLanguage } from "../contexts/LanguageContext";

export function LanguageSettingsScreen() {
const { language, setLanguage } = useLanguage();

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>Language</Text>
<Text style={styles.pageSubtitle}>Choose your app language.</Text>

{languages.map((item) => {
const selected = language === item.languageCode;

return (
<TouchableOpacity
key={item.languageCode}
style={[styles.card, selected && styles.selectedCard]}
activeOpacity={0.85}
onPress={() => setLanguage(item.languageCode)}
>
<View>
<Text style={styles.languageName}>
{item.flag} {item.languageName}
</Text>
<Text style={styles.languageCode}>
{item.languageCode.toUpperCase()}
</Text>
</View>

<Text style={styles.checkmark}>{selected ? "✓" : ""}</Text>
</TouchableOpacity>
);
})}
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
flexDirection: "row",
justifyContent: "space-between",
alignItems: "center",
},

selectedCard: {
borderColor: "#C9A227",
backgroundColor: "#FFF8E1",
},

languageName: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
},

languageCode: {
marginTop: 4,
color: "#666666",
fontWeight: "700",
},

checkmark: {
fontSize: 24,
fontWeight: "800",
color: "#C9A227",
},
});