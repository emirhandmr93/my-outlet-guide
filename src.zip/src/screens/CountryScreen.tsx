import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useTranslation } from "../hooks/useTranslation";
import { countries } from "../constants/countries";
import { outlets } from "../constants/outlets";
import { taxFreeRules } from "../constants/taxFreeRules";

type RouteParams = {
Country: {
countryId?: string;
};
};

const cityNames: Record<string, string> = {
paris: "Paris",
milan: "Milan",
london: "London",
};

export function CountryScreen() {
const navigation = useNavigation<any>();
const route = useRoute<RouteProp<RouteParams, "Country">>();
const { t } = useTranslation();

const countryId = route.params?.countryId || "france";

const country =
countries.find((item) => item.countryId === countryId) || countries[0];

const rule =
taxFreeRules.find((item) => item.countryId === country.countryId) ||
taxFreeRules[0];

const countryOutlets = outlets.filter(
(outlet) => outlet.countryId === country.countryId
);

const shoppingCities = Array.from(
new Set(countryOutlets.map((outlet) => outlet.cityId))
);

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.countryName}>
{country.countryName} {country.countryFlag}
</Text>

<View style={styles.infoCard}>
<Text style={styles.infoTitle}>{t("country.currency")}</Text>
<Text style={styles.infoValue}>{country.currency}</Text>
</View>

<View style={styles.infoCard}>
<Text style={styles.infoTitle}>{t("country.taxFreeAvailable")}</Text>
<Text style={styles.infoValue}>
{country.taxFreeAvailable ? t("country.yes") : t("country.noLimited")}
</Text>
</View>

<View style={styles.infoCard}>
<Text style={styles.infoTitle}>{t("country.vatRate")}</Text>
<Text style={styles.infoValue}>{rule.vatRate}%</Text>
</View>

<View style={styles.infoCard}>
<Text style={styles.infoTitle}>{t("country.minimumSpend")}</Text>
<Text style={styles.infoValue}>
{rule.currency} {rule.minimumSpend}
</Text>
</View>

<Text style={styles.sectionTitle}>{t("country.shoppingCities")}</Text>

{shoppingCities.map((cityId) => (
<View key={cityId} style={styles.card}>
<Text style={styles.cardTitle}>{cityNames[cityId] || cityId}</Text>
</View>
))}

<Text style={styles.outletCount}>
{countryOutlets.length} {t("country.outletsAvailable")}
</Text>

<Text style={styles.sectionTitle}>{t("country.availableOutlets")}</Text>

{countryOutlets.map((outlet) => (
<TouchableOpacity
key={outlet.outletId}
style={styles.card}
activeOpacity={0.85}
onPress={() =>
navigation.navigate("OutletDetail", {
outletId: outlet.outletId,
})
}
>
<Text style={styles.cardTitle}>{outlet.name}</Text>
<Text style={styles.cardText}>
{cityNames[outlet.cityId] || outlet.cityId} •{" "}
{outlet.taxFreeAvailable
? t("country.taxFreeAvailable")
: t("country.taxFreeLimited")}
</Text>
</TouchableOpacity>
))}

<Text style={styles.sectionTitle}>
{t("country.quickAccess")}
</Text>

<TouchableOpacity
style={styles.actionButton}
onPress={() => navigation.navigate("TaxFreeCalculator")}
>
<Text style={styles.actionButtonText}>
{t("country.taxFreeCalculator")}
</Text>
</TouchableOpacity>

<TouchableOpacity
style={styles.actionButtonSecondary}
onPress={() => navigation.navigate("TaxFreeGuide")}
>
<Text style={styles.actionButtonSecondaryText}>
{t("country.taxFreeGuide")}
</Text>
</TouchableOpacity>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },
countryName: {
fontSize: 30,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 20,
},
infoCard: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
},
infoTitle: { fontSize: 14, color: "#666666" },
infoValue: {
marginTop: 4,
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
},
sectionTitle: {
marginTop: 18,
marginBottom: 12,
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
},
card: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},
cardTitle: {
fontSize: 17,
fontWeight: "700",
color: "#0B1F3A",
},
cardText: {
marginTop: 6,
color: "#666666",
lineHeight: 20,
},
outletCount: {
color: "#666666",
marginBottom: 10,
fontSize: 14,
},
actionButton: {
backgroundColor: "#0B1F3A",
borderRadius: 16,
padding: 15,
marginBottom: 10,
},
actionButtonText: {
color: "#FFFFFF",
textAlign: "center",
fontWeight: "800",
},
actionButtonSecondary: {
backgroundColor: "#FFFFFF",
borderRadius: 16,
padding: 15,
borderWidth: 1,
borderColor: "#E5E7EB",
},
actionButtonSecondaryText: {
color: "#0B1F3A",
textAlign: "center",
fontWeight: "800",
},
});