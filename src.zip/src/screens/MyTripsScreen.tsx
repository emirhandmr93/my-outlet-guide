import { useNavigation } from "@react-navigation/native";
import { getTripStatusLabel } from "../utils/getTripStatusLabel";
import {
ScrollView,
StyleSheet,
Text,
TouchableOpacity,
View,
} from "react-native";

import { useTranslation } from "../hooks/useTranslation";
import { Trip, useTrips } from "../contexts/TripsContext";

function TripCard({
trip,
onDelete,
onPress,
deleteLabel,
statusLabel,
}: {
trip: Trip;
onDelete: (tripId: string) => void;
onPress: () => void;
deleteLabel: string;
statusLabel: string;
}) {
return (
<TouchableOpacity style={styles.card} activeOpacity={0.85} onPress={onPress}>
<Text style={styles.cardLabel}>
    {statusLabel}
</Text>

<Text style={styles.cardTitle}>{trip.tripName}</Text>

<Text style={styles.cardText}>
{trip.startDate} - {trip.endDate}
</Text>

<TouchableOpacity
style={styles.deleteButton}
onPress={() => onDelete(trip.id)}
>
<Text style={styles.deleteButtonText}>{deleteLabel}</Text>
</TouchableOpacity>
</TouchableOpacity>
);
}

export function MyTripsScreen() {
const navigation = useNavigation<any>();
const { trips, deleteTrip } = useTrips();
const { t } = useTranslation();

const upcomingTrips = trips.filter((trip) => trip.status === "Upcoming");
const activeTrips = trips.filter((trip) => trip.status === "Active");
const completedTrips = trips.filter((trip) => trip.status === "Completed");

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("trips.title")}</Text>

<Text style={styles.pageSubtitle}>{t("trips.subtitle")}</Text>

<TouchableOpacity
style={styles.createButton}
onPress={() => navigation.navigate("CreateTrip")}
>
<Text style={styles.createButtonText}>{t("trips.create")}</Text>
</TouchableOpacity>

{trips.length === 0 ? (
<View style={styles.emptyCard}>
<Text style={styles.emptyTitle}>{t("trips.noTrips")}</Text>

<Text style={styles.emptyText}>{t("trips.noTripsText")}</Text>
</View>
) : (
<>
{activeTrips.length > 0 && (
<>
<Text style={styles.sectionTitle}>{t("trips.active")}</Text>

{activeTrips.map((trip) => (
<TripCard
key={trip.id}
trip={trip}
onDelete={deleteTrip}
deleteLabel={t("trips.delete")}
statusLabel={getTripStatusLabel(trip.status, t)}
onPress={() =>
navigation.navigate("TripDetail", {
tripId: trip.id,
})
}
/>
))}
</>
)}

{upcomingTrips.length > 0 && (
<>
<Text style={styles.sectionTitle}>{t("trips.upcoming")}</Text>

{upcomingTrips.map((trip) => (
<TripCard
key={trip.id}
trip={trip}
onDelete={deleteTrip}
deleteLabel={t("trips.delete")}
statusLabel={getTripStatusLabel(trip.status, t)}
onPress={() =>
navigation.navigate("TripDetail", {
tripId: trip.id,
})
}
/>
))}
</>
)}

{completedTrips.length > 0 && (
<>
<Text style={styles.sectionTitle}>{t("trips.completed")}</Text>

{completedTrips.map((trip) => (
<TripCard
key={trip.id}
trip={trip}
onDelete={deleteTrip}
deleteLabel={t("trips.delete")}
statusLabel={getTripStatusLabel(trip.status, t)}
onPress={() =>
navigation.navigate("TripDetail", {
tripId: trip.id,
})
}
/>
))}
</>
)}
</>
)}
</ScrollView>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: "#F7F8FA",
},

content: {
padding: 20,
paddingTop: 60,
paddingBottom: 120,
},

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

createButton: {
backgroundColor: "#0B1F3A",
borderRadius: 16,
padding: 15,
marginBottom: 18,
},

createButtonText: {
color: "#FFFFFF",
textAlign: "center",
fontWeight: "800",
fontSize: 16,
},

sectionTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginTop: 18,
marginBottom: 12,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
marginBottom: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
},

cardLabel: {
fontSize: 13,
color: "#C9A227",
fontWeight: "700",
marginBottom: 8,
},

cardTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
},

cardText: {
fontSize: 14,
color: "#666666",
lineHeight: 20,
marginBottom: 4,
},

deleteButton: {
marginTop: 14,
backgroundColor: "#EFEFEF",
borderRadius: 14,
padding: 12,
},

deleteButtonText: {
textAlign: "center",
fontWeight: "700",
color: "#0B1F3A",
},

emptyCard: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 22,
borderWidth: 1,
borderColor: "#E5E7EB",
},

emptyTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 8,
},

emptyText: {
fontSize: 14,
color: "#666666",
lineHeight: 20,
},
});