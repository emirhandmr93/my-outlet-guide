import { useNavigation } from "@react-navigation/native";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import {
departureAirports,
flightDealCities,
} from "../constants/flightDealCities";
import { useFlightDealPreferences } from "../contexts/FlightDealPreferencesContext";
import { useTranslation } from "../hooks/useTranslation";

const alertThresholds = [
{
id: "good",
title: "Good Deal",
percent: "15%",
description: "Notify me when fares are at least 15% below the 90-day average.",
},
{
id: "great",
title: "Great Deal",
percent: "30%",
description: "Notify me when fares are at least 25% below the 90-day average.",
},
{
id: "exceptional",
title: "Exceptional Deal",
percent: "45%",
description: "Notify me when fares are at least 40% below the 90-day average.",
},
];

export function FlightDealSettingsScreen() {
const navigation = useNavigation<any>();
const { t } = useTranslation();

const {
departureAirportId,
setDepartureAirportId,
selectedCityIds,
addCity,
removeCity,
selectedThresholds,
toggleThreshold,
} = useFlightDealPreferences();

const selectedAirport = departureAirports.find(
(airport) => airport.airportId === departureAirportId
);

const selectedCitiesText = flightDealCities
.filter((city) => selectedCityIds.includes(city.cityId))
.map((city) => city.cityName)
.join(", ");

const selectedThresholdsText = alertThresholds
.filter((threshold) => selectedThresholds.includes(threshold.id))
.map((threshold) => `${threshold.title} (${threshold.percent})`)
.join(", ");

function handleThresholdPress(thresholdId: string) {
if (
selectedThresholds.includes(thresholdId) &&
selectedThresholds.length === 1
) {
return;
}

toggleThreshold(thresholdId);
}

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("flightDeals.settingsTitle")}</Text>

<Text style={styles.pageSubtitle}>
{t("flightDeals.settingsSubtitle")}
</Text>

<View style={styles.infoBox}>
<Text style={styles.infoText}>
Flight deal percentages are calculated using the 90-day average fare for each route.
</Text>
</View>

<View style={styles.summaryCard}>
<Text style={styles.summaryTitle}>{t("flightDeals.currentSetup")}</Text>

<Text style={styles.summaryLabel}>{t("flightDeals.departureCity")}</Text>
<Text style={styles.summaryValue}>
{selectedAirport?.cityName || "Not selected"}
</Text>

<Text style={styles.summaryLabel}>{t("flightDeals.interestedCities")}</Text>
<Text style={styles.summaryValue}>
{selectedCitiesText || "No cities selected"}
</Text>

<Text style={styles.summaryLabel}>Alert Levels</Text>
<Text style={styles.summaryValue}>
{selectedThresholdsText || "No alert level selected"}
</Text>
</View>

<Text style={styles.sectionTitle}>Departure City</Text>

{departureAirports.map((airport) => (
<TouchableOpacity
key={airport.airportId}
style={[
styles.card,
departureAirportId === airport.airportId && styles.selectedCard,
]}
onPress={() => setDepartureAirportId(airport.airportId)}
>
<Text style={styles.cardTitle}>{airport.cityName}</Text>
<Text style={styles.cardText}>{airport.airportName}</Text>
</TouchableOpacity>
))}

<Text style={styles.sectionTitle}>Interested Cities</Text>

{flightDealCities.map((city) => {
const selected = selectedCityIds.includes(city.cityId);

return (
<TouchableOpacity
key={city.cityId}
style={[styles.card, selected && styles.selectedCard]}
onPress={() =>
selected ? removeCity(city.cityId) : addCity(city.cityId)
}
>
<Text style={styles.cardTitle}>{city.cityName}</Text>
<Text style={styles.cardText}>{city.countryName}</Text>

<Text style={styles.selectionText}>
{selected ? "✓ Selected" : "Tap to Select"}
</Text>
</TouchableOpacity>
);
})}

<Text style={styles.sectionTitle}>Alert Levels</Text>

{alertThresholds.map((threshold) => {
const selected = selectedThresholds.includes(threshold.id);

return (
<TouchableOpacity
key={threshold.id}
style={[styles.card, selected && styles.selectedCard]}
onPress={() => handleThresholdPress(threshold.id)}
>
<Text style={styles.cardTitle}>
{threshold.title} ({threshold.percent})
</Text>

<Text style={styles.cardText}>{threshold.description}</Text>

<Text style={styles.selectionText}>
{selected ? "✓ Selected" : "Tap to Select"}
</Text>
</TouchableOpacity>
);
})}

<TouchableOpacity
style={styles.viewDealsButton}
onPress={() => navigation.navigate("FlightDeals")}
>
<Text style={styles.viewDealsButtonText}>
✈️ {t("flightDeals.viewDeals")}
</Text>
</TouchableOpacity>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: "#F7F8FA",
},

content: {
padding: 20,
paddingTop: 60,
paddingBottom: 120,
},

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

infoBox: {
backgroundColor: "#FFF8E1",
borderRadius: 18,
padding: 16,
borderWidth: 1,
borderColor: "#C9A227",
marginBottom: 16,
},

infoText: {
color: "#0B1F3A",
fontWeight: "700",
lineHeight: 20,
},

summaryCard: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 16,
},

summaryTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 12,
},

summaryLabel: {
color: "#C9A227",
fontWeight: "800",
marginTop: 8,
},

summaryValue: {
color: "#0B1F3A",
fontWeight: "800",
marginTop: 4,
},

sectionTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 12,
marginTop: 18,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

selectedCard: {
borderColor: "#C9A227",
borderWidth: 2,
},

cardTitle: {
fontSize: 17,
fontWeight: "800",
color: "#0B1F3A",
},

cardText: {
color: "#666666",
marginTop: 4,
lineHeight: 20,
},

selectionText: {
marginTop: 8,
color: "#C9A227",
fontWeight: "800",
},

viewDealsButton: {
backgroundColor: "#0B1F3A",
borderRadius: 18,
padding: 16,
marginTop: 18,
},

viewDealsButtonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},
});