import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { currencies } from "../constants/currencies";
import { useSavings } from "../contexts/SavingsContext";
import type { CurrencyCode } from "../services/exchangeRateService";

export function CurrencySettingsScreen() {
const { selectedCurrency, setSelectedCurrency } = useSavings();

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>Currency</Text>
<Text style={styles.pageSubtitle}>Choose your preferred currency.</Text>

{currencies.map((item) => {
const selected = selectedCurrency === item.currencyCode;

return (
<TouchableOpacity
key={item.currencyCode}
style={[styles.card, selected && styles.selectedCard]}
activeOpacity={0.85}
onPress={() => setSelectedCurrency(item.currencyCode as CurrencyCode)}
>
<View>
<Text style={styles.currencyName}>
{item.symbol} {item.currencyName}
</Text>
<Text style={styles.currencyCode}>{item.currencyCode}</Text>
</View>

<Text style={styles.checkmark}>{selected ? "✓" : ""}</Text>
</TouchableOpacity>
);
})}
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },
pageTitle: { fontSize: 28, fontWeight: "800", color: "#0B1F3A" },
pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},
card: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
flexDirection: "row",
justifyContent: "space-between",
alignItems: "center",
},
selectedCard: {
borderColor: "#C9A227",
backgroundColor: "#FFF8E1",
},
currencyName: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
},
currencyCode: {
marginTop: 4,
color: "#666666",
fontWeight: "700",
},
checkmark: {
fontSize: 24,
fontWeight: "800",
color: "#C9A227",
},
});