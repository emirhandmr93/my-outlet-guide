import { useState } from "react";
import {
ScrollView,
StyleSheet,
Text,
TextInput,
TouchableOpacity,
View,
} from "react-native";

import { CountrySelector } from "../components/CountrySelector";
import { CurrencySelector } from "../components/CurrencySelector";
import { countries } from "../constants/countries";
import { taxFreeRules } from "../constants/taxFreeRules";
import { useSavings } from "../contexts/SavingsContext";
import {
convertFromEur,
formatCurrency,
} from "../services/exchangeRateService";
import { useTranslation } from "../hooks/useTranslation";

export function PriceAdvantageCalculatorScreen() {
const [europePrice, setEuropePrice] = useState("");
const [localPrice, setLocalPrice] = useState("");
const [includeTaxFree, setIncludeTaxFree] = useState(true);
const { t } = useTranslation();

const {
selectedCountryId,
selectedCurrency,
setSelectedCountryId,
setSelectedCurrency,
} = useSavings();

const selectedCountry =
countries.find((country) => country.countryId === selectedCountryId) ||
countries[0];

const rule =
taxFreeRules.find((item) => item.countryId === selectedCountryId) ||
taxFreeRules[0];

const numericEuropePrice = Number(europePrice) || 0;
const numericLocalPrice = Number(localPrice) || 0;

const refund = includeTaxFree
? numericEuropePrice * (rule.estimatedRefundRate / 100)
: 0;

const netEuropeCost = numericEuropePrice - refund;
const convertedEuropeCost = convertFromEur(netEuropeCost, selectedCurrency);

const savings = numericLocalPrice - convertedEuropeCost;
const hasSavings = savings > 0;

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("priceCalc.title")}</Text>

<Text style={styles.pageSubtitle}>
{t("priceCalc.subtitle")}
</Text>

<View style={styles.card}>
<Text style={styles.sectionTitle}>
{t("priceCalc.country")}
</Text>

<CountrySelector
selectedCountryId={selectedCountryId}
onSelectCountry={setSelectedCountryId}
/>

<Text style={styles.sectionTitle}>
{t("priceCalc.yourCurrency")}
</Text>

<CurrencySelector
selectedCurrency={selectedCurrency}
onSelectCurrency={setSelectedCurrency}
/>

<Text style={styles.label}>
{t("priceCalc.europePrice")} ({selectedCountry.currency})
</Text>

<TextInput
style={styles.input}
keyboardType="numeric"
placeholder="2500"
placeholderTextColor="#8A8A8A"
value={europePrice}
onChangeText={setEuropePrice}
/>

<Text style={styles.label}>
{t("priceCalc.localPrice")} ({selectedCurrency})
</Text>

<TextInput
style={styles.input}
keyboardType="numeric"
placeholder="120000"
placeholderTextColor="#8A8A8A"
value={localPrice}
onChangeText={setLocalPrice}
/>

<TouchableOpacity
style={styles.toggleButton}
onPress={() => setIncludeTaxFree((current) => !current)}
activeOpacity={0.85}
>
<Text style={styles.toggleButtonText}>
{includeTaxFree ? "☑" : "☐"} {t("priceCalc.includeTaxFree")}
</Text>
</TouchableOpacity>

<View style={styles.resultBox}>
<Text style={styles.resultLabel}>
{t("priceCalc.europeNetCost")}
</Text>
<Text style={styles.resultValue}>
{formatCurrency(convertedEuropeCost, selectedCurrency)}
</Text>
</View>

<View style={styles.highlightBox}>
<Text style={styles.highlightLabel}>
{hasSavings
? t("priceCalc.youSave")
: t("priceCalc.noSavings")}
</Text>

<Text style={styles.highlightValue}>
{formatCurrency(Math.abs(savings), selectedCurrency)}
</Text>
</View>

<Text style={styles.note}>
{includeTaxFree
? t("priceCalc.taxFreeIncluded")
: t("priceCalc.taxFreeNotIncluded")}{" "}
{t("priceCalc.refundRate")}: {rule.estimatedRefundRate}%.
</Text>
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
},

sectionTitle: {
fontSize: 16,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 10,
marginTop: 8,
},

label: {
fontSize: 14,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 8,
marginTop: 12,
},

input: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
paddingHorizontal: 14,
paddingVertical: 12,
borderWidth: 1,
borderColor: "#E5E7EB",
fontSize: 15,
},

toggleButton: {
marginTop: 18,
backgroundColor: "#FFFFFF",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#C9A227",
},

toggleButtonText: {
color: "#0B1F3A",
fontWeight: "800",
textAlign: "center",
},

resultBox: { marginTop: 18 },

resultLabel: {
color: "#666666",
},

resultValue: {
marginTop: 4,
fontSize: 24,
fontWeight: "800",
color: "#0B1F3A",
},

highlightBox: {
marginTop: 20,
backgroundColor: "#0B1F3A",
borderRadius: 18,
padding: 16,
},

highlightLabel: {
color: "#C9A227",
fontWeight: "800",
marginBottom: 6,
},

highlightValue: {
color: "#FFFFFF",
fontSize: 24,
fontWeight: "800",
},

note: {
marginTop: 16,
color: "#666666",
lineHeight: 20,
},
});