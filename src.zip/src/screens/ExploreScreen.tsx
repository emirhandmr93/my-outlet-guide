import { useMemo, useState } from "react";
import { useNavigation } from "@react-navigation/native";
import { searchAll, searchOutlets } from "../services/searchService";
import { categories } from "../constants/categories";
import { cities } from "../constants/cities";
import { countries } from "../constants/countries";
import { outlets } from "../constants/outlets";
import { useTranslation } from "../hooks/useTranslation";
import { getPopularBrands } from "../services/brandService";
import {
getCityName,
getCountryName,
} from "../services/locationService";

import {
Image,
ScrollView,
StyleSheet,
Text,
TextInput,
TouchableOpacity,
View,
} from "react-native";

export function ExploreScreen() {
const navigation = useNavigation<any>();
const { t } = useTranslation();
const [search, setSearch] = useState("");

const isSearching = search.trim().length > 0;

const availableCityIds = useMemo(
() => Array.from(new Set(outlets.map((outlet) => outlet.cityId))),
[]
);

const availableCountryIds = useMemo(
() => Array.from(new Set(outlets.map((outlet) => outlet.countryId))),
[]
);

const shoppingCities = useMemo(
() => cities.filter((city) => availableCityIds.includes(city.cityId)),
[availableCityIds]
);

const availableCountries = useMemo(
() =>
countries.filter((country) =>
availableCountryIds.includes(country.countryId)
),
[availableCountryIds]
);

const popularBrands = useMemo(() => {
return getPopularBrands();
}, []);

const searchSuggestions = useMemo(() => {
return searchAll(search, 6);
}, [search]);


const filteredOutlets = useMemo(() => {
return searchOutlets(search);
}, [search]);

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("explore.title")}</Text>

<TextInput
style={styles.searchInput}
placeholder={t("explore.search")}
placeholderTextColor="#8A8A8A"
value={search}
onChangeText={setSearch}
/>

{isSearching ? (
<>
{searchSuggestions.length > 0 && (
<>
<Text style={styles.sectionTitle}>{t("explore.suggestions")}</Text>

{searchSuggestions.map((item) => (
<TouchableOpacity
key={`${item.type}-${item.id}`}
style={styles.suggestionCard}
activeOpacity={0.85}
onPress={() => {
if (item.type === "brand") {
navigation.navigate("BrandResults", { brandId: item.id });
}

if (item.type === "outlet") {
navigation.navigate("OutletDetail", { outletId: item.id });
}

if (item.type === "category") {
setSearch(item.title);
}
if (item.type === "city") {
navigation.navigate("CityResults", {
cityId: item.id,
});
}

if (item.type === "country") {
navigation.navigate("Country", {
countryId: item.id,
});
}
}}
>
<Text style={styles.suggestionTitle}>{item.title}</Text>
<Text style={styles.suggestionSubtitle}>{item.subtitle}</Text>
</TouchableOpacity>
))}
</>
)}

<Text style={styles.sectionTitle}>{t("explore.searchResults")}</Text>

{filteredOutlets.map((outlet) => (
<TouchableOpacity
key={outlet.outletId}
activeOpacity={0.85}
style={styles.searchResultCard}
onPress={() =>
navigation.navigate("OutletDetail", {
outletId: outlet.outletId,
})
}
>
<Text style={styles.outletTitle}>{outlet.name}</Text>

<Text style={styles.outletLocation}>
{getCityName(outlet.cityId)}, {getCountryName(outlet.countryId)}
</Text>

<Text style={styles.tapText}>{t("explore.viewDetails")}</Text>
</TouchableOpacity>
))}

{filteredOutlets.length === 0 && (
<View style={styles.emptyCard}>
<Text style={styles.emptyTitle}>{t("explore.noResults")}</Text>
<Text style={styles.emptyText}>{t("explore.noResultsText")}</Text>
</View>
)}
</>
) : (
<>
<Text style={styles.sectionTitle}>{t("explore.shoppingCities")}</Text>

<View style={styles.row}>
{shoppingCities.map((city) => (
<TouchableOpacity
key={city.cityId}
style={styles.cityCard}
activeOpacity={0.85}
onPress={() =>
navigation.navigate("CityResults", {
cityId: city.cityId,
})
}
>
<Text style={styles.cityName}>{city.cityName}</Text>
</TouchableOpacity>
))}
</View>

<Text style={styles.sectionTitle}>{t("explore.browseByCountry")}</Text>

{availableCountries.map((country) => (
<TouchableOpacity
key={country.countryId}
style={styles.countryCard}
onPress={() =>
navigation.navigate("Country", {
countryId: country.countryId,
})
}
>
<Text style={styles.countryText}>
{country.countryFlag} {country.countryName}
</Text>
</TouchableOpacity>
))}

<Text style={styles.sectionTitle}>{t("explore.categories")}</Text>

<View style={styles.row}>
{categories.map((category) => (
<View key={category.categoryId} style={styles.categoryCard}>
<Text style={styles.categoryText}>
{category.icon} {category.categoryName}
</Text>
</View>
))}
</View>

<Text style={styles.sectionTitle}>{t("explore.popularBrands")}</Text>

{popularBrands.map((brand) => (
<TouchableOpacity
key={brand.brandId}
style={styles.countryCard}
onPress={() =>
navigation.navigate("BrandResults", {
brandId: brand.brandId,
})
}
>
<Text style={styles.countryText}>🏷️ {brand.brandName}</Text>
</TouchableOpacity>
))}

<Text style={styles.sectionTitle}>{t("explore.trendingOutlets")}</Text>

{outlets.map((outlet) => (
<TouchableOpacity
key={outlet.outletId}
activeOpacity={0.85}
style={styles.outletCard}
onPress={() =>
navigation.navigate("OutletDetail", {
outletId: outlet.outletId,
})
}
>
<Image source={{ uri: outlet.heroImage }} style={styles.outletImage} />

<View style={styles.outletContent}>
<Text style={styles.outletTitle}>{outlet.name}</Text>

<Text style={styles.outletLocation}>
{getCityName(outlet.cityId)}, {getCountryName(outlet.countryId)}
</Text>

<Text style={styles.outletStores}>
{outlet.taxFreeAvailable
? t("explore.taxFreeAvailable")
: t("explore.taxFreeLimited")}
</Text>

<Text style={styles.tapText}>{t("explore.viewDetails")}</Text>
</View>
</TouchableOpacity>
))}
</>
)}
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },
pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 20,
},
searchInput: {
backgroundColor: "#FFFFFF",
borderRadius: 16,
paddingHorizontal: 16,
paddingVertical: 14,
fontSize: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 20,
},
suggestionCard: {
backgroundColor: "#FFFFFF",
borderRadius: 16,
padding: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

suggestionTitle: {
fontSize: 17,
fontWeight: "800",
color: "#0B1F3A",
},

suggestionSubtitle: {
marginTop: 4,
color: "#C9A227",
fontWeight: "700",
},
sectionTitle: {
marginTop: 18,
marginBottom: 12,
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
},
row: { flexDirection: "row", gap: 10 },
cityCard: {
flex: 1,
backgroundColor: "#FFFFFF",
padding: 14,
borderRadius: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
},
cityName: {
textAlign: "center",
fontWeight: "700",
color: "#0B1F3A",
},
countryCard: {
backgroundColor: "#FFFFFF",
padding: 16,
borderRadius: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},
countryText: {
fontWeight: "700",
color: "#0B1F3A",
},
categoryCard: {
flex: 1,
backgroundColor: "#FFFFFF",
padding: 16,
borderRadius: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},
categoryText: {
textAlign: "center",
fontWeight: "700",
color: "#0B1F3A",
},
searchResultCard: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
},
outletCard: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
overflow: "hidden",
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 16,
},
outletImage: {
width: "100%",
height: 150,
},
outletContent: { padding: 18 },
outletTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
},
outletLocation: {
marginTop: 4,
color: "#666666",
},
outletStores: {
marginTop: 8,
color: "#C9A227",
fontWeight: "700",
},
tapText: {
marginTop: 10,
color: "#0B1F3A",
fontWeight: "800",
},
emptyCard: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
},
emptyTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
},
emptyText: {
color: "#666666",
lineHeight: 20,
},
});