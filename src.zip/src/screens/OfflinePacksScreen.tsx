import { useState } from "react";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useTrips } from "../contexts/TripsContext";
import { useTranslation } from "../hooks/useTranslation";

export function OfflinePacksScreen() {
const { trips } = useTrips();
const { t } = useTranslation();
const [downloadedTripIds, setDownloadedTripIds] = useState<string[]>([]);

function toggleDownload(tripId: string) {
setDownloadedTripIds((current) =>
current.includes(tripId)
? current.filter((id) => id !== tripId)
: [...current, tripId]
);
}

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("offline.title")}</Text>

<Text style={styles.pageSubtitle}>
{t("offline.subtitle")}
</Text>

<Text style={styles.sectionTitle}>{t("offline.tripPacks")}</Text>

{trips.length === 0 ? (
<View style={styles.card}>
<Text style={styles.cardTitle}>{t("offline.noTrips")}</Text>
<Text style={styles.cardText}>{t("offline.noTripsText")}</Text>
</View>
) : (
trips.map((trip) => {
const downloaded = downloadedTripIds.includes(trip.id);

return (
<View key={trip.id} style={styles.card}>
<Text style={styles.cardTitle}>{trip.tripName}</Text>

<Text style={styles.cardText}>
{trip.startDate} - {trip.endDate}
</Text>

<Text style={styles.cardText}>
{t("offline.cities")}:{" "}
{trip.tripCities.length > 0
? trip.tripCities.map((city) => city.cityName).join(", ")
: t("offline.addCitiesFirst")}
</Text>

<View style={styles.includesBox}>
<Text style={styles.includesTitle}>{t("offline.packIncludes")}</Text>
<Text style={styles.includesText}>• {t("offline.outletInfo")}</Text>
<Text style={styles.includesText}>• {t("offline.transportationGuides")}</Text>
<Text style={styles.includesText}>• {t("offline.taxFreeTools")}</Text>
<Text style={styles.includesText}>• {t("offline.brandLists")}</Text>
<Text style={styles.includesText}>• {t("offline.mapShortcuts")}</Text>
<Text style={styles.includesText}>• {t("offline.shoppingNotes")}</Text>
<Text style={styles.includesText}>• {t("offline.taxFreeChecklist")}</Text>
<Text style={styles.includesText}>• {t("offline.exchangeRates")}</Text>
</View>

<TouchableOpacity
style={[
styles.actionButton,
downloaded && styles.downloadedButton,
]}
onPress={() => toggleDownload(trip.id)}
>
<Text style={styles.actionButtonText}>
{downloaded ? t("offline.downloaded") : t("offline.downloadPack")}
</Text>
</TouchableOpacity>
</View>
);
})
)}

<Text style={styles.sectionTitle}>{t("offline.travelTools")}</Text>

<View style={styles.card}>
<Text style={styles.cardTitle}>{t("offline.checklistTitle")}</Text>
<Text style={styles.cardText}>{t("offline.checklistText")}</Text>
</View>

<View style={styles.card}>
<Text style={styles.cardTitle}>{t("offline.notesTitle")}</Text>
<Text style={styles.cardText}>{t("offline.notesText")}</Text>
</View>

<View style={styles.card}>
<Text style={styles.cardTitle}>{t("offline.exchangeTitle")}</Text>
<Text style={styles.cardText}>{t("offline.exchangeText")}</Text>
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },
content: { padding: 20, paddingTop: 60, paddingBottom: 120 },
pageTitle: { fontSize: 28, fontWeight: "800", color: "#0B1F3A" },
pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},
sectionTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginTop: 18,
marginBottom: 12,
},
card: {
backgroundColor: "#FFFFFF",
borderRadius: 18,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 12,
},
cardTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
},
cardText: {
color: "#666666",
lineHeight: 20,
marginBottom: 4,
},
includesBox: {
marginTop: 12,
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
},
includesTitle: {
color: "#0B1F3A",
fontWeight: "800",
marginBottom: 8,
},
includesText: {
color: "#666666",
lineHeight: 22,
},
actionButton: {
marginTop: 14,
backgroundColor: "#0B1F3A",
borderRadius: 14,
padding: 13,
},
downloadedButton: {
backgroundColor: "#C9A227",
},
actionButtonText: {
color: "#FFFFFF",
textAlign: "center",
fontWeight: "800",
},
});