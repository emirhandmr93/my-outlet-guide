import { useNavigation } from "@react-navigation/native";
import { useTranslation } from "../hooks/useTranslation";
import { getDashboardCards } from "../services/dashboardService";
import { HomeHeader } from "../components/HomeHeader";
import { SearchBar } from "../components/SearchBar";
import { DashboardUpdateCard } from "../components/DashboardUpdateCard";
import { DashboardSectionHeader } from "../components/DashboardSectionHeader";
import { colors } from "../theme/colors";
import { radius } from "../theme/radius";
import { spacing } from "../theme/spacing";
import { typography } from "../theme/typography";
import { shadows } from "../theme/shadows";
import { useState } from "react";
import {
ScrollView,
StyleSheet,
Text,
TextInput,
TouchableOpacity,
View,
} from "react-native";

import { outlets } from "../constants/outlets";
import { useFavorites } from "../contexts/FavoritesContext";
import { useTrips } from "../contexts/TripsContext";

export function HomeScreen() {
const navigation = useNavigation<any>();
const { t } = useTranslation();
const { trips } = useTrips();
const { favoriteIds } = useFavorites();
const [searchQuery, setSearchQuery] = useState("");
const dashboardCards = getDashboardCards(trips);
const primaryDashboardCard = dashboardCards[0];


const latestTrip = trips[0];

const favoriteOutlets = outlets.filter((outlet) =>
favoriteIds.includes(outlet.outletId)
);

const firstFavorite = favoriteOutlets[0];

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<HomeHeader userName="Emirhan" />

<SearchBar
value={searchQuery}
placeholder={t("home.search")}
onChangeText={setSearchQuery}
/>

<DashboardSectionHeader
title="What’s new for you"
subtitle="Your most important shopping update appears here."
/>

{primaryDashboardCard ? (
<DashboardUpdateCard
label={primaryDashboardCard.type}
badge={primaryDashboardCard.badge}
title={primaryDashboardCard.title}
description={primaryDashboardCard.description}
actionText={primaryDashboardCard.actionText}
onPress={() => {
navigation.navigate(primaryDashboardCard.actionRoute);
}}
/>
) : (
<DashboardUpdateCard
label="Recommendation"
badge="Recommended"
title="Create your first shopping trip"
description="Add your travel dates to unlock outlet reminders, Tax Free guidance, transportation tips and offline packs."
actionText="Create trip"
onPress={() => navigation.navigate("CreateTrip")}
/>
)}

<DashboardSectionHeader
title="Shopping tools"
subtitle="Calculate your savings before you shop."
/>

<View style={styles.toolsRow}>
<TouchableOpacity
style={styles.toolCard}
onPress={() => navigation.navigate("Savings")}
>
<Text style={styles.toolTitle}>Savings</Text>
<Text style={styles.toolText}>
Tax Free and price advantage calculators.
</Text>
</TouchableOpacity>

<TouchableOpacity
style={styles.toolCard}
onPress={() => navigation.navigate("OfflinePacks")}
>
<Text style={styles.toolTitle}>Offline Packs</Text>
<Text style={styles.toolText}>
Save outlet guides for your next trip.
</Text>
</TouchableOpacity>
</View>

<DashboardSectionHeader
title="Explore"
subtitle="Start with popular shopping cities."
/>

<View style={styles.cityRow}>
<TouchableOpacity
style={styles.cityCard}
onPress={() =>
navigation.navigate("CityResults", {
cityId: "paris",
})
}
>
<Text style={styles.cityTitle}>Paris</Text>
<Text style={styles.cityText}>France</Text>
</TouchableOpacity>

<TouchableOpacity
style={styles.cityCard}
onPress={() =>
navigation.navigate("CityResults", {
cityId: "milan",
})
}
>
<Text style={styles.cityTitle}>Milan</Text>
<Text style={styles.cityText}>Italy</Text>
</TouchableOpacity>
</View>

<DashboardSectionHeader
title="Recommended outlet"
subtitle="A premium destination to start exploring."
/>

<TouchableOpacity
style={styles.recommendedCard}
onPress={() =>
navigation.navigate("OutletDetail", {
outletId: "la-vallee-village",
})
}
activeOpacity={0.86}
>
<Text style={styles.cardLabel}>La Vallée Village</Text>

<Text style={styles.cardText}>
Luxury outlet shopping destination close to Disneyland Paris with Tax Free shopping support.
</Text>

<Text style={styles.tapText}>View outlet</Text>
</TouchableOpacity>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: colors.background,
},

content: {
padding: 20,
paddingTop: 70,
paddingBottom: 120,
},

toolsRow: {
flexDirection: "row",
gap: 12,
marginBottom: 16,
},

toolCard: {
flex: 1,
backgroundColor: colors.surface,
borderRadius: 20,
padding: 16,
borderWidth: 1,
borderColor: colors.border,

},

toolTitle: {
fontSize: 20,
fontWeight: "900",
color: colors.textPrimary,
marginBottom: 4,
},

toolText: {
color: colors.textSecondary,
fontSize: 13,
lineHeight: 19,
},

cityRow: {
flexDirection: "row",
gap: 12,
marginBottom: 16,
},

cityCard: {
flex: 1,
backgroundColor: colors.surface,
borderRadius: 20,
padding: 16,
borderWidth: 1,
borderColor: colors.border,

},

cityTitle: {
fontSize: 20,
fontWeight: "900",
color: colors.textPrimary,
},

cityText: {
fontSize: 13,
color: colors.textSecondary,
marginTop: 4,
fontWeight: "700",
},

recommendedCard: {
backgroundColor: colors.surface,
borderRadius: 20,
padding: 20,
marginBottom: 16,
borderWidth: 1,
borderColor: colors.border,

},

cardLabel: {
fontSize: 13,
color: colors.gold,
fontWeight: "900",
marginBottom: 8,
textTransform: "uppercase",
letterSpacing: 0.8,
},

cardText: {
fontSize: 15,
color: colors.textSecondary,
lineHeight: 22,
},

tapText: {
marginTop: 12,
color: colors.primary,
fontWeight: "900",
fontSize: 15,
},
});
