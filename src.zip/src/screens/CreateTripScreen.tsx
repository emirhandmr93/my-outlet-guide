import { useState } from "react";
import DateTimePicker from "@react-native-community/datetimepicker";
import { useNavigation } from "@react-navigation/native";
import { useUser } from "../contexts/UserContext";
import { requireAuth } from "../utils/requireAuth";

import {
Platform,
ScrollView,
StyleSheet,
Text,
TextInput,
TouchableOpacity,
View,
} from "react-native";

import { useTrips } from "../contexts/TripsContext";
import { useTranslation } from "../hooks/useTranslation";

function formatDate(date: Date) {
const year = date.getFullYear();
const month = String(date.getMonth() + 1).padStart(2, "0");
const day = String(date.getDate()).padStart(2, "0");

return `${year}-${month}-${day}`;
}

export function CreateTripScreen() {
const navigation = useNavigation<any>();
const { isLoggedIn } = useUser();
const { addTrip } = useTrips();
const { t } = useTranslation();

const [tripName, setTripName] = useState("");
const [startDate, setStartDate] = useState<Date | null>(null);
const [endDate, setEndDate] = useState<Date | null>(null);

const [flightNumber, setFlightNumber] = useState("");
const [departureAirport, setDepartureAirport] = useState("");
const [departureTime, setDepartureTime] = useState<Date | null>(null);

const [pickerType, setPickerType] = useState<
"start" | "end" | "departureTime" | null
>(null);

function handleSaveTrip() {
if (
!requireAuth({
isLoggedIn,
navigation,
})
) {
return;
}
if (!startDate || !endDate) {
alert(t("createTrip.alertDates"));
return;
}

if (endDate < startDate) {
alert(t("createTrip.alertEndDate"));
return;
}

const newTripId = addTrip({
tripName: tripName.trim() || t("createTrip.title"),
startDate: formatDate(startDate),
endDate: formatDate(endDate),
tripCities: [],
flightNumber: flightNumber.trim() || undefined,
departureAirport: departureAirport.trim() || undefined,
departureTime: departureTime
? departureTime.toLocaleTimeString([], {
hour: "2-digit",
minute: "2-digit",
})
: undefined,
});

navigation.navigate("TripDetail", {
tripId: newTripId,
});
}

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("createTrip.title")}</Text>
<Text style={styles.pageSubtitle}>{t("createTrip.subtitle")}</Text>

<View style={styles.card}>
<Text style={styles.label}>{t("createTrip.tripName")}</Text>

<TextInput
style={styles.input}
placeholder="Paris & Milan Trip"
placeholderTextColor="#8A8A8A"
value={tripName}
onChangeText={setTripName}
/>

<Text style={styles.label}>{t("createTrip.startDate")}</Text>

<TouchableOpacity
style={styles.input}
onPress={() => {
if (!startDate) {
setStartDate(new Date());
}
setPickerType("start");
}}
>
<Text style={startDate ? styles.inputText : styles.placeholderText}>
{startDate ? formatDate(startDate) : t("createTrip.selectStartDate")}
</Text>
</TouchableOpacity>

<Text style={styles.label}>{t("createTrip.endDate")}</Text>

<TouchableOpacity
style={styles.input}
onPress={() => {
if (!endDate) {
setEndDate(startDate || new Date());
}
setPickerType("end");
}}
>
<Text style={endDate ? styles.inputText : styles.placeholderText}>
{endDate ? formatDate(endDate) : t("createTrip.selectEndDate")}
</Text>
</TouchableOpacity>

{pickerType && (
<DateTimePicker
value={
pickerType === "start"
? startDate || new Date()
: pickerType === "end"
? endDate || startDate || new Date()
: departureTime || new Date()
}
mode={pickerType === "departureTime" ? "time" : "date"}
display={Platform.OS === "ios" ? "spinner" : "default"}
onChange={(_, selectedDate) => {
if (!selectedDate) {
setPickerType(null);
return;
}

if (pickerType === "start") {
setStartDate(selectedDate);

if (endDate && selectedDate > endDate) {
setEndDate(null);
}
}

if (pickerType === "end") {
setEndDate(selectedDate);
}

if (pickerType === "departureTime") {
setDepartureTime(selectedDate);
}

if (Platform.OS !== "ios") {
setPickerType(null);
}
}}
/>
)}

{Platform.OS === "ios" && pickerType && (
<TouchableOpacity
style={styles.doneButton}
onPress={() => setPickerType(null)}
>
<Text style={styles.doneButtonText}>{t("createTrip.done")}</Text>
</TouchableOpacity>
)}

<Text style={styles.label}>{t("createTrip.flightInfo")}</Text>

<TextInput
style={styles.input}
placeholder={t("createTrip.flightNumber")}
placeholderTextColor="#8A8A8A"
value={flightNumber}
onChangeText={setFlightNumber}
/>

<TextInput
style={[styles.input, { marginTop: 10 }]}
placeholder={t("createTrip.departureAirport")}
placeholderTextColor="#8A8A8A"
value={departureAirport}
onChangeText={setDepartureAirport}
/>

<TouchableOpacity
style={[styles.input, { marginTop: 10 }]}
onPress={() => setPickerType("departureTime")}
>
<Text
style={departureTime ? styles.inputText : styles.placeholderText}
>
{departureTime
? departureTime.toLocaleTimeString([], {
hour: "2-digit",
minute: "2-digit",
})
: t("createTrip.departureTime")}
</Text>
</TouchableOpacity>

<View style={styles.infoBox}>
<Text style={styles.infoText}>
{t("createTrip.infoText")}
</Text>
</View>

<TouchableOpacity style={styles.saveButton} onPress={handleSaveTrip}>
<Text style={styles.saveButtonText}>{t("createTrip.save")}</Text>
</TouchableOpacity>
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: "#F7F8FA",
},

content: {
padding: 20,
paddingTop: 60,
paddingBottom: 120,
},

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
},

label: {
fontSize: 14,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 8,
marginTop: 12,
},

input: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
paddingHorizontal: 14,
paddingVertical: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
fontSize: 15,
},

inputText: {
color: "#0B1F3A",
fontSize: 15,
},

placeholderText: {
color: "#8A8A8A",
fontSize: 15,
},

doneButton: {
marginTop: 12,
backgroundColor: "#EFEFEF",
borderRadius: 14,
padding: 12,
},

doneButtonText: {
textAlign: "center",
fontWeight: "800",
color: "#0B1F3A",
},

infoBox: {
marginTop: 18,
backgroundColor: "#FFF8E1",
borderRadius: 16,
padding: 14,
borderWidth: 1,
borderColor: "#C9A227",
},

infoText: {
color: "#0B1F3A",
fontSize: 13,
lineHeight: 20,
fontWeight: "700",
},

saveButton: {
marginTop: 22,
backgroundColor: "#0B1F3A",
borderRadius: 16,
padding: 15,
},

saveButtonText: {
color: "#FFFFFF",
textAlign: "center",
fontWeight: "800",
fontSize: 16,
},
});