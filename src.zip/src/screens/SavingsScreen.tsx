import { useNavigation } from "@react-navigation/native";
import { ScrollView, StyleSheet, Text, TouchableOpacity } from "react-native";
import { useTranslation } from "../hooks/useTranslation";

export function SavingsScreen() {
const navigation = useNavigation<any>();
const { t } = useTranslation();

return (
<ScrollView style={styles.container} contentContainerStyle={styles.content}>
<Text style={styles.pageTitle}>{t("savings.title")}</Text>

<Text style={styles.pageSubtitle}>
{t("savings.subtitle")}
</Text>

<TouchableOpacity
style={styles.card}
activeOpacity={0.85}
onPress={() => navigation.navigate("SmartShoppingCalculator")}
>
<Text style={styles.cardIcon}>💱</Text>

<Text style={styles.cardTitle}>
{t("savings.smartTitle")}
</Text>

<Text style={styles.cardText}>
{t("savings.smartText")}
</Text>
</TouchableOpacity>

<TouchableOpacity
style={styles.card}
activeOpacity={0.85}
onPress={() => navigation.navigate("PriceAdvantageCalculator")}
>
<Text style={styles.cardIcon}>🏷️</Text>

<Text style={styles.cardTitle}>
{t("savings.priceTitle")}
</Text>

<Text style={styles.cardText}>
{t("savings.priceText")}
</Text>
</TouchableOpacity>

<TouchableOpacity
style={styles.card}
activeOpacity={0.85}
onPress={() => navigation.navigate("TaxFreeCalculator")}
>
<Text style={styles.cardIcon}>🧮</Text>

<Text style={styles.cardTitle}>
{t("savings.taxCalcTitle")}
</Text>

<Text style={styles.cardText}>
{t("savings.taxCalcText")}
</Text>
</TouchableOpacity>

<TouchableOpacity
style={styles.card}
activeOpacity={0.85}
onPress={() => navigation.navigate("TaxFreeGuide")}
>
<Text style={styles.cardIcon}>📚</Text>

<Text style={styles.cardTitle}>
{t("savings.taxGuideTitle")}
</Text>

<Text style={styles.cardText}>
{t("savings.taxGuideText")}
</Text>
</TouchableOpacity>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: "#F7F8FA" },

content: {
padding: 20,
paddingTop: 60,
paddingBottom: 120,
},

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
marginBottom: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
},

cardIcon: {
fontSize: 26,
marginBottom: 10,
},

cardTitle: {
fontSize: 19,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 6,
},

cardText: {
fontSize: 14,
color: "#666666",
lineHeight: 20,
},
});