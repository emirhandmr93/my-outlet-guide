import { RouteProp, useNavigation, useRoute } from "@react-navigation/native";
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { outlets } from "../constants/outlets";
import { flightDeals } from "../constants/flightDeals";
import { useTranslation } from "../hooks/useTranslation";

type RouteParams = {
FlightDealDetail: {
dealId: string;
};
};

export function FlightDealDetailScreen() {
const { t } = useTranslation();
const navigation = useNavigation<any>();
    
const route =
useRoute<RouteProp<RouteParams, "FlightDealDetail">>();

const deal =
flightDeals.find(
(item) => item.dealId === route.params?.dealId
) || flightDeals[0];

const recommendedOutlet =
outlets.find((outlet) => {
if (deal.destinationCityId === "paris") {
return outlet.outletId === "la-vallee-village";
}

if (deal.destinationCityId === "milan") {
return outlet.outletId === "serravalle";
}

if (deal.destinationCityId === "london") {
return outlet.outletId === "bicester-village";
}

return false;
}) || outlets[0];

return (
<ScrollView
style={styles.container}
contentContainerStyle={styles.content}
>
<Text style={styles.pageTitle}>
{deal.airline}
</Text>

<Text style={styles.pageSubtitle}>
{t("flightDeals.detailTitle")}
</Text>

<View style={styles.card}>
<Text style={styles.sectionTitle}>
{t("flightDeals.route")}
</Text>

<Text style={styles.route}>
{deal.departureAirportId.toUpperCase()} →{" "}
{deal.destinationCityId.toUpperCase()}
</Text>

<Text style={styles.price}>
{deal.detectedPrice} {deal.currency}
</Text>

<Text style={styles.discount}>
{deal.discountPercent}% {t("flightDeals.belowAverage")}
</Text>

<Text style={styles.updated}>
{t("flightDeals.updated")} {deal.lastUpdatedMinutesAgo} {t("flightDeals.minAgo")}
</Text>
</View>

<TouchableOpacity
style={styles.card}
activeOpacity={0.85}
onPress={() =>
navigation.navigate("OutletDetail", {
outletId: recommendedOutlet.outletId,
})
}
>
<Text style={styles.sectionTitle}>
{t("flightDeals.recommendedOutlet")}
</Text>

<Text style={styles.outletTitle}>
{recommendedOutlet.name}
</Text>

<Text style={styles.outletText}>
{t("flightDeals.outletDescription")}
</Text>

<Text style={styles.outletLink}>
{t("flightDeals.viewOutlet")} →
</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.button}>
<Text style={styles.buttonText}>
{t("flightDeals.checkFlights")}
</Text>
</TouchableOpacity>

<Text style={styles.note}>
{t("flightDeals.priceNotice")}
</Text>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: "#F7F8FA",
},

content: {
padding: 20,
paddingTop: 60,
paddingBottom: 120,
},

pageTitle: {
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

pageSubtitle: {
fontSize: 15,
color: "#C9A227",
marginTop: 6,
marginBottom: 22,
},

card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
marginBottom: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
},

sectionTitle: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 10,
},

route: {
fontSize: 22,
fontWeight: "800",
color: "#0B1F3A",
},

price: {
marginTop: 14,
fontSize: 28,
fontWeight: "800",
color: "#0B1F3A",
},

discount: {
marginTop: 8,
color: "#C9A227",
fontWeight: "800",
},

updated: {
marginTop: 10,
color: "#999999",
},

outletTitle: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
},

outletText: {
marginTop: 6,
color: "#666666",
},

outletLink: {
marginTop: 12,
color: "#0B1F3A",
fontWeight: "800",
},


button: {
backgroundColor: "#0B1F3A",
borderRadius: 18,
padding: 16,
marginTop: 10,
},

buttonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},

note: {
marginTop: 16,
color: "#666666",
lineHeight: 20,
},
});