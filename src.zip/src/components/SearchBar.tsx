import { StyleSheet, Text, TextInput, View } from "react-native";

type SearchBarProps = {
value: string;
placeholder: string;
onChangeText: (value: string) => void;
};

export function SearchBar({
value,
placeholder,
onChangeText,
}: SearchBarProps) {
return (
<View style={styles.container}>
<Text style={styles.icon}>🔍</Text>

<TextInput
style={styles.input}
value={value}
placeholder={placeholder}
placeholderTextColor="#999999"
onChangeText={onChangeText}
/>
</View>
);
}

const styles = StyleSheet.create({
container: {
backgroundColor: "#FFFFFF",
borderRadius: 16,
paddingHorizontal: 16,
paddingVertical: 12,
borderWidth: 1,
borderColor: "#E5E7EB",
flexDirection: "row",
alignItems: "center",
marginBottom: 16,
},

icon: {
fontSize: 18,
marginRight: 8,
},

input: {
flex: 1,
color: "#0B1F3A",
fontSize: 15,
fontWeight: "600",
},
});