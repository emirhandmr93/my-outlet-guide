import { StyleSheet, Text, View } from "react-native";

type HomeHeaderProps = {
userName?: string;
};

export function HomeHeader({ userName }: HomeHeaderProps) {
const displayName = userName || "Shopper";

return (
<View style={styles.container}>
<Text style={styles.kicker}>MY OUTLET GUIDE</Text>

<Text style={styles.title}>
Hello, {displayName}
</Text>

<Text style={styles.subtitle}>
Plan smarter shopping trips, discover premium outlet destinations, and track savings with confidence.
</Text>
</View>
);
}

const styles = StyleSheet.create({
container: {
backgroundColor: "#0B1F3A",
borderRadius: 28,
padding: 24,
marginBottom: 16,
},

kicker: {
color: "#C9A227",
fontSize: 13,
fontWeight: "900",
letterSpacing: 1.4,
marginBottom: 12,
},

title: {
color: "#FFFFFF",
fontSize: 28,
fontWeight: "900",
marginBottom: 8,
},

subtitle: {
color: "#D8DEE9",
fontSize: 15,
lineHeight: 23,
},
});