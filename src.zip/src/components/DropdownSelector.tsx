import { useState } from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

export type DropdownOption = {
label: string;
value: string;
};

type DropdownSelectorProps = {
label: string;
selectedLabel: string;
options: DropdownOption[];
onSelect: (value: string) => void;
};

export function DropdownSelector({
label,
selectedLabel,
options,
onSelect,
}: DropdownSelectorProps) {
const [open, setOpen] = useState(false);

return (
<View style={styles.container}>
<TouchableOpacity
style={styles.selectedBox}
activeOpacity={0.85}
onPress={() => setOpen((current) => !current)}
>
<Text style={styles.selectedText}>{selectedLabel}</Text>
<Text style={styles.chevron}>{open ? "▲" : "▼"}</Text>
</TouchableOpacity>

{open && (
<View style={styles.optionsBox}>
{options.map((option) => (
<TouchableOpacity
key={option.value}
style={styles.option}
activeOpacity={0.85}
onPress={() => {
onSelect(option.value);
setOpen(false);
}}
>
<Text style={styles.optionText}>{option.label}</Text>
</TouchableOpacity>
))}
</View>
)}
</View>
);
}

const styles = StyleSheet.create({
container: {
marginBottom: 16,
},

selectedBox: {
backgroundColor: "#FFFFFF",
borderRadius: 16,
padding: 15,
borderWidth: 1,
borderColor: "#C9A227",
flexDirection: "row",
justifyContent: "space-between",
alignItems: "center",
},
selectedText: {
fontSize: 16,
fontWeight: "800",
color: "#0B1F3A",
},
chevron: {
color: "#C9A227",
fontWeight: "800",
},
optionsBox: {
marginTop: 8,
backgroundColor: "#FFFFFF",
borderRadius: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
overflow: "hidden",
},
option: {
padding: 14,
borderBottomWidth: 1,
borderBottomColor: "#F0F0F0",
},
optionText: {
fontSize: 15,
fontWeight: "700",
color: "#0B1F3A",
},
});