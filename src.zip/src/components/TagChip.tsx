import { StyleSheet, Text, View } from "react-native";
import { colors } from "../theme/colors";
import { radius } from "../theme/radius";
import { spacing } from "../theme/spacing";
import { typography } from "../theme/typography";
import { shadows } from "../theme/shadows";

type TagChipProps = {
label: string;
icon?: string;
};

export function TagChip({ label, icon }: TagChipProps) {
return (
<View style={styles.chip}>
<Text style={styles.chipText}>
{icon ? `${icon} ` : ""}
{label}
</Text>
</View>
);
}

const styles = StyleSheet.create({
chip: {
backgroundColor: colors.surfaceSoft,
borderRadius: 999,
paddingHorizontal: 12,
paddingVertical: 8,
borderWidth: 1,
borderColor: colors.border,
marginRight: 8,
marginBottom: 8,
},

chipText: {
color: colors.textPrimary,
fontWeight: "700",
fontSize: 13,
},
});