import { StyleSheet, Text, TouchableOpacity } from "react-native";
import { colors } from "../theme/colors";
import { radius } from "../theme/radius";
import { spacing } from "../theme/spacing";
import { typography } from "../theme/typography";
import { shadows } from "../theme/shadows";
import type { SearchResult } from "../services/searchTypes";

type SearchResultItemProps = {
item: SearchResult;
onPress: () => void;
};

export function SearchResultItem({ item, onPress }: SearchResultItemProps) {
return (
<TouchableOpacity
style={styles.container}
activeOpacity={0.86}
onPress={onPress}
>
<Text style={styles.type}>{item.type}</Text>
<Text style={styles.title}>{item.title}</Text>
<Text style={styles.subtitle}>{item.subtitle}</Text>
</TouchableOpacity>
);
}

const styles = StyleSheet.create({
container: {
backgroundColor: colors.surface,
borderRadius: 16,
padding: 16,
marginBottom: 8,
borderWidth: 1,
borderColor: colors.border,
},

type: {
color: colors.gold,
fontSize: typography.small,
fontWeight: "900",
textTransform: "uppercase",
marginBottom: 4,
},

title: {
color: colors.textPrimary,
fontSize: 20ge,
fontWeight: "900",
},

subtitle: {
color: colors.textSecondary,
fontSize: 13,
marginTop: 4,
},
});