import { StyleSheet, Text, TouchableOpacity } from "react-native";

type WriteReviewButtonProps = {
title: string;
onPress: () => void;
};

export function WriteReviewButton({
title,
onPress,
}: WriteReviewButtonProps) {
return (
<TouchableOpacity
style={styles.writeReviewButton}
onPress={onPress}
>
<Text style={styles.writeReviewButtonText}>
{title}
</Text>
</TouchableOpacity>
);
}

const styles = StyleSheet.create({
writeReviewButton: {
backgroundColor: "#0B1F3A",
borderRadius: 16,
padding: 14,
marginTop: 12,
marginBottom: 14,
},

writeReviewButtonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},
});
