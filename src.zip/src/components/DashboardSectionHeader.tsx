import { StyleSheet, Text, View } from "react-native";

type DashboardSectionHeaderProps = {
title: string;
subtitle?: string;
};

export function DashboardSectionHeader({
title,
subtitle,
}: DashboardSectionHeaderProps) {
return (
<View style={styles.container}>
<Text style={styles.title}>{title}</Text>

{subtitle ? (
<Text style={styles.subtitle}>{subtitle}</Text>
) : null}
</View>
);
}

const styles = StyleSheet.create({
container: {
marginTop: 8,
marginBottom: 12,
},

title: {
color: "#0B1F3A",
fontSize: 20,
fontWeight: "900",
},

subtitle: {
color: "#666666",
fontSize: 15,
marginTop: 4,
lineHeight: 21,
},
});