import {
FlatList,
Image,
StyleSheet,
Text,
TouchableOpacity,
} from "react-native";

type OutletHeroProps = {
name: string;
location: string;
selectedImage: string;
galleryImages: string[];
favoriteButtonText: string;
onPressHeroImage: () => void;
onPressGalleryImage: (image: string) => void;
onPressFavorite: () => void;
};

export function OutletHero({
name,
location,
selectedImage,
galleryImages,
favoriteButtonText,
onPressHeroImage,
onPressGalleryImage,
onPressFavorite,
}: OutletHeroProps) {
return (
<>
<TouchableOpacity onPress={onPressHeroImage}>
<Image source={{ uri: selectedImage }} style={styles.heroImage} />
</TouchableOpacity>

<FlatList
data={galleryImages}
horizontal
showsHorizontalScrollIndicator={false}
keyExtractor={(item, index) => `${item}-${index}`}
style={styles.gallery}
renderItem={({ item }) => (
<TouchableOpacity onPress={() => onPressGalleryImage(item)}>
<Image
source={{ uri: item }}
style={[
styles.galleryImage,
selectedImage === item && styles.galleryImageActive,
]}
/>
</TouchableOpacity>
)}
/>

<Text style={styles.title}>{name}</Text>

<Text style={styles.location}>{location}</Text>

<TouchableOpacity
style={styles.favoriteButton}
onPress={onPressFavorite}
>
<Text style={styles.favoriteButtonText}>
{favoriteButtonText}
</Text>
</TouchableOpacity>
</>
);
}

const styles = StyleSheet.create({
heroImage: {
width: "100%",
height: 260,
borderRadius: 28,
marginBottom: 22,
backgroundColor: "#E5E7EB",
},

gallery: {
marginBottom: 22,
},

galleryImage: {
width: 110,
height: 85,
borderRadius: 16,
marginRight: 10,
backgroundColor: "#E5E7EB",
},

galleryImageActive: {
borderWidth: 3,
borderColor: "#C9A227",
},

title: {
fontSize: 32,
fontWeight: "800",
color: "#0B1F3A",
},

location: {
fontSize: 16,
color: "#C9A227",
marginTop: 6,
marginBottom: 16,
},

favoriteButton: {
backgroundColor: "#FFFFFF",
borderRadius: 16,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 18,
},

favoriteButtonText: {
textAlign: "center",
fontWeight: "700",
color: "#0B1F3A",
},
});
