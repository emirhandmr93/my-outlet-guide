import { ReactNode } from "react";
import { StyleSheet, View } from "react-native";

type CardProps = {
children: ReactNode;
};

export function Card({ children }: CardProps) {
return <View style={styles.card}>{children}</View>;
}

const styles = StyleSheet.create({
card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 20,
marginBottom: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
},
});