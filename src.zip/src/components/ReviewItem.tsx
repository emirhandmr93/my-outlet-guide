import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

type ReviewItemProps = {
userName: string;
rating: string;
comment: string;
createdAt: string;
isEdited?: boolean;
updatedAt?: string;
previousComment?: string;
editedText: string;
previousCommentTitle: string;
helpfulText: string;
helpfulCount: number;
isHelpfulByCurrentUser: boolean;
canEdit: boolean;
editText: string;
onPressHelpful: () => void;
onPressEdit: () => void;
};

export function ReviewItem({
userName,
rating,
comment,
createdAt,
isEdited,
updatedAt,
previousComment,
editedText,
previousCommentTitle,
helpfulText,
helpfulCount,
isHelpfulByCurrentUser,
canEdit,
editText,
onPressHelpful,
onPressEdit,
}: ReviewItemProps) {
return (
<View style={styles.reviewCard}>
<Text style={styles.reviewUser}>{userName}</Text>

<Text style={styles.reviewRating}>⭐ {rating}</Text>

<Text style={styles.reviewComment}>{comment}</Text>

<Text style={styles.reviewDate}>{createdAt}</Text>

{isEdited && (
<Text style={styles.editedText}>
{editedText} • {updatedAt}
</Text>
)}

{previousComment && (
<View style={styles.previousCommentBox}>
<Text style={styles.previousCommentTitle}>
{previousCommentTitle}
</Text>

<Text style={styles.previousCommentText}>
{previousComment}
</Text>
</View>
)}

<TouchableOpacity onPress={onPressHelpful}>
<Text style={styles.reviewHelpful}>
{isHelpfulByCurrentUser ? "👍" : "👍🏻"} {helpfulText} ({helpfulCount})
</Text>
</TouchableOpacity>

{canEdit && (
<TouchableOpacity
style={styles.editReviewButton}
onPress={onPressEdit}
>
<Text style={styles.editReviewButtonText}>
{editText}
</Text>
</TouchableOpacity>
)}
</View>
);
}

const styles = StyleSheet.create({
reviewCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

reviewUser: {
fontWeight: "800",
color: "#0B1F3A",
},

reviewRating: {
marginTop: 4,
color: "#C9A227",
fontWeight: "800",
},

reviewComment: {
marginTop: 6,
color: "#666666",
lineHeight: 20,
},

reviewDate: {
marginTop: 8,
color: "#999999",
fontSize: 12,
},

editedText: {
marginTop: 4,
color: "#C9A227",
fontSize: 12,
fontWeight: "800",
},

previousCommentBox: {
marginTop: 10,
backgroundColor: "#FFFFFF",
borderRadius: 12,
padding: 10,
borderWidth: 1,
borderColor: "#E5E7EB",
},

previousCommentTitle: {
color: "#C9A227",
fontWeight: "800",
marginBottom: 4,
fontSize: 12,
},

previousCommentText: {
color: "#666666",
lineHeight: 18,
fontSize: 13,
},

reviewHelpful: {
marginTop: 8,
color: "#0B1F3A",
fontWeight: "800",
},

editReviewButton: {
marginTop: 10,
backgroundColor: "#FFFFFF",
borderRadius: 12,
padding: 10,
borderWidth: 1,
borderColor: "#E5E7EB",
},

editReviewButtonText: {
color: "#0B1F3A",
fontWeight: "800",
textAlign: "center",
},
});