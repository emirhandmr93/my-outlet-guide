import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

type ReviewSort = "helpful" | "recent";

type ReviewTabsProps = {
activeTab: ReviewSort;
helpfulText: string;
recentText: string;
onChangeTab: (tab: ReviewSort) => void;
};

export function ReviewTabs({
activeTab,
helpfulText,
recentText,
onChangeTab,
}: ReviewTabsProps) {
return (
<View style={styles.reviewTabs}>
<TouchableOpacity
style={[
styles.reviewTab,
activeTab === "helpful" && styles.reviewTabActive,
]}
onPress={() => onChangeTab("helpful")}
>
<Text
style={[
styles.reviewTabText,
activeTab === "helpful" && styles.reviewTabTextActive,
]}
>
{helpfulText}
</Text>
</TouchableOpacity>

<TouchableOpacity
style={[
styles.reviewTab,
activeTab === "recent" && styles.reviewTabActive,
]}
onPress={() => onChangeTab("recent")}
>
<Text
style={[
styles.reviewTabText,
activeTab === "recent" && styles.reviewTabTextActive,
]}
>
{recentText}
</Text>
</TouchableOpacity>
</View>
);
}

const styles = StyleSheet.create({
reviewTabs: {
flexDirection: "row",
gap: 10,
marginTop: 14,
marginBottom: 14,
},

reviewTab: {
flex: 1,
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 12,
borderWidth: 1,
borderColor: "#E5E7EB",
},

reviewTabActive: {
backgroundColor: "#0B1F3A",
borderColor: "#0B1F3A",
},

reviewTabText: {
textAlign: "center",
color: "#0B1F3A",
fontWeight: "800",
},

reviewTabTextActive: {
color: "#FFFFFF",
},
});