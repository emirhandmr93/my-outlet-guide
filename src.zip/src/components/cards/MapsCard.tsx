import { StyleSheet, Text, TouchableOpacity } from "react-native";
import { Card } from "../card";
import { SectionTitle } from "../SectionTitle";

type MapsCardProps = {
title: string;
googleText: string;
appleText: string;
yandexText: string;
onPressGoogle: () => void;
onPressApple: () => void;
onPressYandex: () => void;
};

export function MapsCard({
title,
googleText,
appleText,
yandexText,
onPressGoogle,
onPressApple,
onPressYandex,
}: MapsCardProps) {
return (
<Card>
<SectionTitle title={title} />

<TouchableOpacity style={styles.primaryButton} onPress={onPressGoogle}>
<Text style={styles.primaryButtonText}>{googleText}</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.secondaryButton} onPress={onPressApple}>
<Text style={styles.secondaryButtonText}>{appleText}</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.secondaryButton} onPress={onPressYandex}>
<Text style={styles.secondaryButtonText}>{yandexText}</Text>
</TouchableOpacity>
</Card>
);
}

const styles = StyleSheet.create({
primaryButton: {
backgroundColor: "#0B1F3A",
borderRadius: 14,
padding: 14,
marginTop: 8,
},

primaryButtonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},

secondaryButton: {
backgroundColor: "#FFFFFF",
borderRadius: 14,
padding: 14,
marginTop: 10,
borderWidth: 1,
borderColor: "#E5E7EB",
},

secondaryButtonText: {
color: "#0B1F3A",
fontWeight: "800",
textAlign: "center",
},
});