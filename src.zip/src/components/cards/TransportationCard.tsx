import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { Card } from "../card";
import { SectionTitle } from "../SectionTitle";
import type { TransportationItem } from "../../services/transportationService";

type TransportationCardProps = {
title: string;
transportationItems: TransportationItem[];
notAvailableText: string;
buttonText: string;
onPressGuide: () => void;
};

export function TransportationCard({
title,
transportationItems,
notAvailableText,
buttonText,
onPressGuide,
}: TransportationCardProps) {
return (
<Card>
<SectionTitle title={title} />

{transportationItems.length > 0 ? (
transportationItems.map((item) => (
<View key={item.transportationId} style={styles.transportationCard}>
<Text style={styles.transportationTitle}>
{item.title}
</Text>

<Text style={styles.transportationMeta}>
Duration: {item.duration}
</Text>

<Text style={styles.transportationPrice}>
{item.cost}
</Text>

<Text style={styles.transportationTip}>
{item.tip}
</Text>
</View>
))
) : (
<Text style={styles.text}>{notAvailableText}</Text>
)}

<TouchableOpacity style={styles.mapButton} onPress={onPressGuide}>
<Text style={styles.mapButtonText}>{buttonText}</Text>
</TouchableOpacity>
</Card>
);
}

const styles = StyleSheet.create({
transportationCard: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

transportationTitle: {
color: "#0B1F3A",
fontWeight: "800",
fontSize: 16,
},

transportationMeta: {
marginTop: 6,
color: "#666666",
lineHeight: 20,
},

transportationPrice: {
marginTop: 6,
color: "#C9A227",
fontWeight: "800",
},

transportationTip: {
marginTop: 8,
color: "#666666",
fontStyle: "italic",
lineHeight: 20,
},

mapButton: {
backgroundColor: "#0B1F3A",
borderRadius: 14,
padding: 14,
marginTop: 8,
},

mapButtonText: {
color: "#FFFFFF",
fontWeight: "800",
textAlign: "center",
},

text: {
fontSize: 15,
color: "#666666",
lineHeight: 22,
marginBottom: 6,
},
});
