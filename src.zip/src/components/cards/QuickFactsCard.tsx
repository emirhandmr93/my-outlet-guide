import { StyleSheet, Text, View } from "react-native";
import { Card } from "../card";
import { SectionTitle } from "../SectionTitle";
import type { CurrentWeather } from "../../services/weatherService";

type QuickFactsCardProps = {
title: string;
weather: CurrentWeather | null;
weatherLoading: boolean;
weatherError: boolean;
weatherLoadingText: string;
weatherUnavailableText: string;
cityName: string;
openingHoursLabel: string;
openingHours: string;
addressLabel: string;
address: string;
storesCountText: string;
cityCenterDistanceKm: number;
airportDistanceKm: number;
reviewCountLabel: string;
reviewCount: number;
};

export function QuickFactsCard({
title,
weather,
weatherLoading,
weatherError,
weatherLoadingText,
weatherUnavailableText,
cityName,
openingHoursLabel,
openingHours,
addressLabel,
address,
storesCountText,
cityCenterDistanceKm,
airportDistanceKm,
reviewCountLabel,
reviewCount,
}: QuickFactsCardProps) {
return (
<Card>
<SectionTitle title={title} />

<View style={styles.weatherCard}>
<Text style={styles.weatherIcon}>
{weather ? weather.icon : "☀️"}
</Text>

<View>
<Text style={styles.weatherTitle}>Current Weather</Text>

<Text style={styles.weatherText}>
{weatherLoading
? weatherLoadingText
: weatherError
? weatherUnavailableText
: `${cityName} • ${weather?.temperature}°C • ${weather?.condition}`}
</Text>
</View>
</View>

<Text style={styles.text}>
{openingHoursLabel}: {openingHours}
</Text>

<Text style={styles.text}>
{addressLabel}: {address}
</Text>

<Text style={styles.text}>
Stores: {storesCountText}
</Text>

<Text style={styles.text}>
City Center Distance: {cityCenterDistanceKm} km
</Text>

<Text style={styles.text}>
Airport Distance: {airportDistanceKm} km
</Text>

<Text style={styles.text}>
{reviewCountLabel}: {reviewCount}
</Text>
</Card>
);
}

const styles = StyleSheet.create({
weatherCard: {
backgroundColor: "#FFF8E1",
borderRadius: 20,
padding: 16,
marginBottom: 16,
borderWidth: 1,
borderColor: "#C9A227",
flexDirection: "row",
alignItems: "center",
},

weatherIcon: {
fontSize: 30,
marginRight: 12,
},

weatherTitle: {
color: "#0B1F3A",
fontWeight: "900",
fontSize: 15,
},

weatherText: {
color: "#666666",
marginTop: 4,
},

text: {
fontSize: 15,
color: "#666666",
lineHeight: 22,
marginBottom: 6,
},
});