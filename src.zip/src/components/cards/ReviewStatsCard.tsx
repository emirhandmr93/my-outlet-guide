import { StyleSheet, Text, View } from "react-native";

type ReviewStatsCardProps = {
summaryText: string;
transportationTitle: string;
transportationValue: string;
brandsTitle: string;
brandsValue: string;
restaurantsTitle: string;
restaurantsValue: string;
servicesTitle: string;
servicesValue: string;
};

export function ReviewStatsCard({
summaryText,
transportationTitle,
transportationValue,
brandsTitle,
brandsValue,
restaurantsTitle,
restaurantsValue,
servicesTitle,
servicesValue,
}: ReviewStatsCardProps) {
return (
<>
<Text style={styles.reviewSummary}>
{summaryText}
</Text>

<View style={styles.reviewStatsRow}>
<View style={styles.reviewStatBox}>
<Text style={styles.reviewStatTitle}>
{transportationTitle}
</Text>
<Text style={styles.reviewStatValue}>
⭐ {transportationValue}
</Text>
</View>

<View style={styles.reviewStatBox}>
<Text style={styles.reviewStatTitle}>
{brandsTitle}
</Text>
<Text style={styles.reviewStatValue}>
⭐ {brandsValue}
</Text>
</View>
</View>

<View style={styles.reviewStatsRow}>
<View style={styles.reviewStatBox}>
<Text style={styles.reviewStatTitle}>
{restaurantsTitle}
</Text>
<Text style={styles.reviewStatValue}>
⭐ {restaurantsValue}
</Text>
</View>

<View style={styles.reviewStatBox}>
<Text style={styles.reviewStatTitle}>
{servicesTitle}
</Text>
<Text style={styles.reviewStatValue}>
⭐ {servicesValue}
</Text>
</View>
</View>
</>
);
}

const styles = StyleSheet.create({
reviewSummary: {
fontSize: 18,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 14,
},

reviewStatsRow: {
flexDirection: "row",
gap: 10,
marginBottom: 10,
},

reviewStatBox: {
flex: 1,
backgroundColor: "#F7F8FA",
borderRadius: 12,
padding: 12,
borderWidth: 1,
borderColor: "#E5E7EB",
},

reviewStatTitle: {
color: "#666666",
fontSize: 12,
fontWeight: "700",
},

reviewStatValue: {
marginTop: 4,
color: "#0B1F3A",
fontWeight: "800",
},
});