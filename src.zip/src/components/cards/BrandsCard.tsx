import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { Card } from "../card";
import { SectionTitle } from "../SectionTitle";
import type { BrandCategoryGroup } from "../../services/brandService";

type BrandsCardProps = {
title: string;
brandSearch: string;
setBrandSearch: (value: string) => void;
openCategory: string | null;
setOpenCategory: (value: string | null) => void;
brandCategoryGroups: BrandCategoryGroup[];
};

export function BrandsCard({
title,
brandSearch,
setBrandSearch,
openCategory,
setOpenCategory,
brandCategoryGroups,
}: BrandsCardProps) {
return (
<Card>
<SectionTitle title={title} />

<TextInput
style={styles.brandSearchInput}
placeholder="Search brands..."
placeholderTextColor="#8A8A8A"
value={brandSearch}
onChangeText={setBrandSearch}
/>

{brandCategoryGroups.map((category) => {
const filteredBrands = category.brands.filter((brand) =>
brand.brandName.toLowerCase().includes(brandSearch.toLowerCase())
);

if (brandSearch && filteredBrands.length === 0) {
return null;
}

const isOpen = openCategory === category.categoryId || Boolean(brandSearch);

return (
<View key={category.categoryId} style={styles.brandCategoryBox}>
<TouchableOpacity
onPress={() =>
setOpenCategory(isOpen ? null : category.categoryId)
}
>
<Text style={styles.brandCategoryTitle}>
{category.icon} {category.categoryName} ({filteredBrands.length}){" "}
{isOpen ? "▲" : "▼"}
</Text>
</TouchableOpacity>

{isOpen &&
filteredBrands.map((brand) => (
<Text key={brand.brandId} style={styles.brandItem}>
• {brand.brandName}
</Text>
))}
</View>
);
})}
</Card>
);
}

const styles = StyleSheet.create({
brandSearchInput: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 14,
color: "#0B1F3A",
},

brandCategoryBox: {
backgroundColor: "#F7F8FA",
borderRadius: 14,
padding: 14,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 10,
},

brandCategoryTitle: {
color: "#0B1F3A",
fontWeight: "800",
},

brandItem: {
color: "#666666",
marginTop: 8,
},
});