import { StyleSheet, Text, View } from "react-native";
import { WeatherForecast } from "../constants/weatherForecasts";

type WeatherCardProps = {
weather: WeatherForecast;
};

export function WeatherCard({ weather }: WeatherCardProps) {
return (
<View style={styles.card}>
<Text style={styles.cityName}>{weather.cityName}</Text>

{weather.forecasts.map((forecast) => (
<View key={forecast.date} style={styles.forecastRow}>
<Text style={styles.day}>{forecast.date}</Text>

<View style={styles.weatherInfo}>
<Text style={styles.icon}>{forecast.icon}</Text>
<Text style={styles.temperature}>{forecast.temperature}°C</Text>
</View>
</View>
))}
</View>
);
}

const styles = StyleSheet.create({
card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 18,
borderWidth: 1,
borderColor: "#E5E7EB",
marginBottom: 14,
},
cityName: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 12,
},
forecastRow: {
flexDirection: "row",
justifyContent: "space-between",
alignItems: "center",
paddingVertical: 8,
},
day: {
color: "#666666",
fontWeight: "600",
},
weatherInfo: {
flexDirection: "row",
alignItems: "center",
gap: 8,
},
icon: { fontSize: 20 },
temperature: {
fontWeight: "800",
color: "#0B1F3A",
},
});