import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

type DashboardUpdateCardProps = {
label: string;
title: string;
description: string;
actionText: string;
badge?: string;
onPress: () => void;
};

export function DashboardUpdateCard({
label,
title,
description,
actionText,
badge,
onPress,
}: DashboardUpdateCardProps) {
return (
<TouchableOpacity style={styles.card} activeOpacity={0.86} onPress={onPress}>
<View style={styles.topRow}>
<Text style={styles.label}>{badge || label}</Text>
</View>

<Text style={styles.title}>{title}</Text>
<Text style={styles.description}>{description}</Text>
<Text style={styles.action}>{actionText}</Text>
</TouchableOpacity>
);
}

const styles = StyleSheet.create({
card: {
backgroundColor: "#FFFFFF",
borderRadius: 20,
padding: 20,
marginBottom: 16,
borderWidth: 1,
borderColor: "#E5E7EB",
},

topRow: {
marginBottom: 8,
},

label: {
color: "#C9A227",
fontSize: 13,
fontWeight: "900",
letterSpacing: 0.8,
textTransform: "uppercase",
},

title: {
color: "#0B1F3A",
fontSize: 22,
fontWeight: "900",
marginBottom: 8,
},

description: {
color: "#666666",
fontSize: 15,
lineHeight: 22,
marginBottom: 12,
},

action: {
color: "#0B1F3A",
fontSize: 15,
fontWeight: "900",
},
});