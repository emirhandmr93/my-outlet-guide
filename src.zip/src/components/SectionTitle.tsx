import { Text, StyleSheet } from "react-native";

type SectionTitleProps = {
title: string;
};

export function SectionTitle({ title }: SectionTitleProps) {
return <Text style={styles.title}>{title}</Text>;
}

const styles = StyleSheet.create({
title: {
fontSize: 20,
fontWeight: "800",
color: "#0B1F3A",
marginBottom: 12,
},
});