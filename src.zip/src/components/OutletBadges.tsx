import { StyleSheet, Text, View } from "react-native";
import { colors } from "../theme/colors";
import { radius } from "../theme/radius";
import { spacing } from "../theme/spacing";
import { typography } from "../theme/typography";
import { shadows } from "../theme/shadows";

type OutletBadgesProps = {
taxFreeText: string;
status: string;
rating: number;
};

export function OutletBadges({
taxFreeText,
status,
rating,
}: OutletBadgesProps) {
return (
<View style={styles.badgeRow}>
<Text style={styles.badge}>{taxFreeText}</Text>
<Text style={styles.badge}>{status}</Text>
<Text style={styles.badge}>⭐ {rating}</Text>
</View>
);
}

const styles = StyleSheet.create({
badgeRow: {
flexDirection: "row",
gap: 8,
marginBottom: 16,
flexWrap: "wrap",
},

badge: {
backgroundColor: colors.surface,
color: colors.textPrimary,
paddingHorizontal: 12,
paddingVertical: 8,
borderRadius: radius.pill,
borderWidth: 1,
borderColor: colors.border,
fontWeight: "700",
fontSize: 13,
textTransform: "capitalize",
},
});
