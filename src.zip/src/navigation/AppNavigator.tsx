import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { TransportationScreen } from "../screens/TransportationScreen";
import { CityResultsScreen } from "../screens/CityResultsScreen";
import { HomeScreen } from "../screens/HomeScreen";
import { ExploreScreen } from "../screens/ExploreScreen";
import { SavingsScreen } from "../screens/SavingsScreen";
import { FavoritesScreen } from "../screens/FavoritesScreen";
import { ProfileScreen } from "../screens/ProfileScreen";
import { LanguageSettingsScreen } from "../screens/LanguageSettingsScreen";
import { OutletDetailScreen } from "../screens/OutletDetailScreen";
import { CountryScreen } from "../screens/CountryScreen";
import { MyTripsScreen } from "../screens/MyTripsScreen";
import { CreateTripScreen } from "../screens/CreateTripScreen";
import { TaxFreeCalculatorScreen } from "../screens/TaxFreeCalculatorScreen";
import { CurrencySettingsScreen } from "../screens/CurrencySettingsScreen";
import { BrandResultsScreen } from "../screens/BrandResultsScreen";
import { TripDetailScreen } from "../screens/TripDetailScreen";
import { NotificationSettingsScreen } from "../screens/NotificationSettingsScreen";
import { TaxFreeGuideScreen } from "../screens/TaxFreeGuideScreen";
import { SmartShoppingCalculatorScreen } from "../screens/SmartShoppingCalculatorScreen";
import { PriceAdvantageCalculatorScreen } from "../screens/PriceAdvantageCalculatorScreen";
import { OfflinePacksScreen } from "../screens/OfflinePacksScreen";
import { WriteReviewScreen } from "../screens/WriteReviewScreen";
import { FlightDealSettingsScreen } from "../screens/FlightDealSettingsScreen";
import { FlightDealsScreen } from "../screens/FlightDealsScreen";
import { FlightDealDetailScreen } from "../screens/FlightDealDetailScreen";
import { LoginScreen } from "../screens/LoginScreen";
import { MyReviewsScreen } from "../screens/MyReviewsScreen";
import { PrivacyPolicyScreen } from "../screens/PrivacyPolicyScreen";
import { TermsConditionsScreen } from "../screens/TermsConditionsScreen";
import { ContactUsScreen } from "../screens/ContactUsScreen";
import { HelpFaqScreen } from "../screens/HelpFaqScreen";
import { DeleteAccountScreen } from "../screens/DeleteAccountScreen";


const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function MainTabs() {
return (
<Tab.Navigator
screenOptions={{
headerShown: false,
tabBarActiveTintColor: "#C9A227",
tabBarInactiveTintColor: "#7A7A7A",
tabBarStyle: {
backgroundColor: "#FFFFFF",
borderTopColor: "#E5E5E5",
},
}}
>
<Tab.Screen name="Home" component={HomeScreen} />
<Tab.Screen name="Explore" component={ExploreScreen} />
<Tab.Screen name="Savings" component={SavingsScreen} />
<Tab.Screen name="Favorites" component={FavoritesScreen} />
<Tab.Screen name="Profile" component={ProfileScreen} />

</Tab.Navigator>
);
}

export function AppNavigator() {
return (
<NavigationContainer>
<Stack.Navigator
screenOptions={{
headerShown: true,
headerTintColor: "#0B1F3A",
headerTitleStyle: {
fontWeight: "800",
},
headerStyle: {
backgroundColor: "#FFFFFF",
},
}}
>
<Stack.Screen
name="MainTabs"
component={MainTabs}
options={{ headerShown: false }}
/>

<Stack.Screen
name="OutletDetail"
component={OutletDetailScreen}
options={{
title: "Outlet",
headerBackTitle: "Explore",
}}
/>

<Stack.Screen
name="BrandResults"
component={BrandResultsScreen}
options={{
title: "Marka",
headerBackTitle: "Explore",
}}
/>

<Stack.Screen
name="Transportation"
component={TransportationScreen}
options={{
title: "Ulaşım",
headerBackTitle: "Outlet",
}}
/>

<Stack.Screen
name="Country"
component={CountryScreen}
options={{
title: "Ülke",
headerBackTitle: "Explore",
}}
/>

<Stack.Screen
name="CityResults"
component={CityResultsScreen}
options={{
title: "Şehir",
headerBackTitle: "Explore",
}}
/>

<Stack.Screen
name="MyTrips"
component={MyTripsScreen}
options={{
title: "Seyahatlerim",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="CreateTrip"
component={CreateTripScreen}
options={{
title: "Seyahat Oluştur",
headerBackTitle: "My Trips",
}}
/>

<Stack.Screen
name="SmartShoppingCalculator"
component={SmartShoppingCalculatorScreen}
options={{
title: "Akıllı Hesap Makinesi",
headerBackTitle: "Savings",
}}
/>

<Stack.Screen
name="PriceAdvantageCalculator"
component={PriceAdvantageCalculatorScreen}
options={{
title: "Fiyat Avantajı",
headerBackTitle: "Savings",
}}
/>

<Stack.Screen
name="TaxFreeCalculator"
component={TaxFreeCalculatorScreen}
options={{
title: "Tax Free Hesaplayıcı",
headerBackTitle: "Savings",
}}
/>

<Stack.Screen
name="TaxFreeGuide"
component={TaxFreeGuideScreen}
options={{
title: "Tax Free Rehberi",
headerBackTitle: "Savings",
}}
/>

<Stack.Screen
name="TripDetail"
component={TripDetailScreen}
options={{
title: "Seyahat Detayı",
headerBackTitle: "My Trips",
}}
/>

<Stack.Screen
name="LanguageSettings"
component={LanguageSettingsScreen}
options={{
title: "Dil",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="CurrencySettings"
component={CurrencySettingsScreen}
options={{
title: "Para Birimi",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="NotificationSettings"
component={NotificationSettingsScreen}
options={{
title: "Bildirimler",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="OfflinePacks"
component={OfflinePacksScreen}
options={{
title: "Çevrimdışı Paketler",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="WriteReview"
component={WriteReviewScreen}
options={{
title: "Yorum Yaz",
headerBackTitle: "Outlet",
}}
/>

<Stack.Screen
name="FlightDealSettings"
component={FlightDealSettingsScreen}
options={{
title: "Uçuş Fırsatları",
headerBackTitle: "Bildirimler",
}}
/>

<Stack.Screen
name="FlightDeals"
component={FlightDealsScreen}
options={{
title: "Uçuş Fırsatları",
headerBackTitle: "Bildirimler",
}}
/>

<Stack.Screen
name="FlightDealDetail"
component={FlightDealDetailScreen}
options={{
title: "Uçuş Fırsatı",
headerBackTitle: "Fırsatlar",
}}
/>

<Stack.Screen
name="Login"
component={LoginScreen}
options={{
title: "Sign In",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="MyReviews"
component={MyReviewsScreen}
options={{
title: "My Reviews",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="PrivacyPolicy"
component={PrivacyPolicyScreen}
options={{
title: "Privacy Policy",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="TermsConditions"
component={TermsConditionsScreen}
options={{
title: "Terms & Conditions",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="ContactUs"
component={ContactUsScreen}
options={{
title: "Contact Us",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="HelpFaq"
component={HelpFaqScreen}
options={{
title: "Help & FAQ",
headerBackTitle: "Profile",
}}
/>

<Stack.Screen
name="DeleteAccount"
component={DeleteAccountScreen}
options={{
title: "Delete Account",
headerBackTitle: "Profile",
}}
/>

</Stack.Navigator>
</NavigationContainer>
);

}